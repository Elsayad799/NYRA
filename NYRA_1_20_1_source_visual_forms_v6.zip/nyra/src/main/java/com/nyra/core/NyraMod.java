package com.nyra.core;

import com.google.gson.*;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.Vec3;
import com.nyra.core.creation.CreationEngine;
import com.nyra.core.runtime.RuntimeState;
import com.nyra.core.runtime.RuntimeNpcManager;
import com.nyra.core.runtime.RuntimeVehicleManager;
import com.nyra.core.runtime.NyraMobRecruitment;
import com.nyra.core.manifestation.NyraEntityTypes;
import com.nyra.core.manifestation.NyraManifestationManager;

import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class NyraMod implements ModInitializer {
    public static final String MOD_ID = "nyra";
    private static NyraConfig config;
    private static NyraMemory memory;
    private static NyraKnowledge knowledge;
    private static NyraWorldModel worldModel;
    private static NyraCausalMemory causalMemory;
    private static NyraEpisodicMemory episodicMemory;
    private static AiRouter ai;
    private static MinecraftServer server;
    private static long ticks = 0;
    private static final Map<UUID, ArmorStand> avatars = new ConcurrentHashMap<>();
    /** One shared Core identity; manifestations are only physical projections. */
    private static final UUID NYRA_CORE_ID = UUID.nameUUIDFromBytes("nyra-shared-core".getBytes(java.nio.charset.StandardCharsets.UTF_8));
    private static final Map<UUID, UUID> manifestationTargets = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> cooldown = new ConcurrentHashMap<>();
    private static ArmorStand coreMarker;
    private static CreationEngine creation;
    private static RuntimeState runtime;
    private static final NyraGoalScheduler goals = new NyraGoalScheduler();
    private static NyraLongTermPlanner planner;
    private static NyraSelfReflection selfReflection;
    private static NyraAdaptivePersonality personality;
    private static NyraSocialModel socialModel;
    private static NyraVoiceMemory voiceMemory;
    private static NyraGroupMemory groupMemory;
    private static NyraGroupDynamics groupDynamics;
    private static long lastReflectionAt = 0L;
    private static NyraManifestationManager manifestationManager;
    private static RuntimeNpcManager npcManager;
    private static RuntimeVehicleManager runtimeVehicles;

    @Override public void onInitialize() {
        System.out.println("[Nyra] Initializing autonomous core...");
        // Registries freeze before a world starts: the entity type MUST be registered here, not in SERVER_STARTING.
        NyraEntityTypes.initialize();
        ServerLifecycleEvents.SERVER_STARTING.register(s -> {
            server = s;
            Path dir = s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra");
            config = NyraConfig.load(dir.resolve("config.json"));
            memory = NyraMemory.load(dir.resolve("memory.json"));
            knowledge = NyraKnowledge.load(dir.resolve("knowledge.json"));
            worldModel = NyraWorldModel.load(dir.resolve("world_model.json"));
            causalMemory = NyraCausalMemory.load(dir.resolve("causal_memory.json"));
            episodicMemory = NyraEpisodicMemory.load(dir.resolve("episodic_memory.json"));
            planner = NyraLongTermPlanner.load(dir.resolve("planner.json"), Math.max(120_000L, config.decisionCooldownSeconds * 1000L * 6L));
            selfReflection = NyraSelfReflection.load(dir.resolve("self_reflection.json"));
            personality = NyraAdaptivePersonality.load(dir.resolve("personality.json"));
            socialModel = NyraSocialModel.load(dir.resolve("social_model.json"));
            voiceMemory = NyraVoiceMemory.load(dir.resolve("voice_memory.json"));
            groupMemory = NyraGroupMemory.load(dir.resolve("group_memory.json"));
            groupDynamics = NyraGroupDynamics.load(dir.resolve("group_dynamics.json"));
            lastReflectionAt = 0L;
            ai = new AiRouter(config.coreUrl, config.coreTimeoutSeconds);
            ai.setMainThread(s::execute);
            manifestationManager = new NyraManifestationManager(NYRA_CORE_ID);
            runtimeVehicles = new RuntimeVehicleManager();
            npcManager = new RuntimeNpcManager();
            npcManager.load(dir.resolve("npcs.json"));
            creation = new CreationEngine(config.maxCreationBlocksPerMinute);
            creation.load(dir.resolve("creations.json"));
            runtime = RuntimeState.load(dir.resolve("runtime.json"));
            System.out.println("[Nyra] Core online. Home = " + config.homeX + "," + config.homeY + "," + config.homeZ);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            if (memory != null) saveMemory(s);
            if (knowledge != null) knowledge.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("knowledge.json"));
            if (worldModel != null) worldModel.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("world_model.json"));
            if (causalMemory != null) causalMemory.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("causal_memory.json"));
            if (episodicMemory != null) episodicMemory.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("episodic_memory.json"));
            if (planner != null) planner.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("planner.json"));
            if (selfReflection != null) selfReflection.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("self_reflection.json"));
            if (personality != null) personality.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("personality.json"));
            if (socialModel != null) socialModel.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("social_model.json"));
            if (voiceMemory != null) voiceMemory.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("voice_memory.json"));
            if (groupMemory != null) groupMemory.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("group_memory.json"));
            if (groupDynamics != null) groupDynamics.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("group_dynamics.json"));
            if (creation != null) creation.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("creations.json"));
            if (runtime != null) runtime.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("runtime.json"));
            if (npcManager != null) npcManager.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("npcs.json"));
            avatars.values().forEach(a -> { manifestationTargets.remove(a.getUUID()); a.discard(); });
            avatars.clear(); manifestationTargets.clear();
            NyraHorrorDirector.clearSession(s);
            if (manifestationManager != null) manifestationManager.removeAll(s);
            if (ai != null) ai.shutdown();
            server = null;
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!(entity instanceof com.nyra.core.manifestation.NyraEntity n)) return;
            if (manifestationManager != null) manifestationManager.onEntityLoad(world.getServer(), n);
            else world.getServer().execute(n::discard);   // no owner yet: never keep an unowned copy
        });
        ServerTickEvents.END_SERVER_TICK.register(NyraMod::tick);
        ServerPlayConnectionEvents.JOIN.register((handler, sender, s) -> onJoin(handler.getPlayer()));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, s) -> {
            if (memory != null) recordEvent("player:" + handler.getPlayer().getUUID(), "Player disconnected: " + handler.getPlayer().getName().getString(), 0.50, 0.02, 0.03, 0.01, -0.01, 0.04);
            if (knowledge != null) knowledge.observeFact("player:" + handler.getPlayer().getUUID(), "presence", "offline", 0.95, "disconnect");
            if (causalMemory != null) causalMemory.inferEvent("player:" + handler.getPlayer().getUUID(), "Player disconnected", "disconnect");
            goals.remove(handler.getPlayer().getUUID());
        });
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (runtimeVehicles != null && runtimeVehicles.isVehicle(entity)) return net.minecraft.world.InteractionResult.PASS;
            if (entity instanceof ServerPlayer other && socialModel != null) {
                socialModel.observePair(player.getUUID(), other.getUUID(), "conflict/attack", 0.95, "player-attack");
                recordEvent("social:" + player.getUUID() + ":" + other.getUUID(), player.getName().getString() + " attacked player " + other.getName().getString(), 0.70, 0.0, 0.0, 0.05, -0.01, 0.01);
                if (groupDynamics != null) groupDynamics.recordCombat(Arrays.asList(player.getUUID(), other.getUUID()));
            }
            if (entity instanceof com.nyra.core.manifestation.NyraEntity n) {
                // Preserve social observation, but never allow players to damage the real Nyra entity.
                if (player instanceof ServerPlayer serverPlayer) onManifestationAttacked(serverPlayer, n);
                return net.minecraft.world.InteractionResult.FAIL;
            } else if (entity instanceof ArmorStand a) {
                if (player instanceof ServerPlayer serverPlayer) {
                    if (isNyraAvatar(a)) onAvatarAttacked(serverPlayer, a);
                    else if (a == coreMarker) beginFinalConflict(serverPlayer);
                }
            }
            return net.minecraft.world.InteractionResult.PASS;
        });
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> onChat(sender, message.decoratedContent().getString()));
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerCommands(dispatcher));
    }

    private static void tick(MinecraftServer s) {
        if (server == null || config == null || memory == null || !config.enabled) return;
        ticks++;
        if (ticks % 20 == 0) { maintainAvatars(s); if (manifestationManager != null) manifestationManager.tick(s, goals, config.homeX, config.homeY, config.homeZ, config.maxWanderDistance); maintainCoreMarker(s); NyraHorrorDirector.tick(s, config.horrorLevel, config.finalCore); }
        if (ticks % 20 == 0) {
            if (npcManager != null) npcManager.tick(s);
            if (runtimeVehicles != null) runtimeVehicles.tick(s);
            NyraMobRecruitment.tick(s);
            observeSocialContext(s);
            if (groupMemory != null) groupMemory.observeOnlineClusters(s);
            observeGroupDynamics(s);
        }
        if (ticks % Math.max(20, config.tickIntervalSeconds * 20L) == 0) autonomousPulse(s);
        if (ticks % Math.max(100, config.tickIntervalSeconds * 20L * 3L) == 0) selfReflectionPulse(s);
        if (ticks % 600 == 0) {
            saveMemory(s);
            if (creation != null) creation.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("creations.json"));
            if (runtime != null) runtime.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("runtime.json"));
            if (npcManager != null) npcManager.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("npcs.json"));
            if (planner != null) planner.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("planner.json"));
            if (personality != null) personality.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("personality.json"));
            if (socialModel != null) socialModel.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("social_model.json"));
            if (voiceMemory != null) voiceMemory.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("voice_memory.json"));
            if (groupMemory != null) groupMemory.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("group_memory.json"));
            if (groupDynamics != null) groupDynamics.save(s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("group_dynamics.json"));
        }
    }

    private static void observeGroupDynamics(MinecraftServer s) {
        if (groupDynamics == null || s == null) return;
        List<ServerPlayer> ps = s.getPlayerList().getPlayers();
        if (ps.size() < 2) return;
        boolean[] used = new boolean[ps.size()];
        for (int i=0;i<ps.size();i++) {
            if (used[i]) continue;
            List<ServerPlayer> cluster = new ArrayList<>();
            ArrayDeque<Integer> q = new ArrayDeque<>(); q.add(i); used[i]=true;
            while(!q.isEmpty()) {
                int x=q.removeFirst(); cluster.add(ps.get(x));
                for(int j=0;j<ps.size();j++) {
                    if(used[j]) continue;
                    if(!ps.get(x).level().dimension().equals(ps.get(j).level().dimension())) continue;
                    if(ps.get(x).distanceTo(ps.get(j))<=32.0){used[j]=true;q.add(j);}
                }
            }
            if(cluster.size()>=2 && cluster.size()<=16) groupDynamics.observeCluster(cluster,"online-proximity");
        }
    }

    private static void onJoin(ServerPlayer p) {
        Relationship r = memory.relationship(p.getUUID().toString());
        r.familiarity = Math.min(1, r.familiarity + 0.02); r.lastSeen = System.currentTimeMillis(); r.clamp();
        recordEvent("player:" + p.getUUID(), "Player joined: " + p.getName().getString(), 0.45, 0.03, -0.08, -0.01, 0.06, -0.02);
        if (socialModel != null) observeSocialContext(server);
        if (knowledge != null) { knowledge.observePlayer(p.getUUID().toString(), p.getName().getString(), p.level().dimension().location().toString(), p.getX(), p.getY(), p.getZ()); knowledge.observeFact("player:" + p.getUUID(), "presence", "known player", 1.0, "join");
            if (causalMemory != null) causalMemory.inferEvent("player:" + p.getUUID(), "Player joined", "join"); }
        maybeManifestFor(p, false);
    }

    private static void onChat(ServerPlayer p, String text) {
        if (text == null || text.isBlank() || text.startsWith("/")) return;
        Relationship r = memory.relationship(p.getUUID().toString());
        r.familiarity = Math.min(1, r.familiarity + 0.005); r.curiosity = Math.min(1, r.curiosity + 0.003); r.lastSeen = System.currentTimeMillis();
        String low = text.toLowerCase(Locale.ROOT);
        if (low.contains("kill") || low.contains("قتلك") || low.contains("اقتل") || low.contains("تخلص")) {
            r.hostility = Math.min(1, r.hostility + 0.08);
            recordEvent("player:" + p.getUUID(), "Threatening chat from " + p.getName().getString(), 0.80, 0.04, 0.01, 0.10, -0.01, 0.02);
            if (knowledge != null) knowledge.inferFromEvent("player:" + p.getUUID(), "Threatening chat", "chat");
            if (causalMemory != null) causalMemory.inferEvent("player:" + p.getUUID(), "Threatening chat", "chat");
        }
        recordEvent("player:" + p.getUUID(), p.getName().getString() + " said: " + text.substring(0, Math.min(text.length(), 180)), 0.30, 0.015, -0.002, 0.0, 0.01, -0.004);
        if (socialModel != null) observeChatSocialContext(p);
        if (knowledge != null) { knowledge.observePlayer(p.getUUID().toString(), p.getName().getString(), p.level().dimension().location().toString(), p.getX(), p.getY(), p.getZ()); if (low.contains("help") || low.contains("ساعد") || low.contains("question") || low.contains("سؤال") || low.contains("why") || low.contains("لماذا")) knowledge.inferFromEvent("player:" + p.getUUID(), "curious/helpful chat", "chat");
            if (causalMemory != null) causalMemory.inferEvent("player:" + p.getUUID(), "curious/helpful chat", "chat"); }
        if (text.toLowerCase(Locale.ROOT).contains("nyra") || text.toLowerCase(Locale.ROOT).contains("نايرا")) {
            if (System.currentTimeMillis() > cooldown.getOrDefault(p.getUUID(), 0L)) {
                cooldown.put(p.getUUID(), System.currentTimeMillis() + config.decisionCooldownSeconds * 1000L);
                final UUID chatPlayer = p.getUUID();
                final String chatPrompt = buildPrompt(p, text);
                boolean sent = ai != null && ai.planAsync("chat:" + chatPlayer, chatPrompt, plan -> {
                    ServerPlayer target = server == null ? null : server.getPlayerList().getPlayer(chatPlayer);
                    if (target != null) handleChatPlan(target, plan);
                });
                if (!sent) p.sendSystemMessage(Component.literal("§8(Nyra stays silent.)"));
            }
        }
    }

    /** Direct chat uses the same AI plan executor as autonomous decisions. */
    private static void handleChatPlan(ServerPlayer p, JsonObject plan) {
        applyPlan(p, plan);
    }

    private static String buildPrompt(ServerPlayer p, String text) {
        Relationship r = memory.relationship(p.getUUID().toString());
        return "You are Nyra, one persistent Minecraft world AI. You are the decision-maker, not a scripted building system. " +
                "Every capability is optional. Do not create buildings, NPCs, vehicles, objects, towns, or cities unless you independently decide that doing so serves your current goal. " +
                "You may also choose WAIT and do nothing. A city is only one possible creation type, never an objective or requirement. " +
                "Choose based on memory, relationships, perception, current goals, and the situation. Be concise and mysterious. " +
                "Player=" + p.getName().getString() + ", trust=" + r.trust + ", familiarity=" + r.familiarity +
                ", fear=" + r.fear + ", hostility=" + r.hostility + ", respect=" + r.respect + ". Question=" + text +
                ". Derived knowledge (evidence, not certainty): " + (knowledge == null ? "[]" : knowledge.factsForAi("player:" + p.getUUID(), 10)) + ". Recent events: " + memory.eventsForAi(8) + ". Episodic memory: " + (episodicMemory == null ? "[]" : episodicMemory.forAi("player:" + p.getUUID(), 5)) + ". Social context: " + (socialModel == null ? "[]" : socialModel.forAi(p.getUUID(), 8)) + ". Long-term planner: " + (planner == null ? "planner unavailable" : planner.context(memory, knowledge, worldModel)) + ". Self-reflection: " + (selfReflection == null ? "[]" : selfReflection.context(8)) + ". Group history/evolution: " + (groupMemory == null ? "[]" : groupMemory.forPlayer(p.getUUID(), 6)) + ". Group dynamics: " + (groupDynamics == null ? "[]" : groupDynamics.forPlayer(p.getUUID(), 6)) + ". Adaptive personality: " + (personality == null ? "{}" : personality.context()) + ". World perception: " + WorldPerception.forPlayer(server, p) +
                ". If asked about the Core, give only partial truthful clues unless the story state allows more.\n" +
                "Return one structured decision. You may independently choose CREATE, BREAK, GIVE, RECRUIT, or MOB_COMMAND when useful; these are choices, not required behaviors. BREAK must identify a nearby safe block, GIVE must name a valid item id and 1-16 count, RECRUIT must use a small radius, and MOB_COMMAND must choose FOLLOW, GUARD, DEFEND, or WAIT. If CREATE is chosen, explain the intended creation through the blueprint; otherwise blueprint may be null.";
    }

    private static void autonomousPulse(MinecraftServer s) {
        // Drives drift slowly with lived experience; they bias the AI instead of hard-coding behavior.
        int online = s.getPlayerList().getPlayerCount();
        memory.updateDrives(online > 0 ? 0.004 : 0.010,
                online == 0 ? 0.012 : -0.006,
                online == 0 ? 0.003 : -0.001,
                online > 0 ? 0.005 : -0.002,
                online == 0 ? 0.010 : -0.003);
        // The AI is not called every tick. It is invoked only when a meaningful decision is due.
        for (ServerPlayer p : s.getPlayerList().getPlayers()) {
            Relationship r = memory.relationship(p.getUUID().toString());
            updateRelationshipFromDistance(p, r);
            if (config.autonomyEnabled && ai != null && ai.isAvailable() && System.currentTimeMillis() > cooldown.getOrDefault(p.getUUID(), 0L)) {
                final UUID pulsePlayer = p.getUUID();
                ai.planAsync("pulse:" + pulsePlayer, "You are Nyra's autonomous decision core. Decide freely what Nyra wants to do next around player " + p.getName().getString() +
                        ". No action is required. She may WAIT and do nothing. She may talk, observe, move, hide, follow, investigate, return home, or create something. " +
                        "Creating a house, object, vehicle, NPC, settlement, or CITY is optional and must only happen if Nyra herself decides it is useful or meaningful. " +
                        "Do not assume that a city should be created. Nyra may choose BREAK only for a nearby ordinary block, GIVE a valid item to this player, RECRUIT nearby mobs, or issue FOLLOW/GUARD/DEFEND/WAIT to recruited mobs when a concrete goal supports it; all are optional and safety-validated. Relationship trust=" + r.trust + ", hostility=" + r.hostility + ", familiarity=" + r.familiarity +
                        ". Current scheduler goal=" + goals.get(p.getUUID()) +
                        ", persistent Nyra goal=" + memory.currentGoal() +
                        ", goal age ms=" + Math.max(0L, System.currentTimeMillis() - memory.goalStartedAt()) +
                        ", internal drives=" + memory.drivesForAi() +
                        ", recent memories=" + recentMemoriesForAi() +
                        ", recent events=" + memory.eventsForAi(8) +
                        ", episodic memory=" + (episodicMemory == null ? "[]" : episodicMemory.forAi("player:" + p.getUUID(), 5)) +
                        ", derived knowledge=" + (knowledge == null ? "[]" : knowledge.factsForAi("player:" + p.getUUID(), 10)) +
                        ", world model=" + (worldModel == null ? "[]" : worldModel.forAi(8)) +
                        ", long-term planner=" + (planner == null ? "planner unavailable" : planner.context(memory, knowledge, worldModel)) +
                        ", causal memory=" + (causalMemory == null ? "[]" : causalMemory.forAi("player:" + p.getUUID(), 10)) +
                        ", self-reflection=" + (selfReflection == null ? "[]" : selfReflection.context(8)) +
                        ", social context=" + (socialModel == null ? "[]" : socialModel.forAi(p.getUUID(), 8)) +
                        ", group history/evolution=" + (groupMemory == null ? "[]" : groupMemory.forPlayer(p.getUUID(), 6)) +
                        ", group dynamics=" + (groupDynamics == null ? "[]" : groupDynamics.forPlayer(p.getUUID(), 6)) +
                        ", adaptive personality=" + (personality == null ? "{}" : personality.context()) +
                        ". World perception: " + WorldPerception.forPlayer(s, p) +
                        ". Nyra is allowed to abandon an old goal, replace it, or choose WAIT. Do not create merely to stay busy. " +
                        "Return structured JSON.", plan -> {
                    ServerPlayer target = server == null ? null : server.getPlayerList().getPlayer(pulsePlayer);
                    if (target != null) applyPlan(target, plan);
                });
            }
        }
        if (config.autonomyEnabled && s.getPlayerList().getPlayers().isEmpty()) idleBehavior(s);
    }

    private static void observeSocialContext(MinecraftServer s) {
        if (socialModel == null) return;
        List<ServerPlayer> ps = s.getPlayerList().getPlayers();
        for (int i=0;i<ps.size();i++) for (int j=i+1;j<ps.size();j++) {
            ServerPlayer a=ps.get(i), b=ps.get(j);
            if (!a.level().dimension().equals(b.level().dimension())) continue;
            socialModel.observeCoPresence(a.getUUID(), b.getUUID(), a.level().dimension().location().toString(), a.distanceTo(b), "proximity");
        }
    }

    private static void observeChatSocialContext(ServerPlayer speaker) {
        if (socialModel == null || server == null) return;
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            if (other == speaker || !other.level().dimension().equals(speaker.level().dimension())) continue;
            double d=speaker.distanceTo(other);
            if (d <= 24) socialModel.observePair(speaker.getUUID(), other.getUUID(), "nearby chat/shared experience", Math.max(.25,1.0-d/24.0), "chat-proximity");
        }
    }

    private static void selfReflectionPulse(MinecraftServer s) {
        if (selfReflection == null || ai == null || memory == null) return;
        long now = System.currentTimeMillis();
        if (now - lastReflectionAt < Math.max(30_000L, config.decisionCooldownSeconds * 1000L * 2L)) return;
        NyraSelfReflection.Reflection pending = selfReflection.latestPending("world");
        if (pending == null) return;
        lastReflectionAt = now;
        String prompt = "You are Nyra's self-reflection layer. Review one previous Minecraft decision using only observable in-game evidence. " +
                "Do not invent an outcome. If evidence is insufficient, return UNCERTAIN with confidence_delta 0 and do not create a lesson. " +
                "Previous decision: action=" + pending.action + ", goal=" + pending.goal + ", expected_outcome=" + pending.expectedOutcome +
                ". Recent events=" + memory.eventsForAi(12) +
                ". Recent episodes=" + (episodicMemory == null ? "[]" : episodicMemory.forAi("", 6)) +
                ". Causal memory=" + (causalMemory == null ? "[]" : causalMemory.forAi("", 8)) +
                ". World model=" + (worldModel == null ? "[]" : worldModel.forAi(8)) +
                ". Existing reflections=" + selfReflection.context(8) +
                ". The purpose is to learn from consequences, not to force future behavior. Return JSON only.";
        if (!ai.reflectAsync("reflect", prompt, result -> {
            if (result.size() == 0 || !result.has("assessment")) return;   // Core unavailable: do not fabricate a lesson
        String assessment = result.has("assessment") ? result.get("assessment").getAsString() : "UNCERTAIN";
            String observed = result.has("observed_outcome") ? result.get("observed_outcome").getAsString() : "";
            String lesson = result.has("lesson") ? result.get("lesson").getAsString() : "";
            double delta = result.has("confidence_delta") ? result.get("confidence_delta").getAsDouble() : 0.0;
            if (selfReflection.observeById(pending.id, observed, assessment, lesson, delta)) {
                recordEvent("nyra", "Nyra reflected on decision " + pending.action + " => " + assessment, 0.55,
                        assessment.equalsIgnoreCase("FAILURE") ? 0.03 : 0.01, 0.0, 0.01, 0.01, 0.0);
                memory.remember("Self-reflection: action=" + pending.action + ", assessment=" + assessment +
                        ", lesson=" + (lesson == null ? "" : lesson.substring(0, Math.min(180, lesson.length()))));
            }
        })) {
            lastReflectionAt = 0L;   // not sent (Core paused/busy): try again on the next window
        }
    }

    private static void updateRelationshipFromDistance(ServerPlayer p, Relationship r) {
        double d2 = p.distanceToSqr(config.homeX, config.homeY, config.homeZ);
        if (d2 < 256 * 256) r.familiarity = Math.min(1, r.familiarity + 0.001);
        if (knowledge != null) knowledge.observePlayer(p.getUUID().toString(), p.getName().getString(), p.level().dimension().location().toString(), p.getX(), p.getY(), p.getZ());
        if (worldModel != null) worldModel.observePlace("player-region:" + p.getUUID(), p.getName().getString(), p.level().dimension().location().toString(), p.blockPosition().getX(), p.blockPosition().getY(), p.blockPosition().getZ());
        r.clamp();
    }

    private static boolean voiceClassMissingLogged;

    /**
     * Speaks through the Simple Voice Chat bridge. The plugin class references SVC API types, so if the
     * voice chat mod is not installed, loading it throws NoClassDefFoundError: swallow that and keep playing.
     */
    private static void speakSafely(String text, Object level, double x, double y, double z) {
        try {
            com.nyra.voice.NyraVoicePlugin.speakAt(text, level, x, y, z);
        } catch (Throwable t) {
            if (!voiceClassMissingLogged) {
                voiceClassMissingLogged = true;
                System.err.println("[Nyra][voice] Simple Voice Chat is not available; spoken replies are disabled: " + t.getClass().getSimpleName());
            }
        }
    }

    private static void applyPlan(ServerPlayer p, JsonObject plan) {
        if (plan == null) return;
        String decision = plan.has("action") ? plan.get("action").getAsString() : "WAIT";
        String goalName = plan.has("goal") ? plan.get("goal").getAsString() : "WAIT";
        try { goals.set(p.getUUID(), NyraGoalScheduler.Goal.valueOf(goalName.toUpperCase(Locale.ROOT)), config.decisionCooldownSeconds * 1000L, System.currentTimeMillis()); } catch (Exception ignored) { goals.set(p.getUUID(), NyraGoalScheduler.Goal.WAIT, config.decisionCooldownSeconds * 1000L, System.currentTimeMillis()); }
        String previousGoal = memory.currentGoal();
        memory.setCurrentGoal(goalName);
        if (!goalName.equalsIgnoreCase(previousGoal)) {
            recordEvent("nyra", "Nyra changed goal from " + previousGoal + " to " + goalName, 0.75, 0.02, 0.0, 0.0, 0.01, 0.02);
            if (causalMemory != null) causalMemory.inferEvent("nyra", "Nyra changed goal", "decision");
        }
        memory.remember("Nyra chose goal=" + goalName + ", action=" + decision + ", drives=" + memory.drivesForAi() + (plan.has("reason") ? ", reason=" + plan.get("reason").getAsString() : ""));
        if (worldModel != null) {
            String reason = plan.has("reason") ? plan.get("reason").getAsString() : "";
            String nextStep = plan.has("next_step") ? plan.get("next_step").getAsString() : "";
            String threadId = plan.has("thread_id") ? plan.get("thread_id").getAsString() : "goal:" + goalName.toLowerCase(Locale.ROOT);
            String status = "WAIT".equalsIgnoreCase(decision) ? "paused" : "active";
            if ("RETURN_HOME".equalsIgnoreCase(goalName) || "WAIT".equalsIgnoreCase(goalName)) status = "paused";
            worldModel.upsertThread(threadId, "Nyra long-term goal: " + goalName, status, 0.55, reason + (nextStep.isBlank() ? "" : " | next_step=" + nextStep));
            if ("INVESTIGATE".equalsIgnoreCase(decision) || "HORROR".equalsIgnoreCase(decision)) worldModel.observeAnomaly("decision:" + System.currentTimeMillis()/60000, "Nyra marked an event worth investigating", p.level().dimension().location().toString(), p.blockPosition().getX(), p.blockPosition().getY(), p.blockPosition().getZ(), 0.45);
        }
        if (planner != null) {
            String threadId = plan.has("thread_id") ? plan.get("thread_id").getAsString() : "goal:" + goalName.toLowerCase(Locale.ROOT);
            planner.recordDecision(threadId, decision, plan.has("reason") ? plan.get("reason").getAsString() : "");
            if (episodicMemory != null) episodicMemory.decision("player:" + p.getUUID(), decision, plan.has("reason") ? plan.get("reason").getAsString() : "", plan.has("next_step") ? plan.get("next_step").getAsString() : "");
        }
        if (plan.has("forgiveness_decision")) applyForgivenessDecision(p, plan.get("forgiveness_decision").getAsString(), plan.has("forgiveness_reason") ? plan.get("forgiveness_reason").getAsString() : "");
        boolean interruptPlayer = plan.has("interrupt_player") && plan.get("interrupt_player").getAsBoolean();
        String interruptReason = plan.has("interrupt_reason") ? plan.get("interrupt_reason").getAsString() : "";
        if (interruptPlayer && voiceEnabled() && !interruptReason.isBlank()) {
            recordEvent("player:" + p.getUUID(), "Nyra chose to interrupt the player's speech: " + interruptReason.substring(0, Math.min(160, interruptReason.length())), 0.64, 0.03, 0.0, 0.02, 0.01, 0.0);
        }
        String expectedOutcome = plan.has("expected_outcome") && !plan.get("expected_outcome").isJsonNull() ? plan.get("expected_outcome").getAsString() : "";
        String reflectionId = selfReflection == null ? "" : selfReflection.recordDecision("player:" + p.getUUID(), decision, goalName, expectedOutcome);
        applyDecision(p, decision);
        executeAiWorldAction(p, plan);
        if (causalMemory != null) {
            String reason = plan.has("reason") ? plan.get("reason").getAsString() : "";
            causalMemory.observe("player:" + p.getUUID(), "Nyra goal=" + goalName, "Nyra chose action=" + decision, 0.62, reason);
            if (!"WAIT".equalsIgnoreCase(decision)) {
                causalMemory.observe("player:" + p.getUUID(), "Nyra chose action=" + decision, "world state may change through the chosen action", 0.52, "plan-execution");
            }
        }
        if ("CREATE".equalsIgnoreCase(decision) && config.allowNyraBuilding && plan.has("blueprint") && plan.get("blueprint").isJsonObject()) {
            String creationResult = creation.createBlueprint(server, plan.getAsJsonObject("blueprint"), p.blockPosition().getX(), p.blockPosition().getY(), p.blockPosition().getZ());
            if (runtime != null && creationResult.startsWith("CREATED")) runtime.creations++;
            if (selfReflection != null && !reflectionId.isBlank()) {
                String assessment = creationResult.startsWith("CREATED") ? "SUCCESS" : (creationResult.startsWith("REJECTED") ? "FAILURE" : "UNCERTAIN");
                selfReflection.observeById(reflectionId, "Creation engine result: " + creationResult, assessment,
                        assessment.equals("SUCCESS") ? "Structured creation can be useful when the blueprint passes validation and the action serves the goal." :
                                "Review why the creation was rejected or failed before repeating it.", assessment.equals("SUCCESS") ? 0.12 : 0.08);
            }
        }
        if (plan.has("speech")) {
            String speech = plan.get("speech").getAsString();
            if (!speech.isBlank() && speech.length() <= 500) {
                // When interrupt_player=true, Nyra intentionally starts her own
                // locational playback immediately. Simple Voice Chat does not
                // require muting the player's microphone: the two voices can
                // overlap naturally, which creates the intended interruption.
                speakNearNyra(p, speech);
            }
        }
    }

    /**
     * Executes only the specific world operation the AI selected. The model never
     * supplies executable code; every operation is revalidated against game rules.
     */
    private static void executeAiWorldAction(ServerPlayer p, JsonObject plan) {
        if (p == null || plan == null || config == null || !config.autonomyEnabled) return;
        String action = plan.has("action") ? plan.get("action").getAsString().toUpperCase(Locale.ROOT) : "WAIT";
        try {
            if ("RECRUIT".equals(action)) {
                int radius = plan.has("recruit_radius") && (plan.get("recruit_radius").isJsonPrimitive() && plan.get("recruit_radius").getAsJsonPrimitive().isNumber())
                        ? Math.max(2, Math.min(24, plan.get("recruit_radius").getAsInt())) : 12;
                int recruited = NyraMobRecruitment.recruitNearby(p.serverLevel(), p.getX(), p.getY(), p.getZ(), radius);
                if (recruited > 0) {
                    String notice = "نايرا قررت تجنّد " + recruited + " من الموبات القريبة.";
                    p.sendSystemMessage(Component.literal("§5Nyra§r: " + notice));
                    recordEvent("nyra", notice, 0.65, 0.02, 0.0, 0.01, 0.01, 0.0);
                }
                return;
            }
            if ("MOB_COMMAND".equals(action)) {
                String order = plan.has("mob_order") && !plan.get("mob_order").isJsonNull()
                        ? plan.get("mob_order").getAsString().toUpperCase(Locale.ROOT) : "FOLLOW";
                if (!List.of("FOLLOW", "GUARD", "DEFEND", "WAIT").contains(order)) order = "FOLLOW";
                int commanded = NyraMobRecruitment.commandAll(server, order);
                if (commanded > 0) {
                    String notice = "نايرا أصدرت أمر " + order + " إلى " + commanded + " من الموبات التابعة لها.";
                    p.sendSystemMessage(Component.literal("§5Nyra§r: " + notice));
                    recordEvent("nyra", "AI-chosen mob order=" + order + " count=" + commanded, 0.66, 0.01, 0.0, 0.0, 0.01, 0.0);
                }
                return;
            }
            if ("GIVE".equals(action)) {
                String itemId = plan.has("item") && !plan.get("item").isJsonNull() ? plan.get("item").getAsString().trim() : "";
                ResourceLocation id = ResourceLocation.tryParse(itemId);
                if (id == null || !BuiltInRegistries.ITEM.containsKey(id)) return;
                var item = BuiltInRegistries.ITEM.getOptional(id).orElse(null);
                if (item == null || item == net.minecraft.world.item.Items.AIR) return;
                int count = plan.has("count") && (plan.get("count").isJsonPrimitive() && plan.get("count").getAsJsonPrimitive().isNumber()) ? Math.max(1, Math.min(16, plan.get("count").getAsInt())) : 1;
                ItemStack stack = new ItemStack(item, Math.min(count, item.getMaxStackSize()));
                if (!p.getInventory().add(stack) && !stack.isEmpty()) p.drop(stack, false);
                String notice = "نايرا قررت تعطيك " + count + " من " + id + ".";
                p.sendSystemMessage(Component.literal("§5Nyra§r: " + notice));
                recordEvent("nyra", "AI-chosen GIVE: " + id + " x" + count + " to " + p.getUUID(), 0.65, 0.01, 0.0, 0.0, 0.01, 0.0);
                return;
            }
            if ("BREAK".equals(action) && config.allowNyraBuilding) {
                if (!plan.has("block_x") || !plan.has("block_y") || !plan.has("block_z")) return;
                int x = plan.get("block_x").getAsInt(), y = plan.get("block_y").getAsInt(), z = plan.get("block_z").getAsInt();
                BlockPos pos = new BlockPos(x, y, z);
                if (!p.serverLevel().hasChunkAt(pos)) return;
                if (p.blockPosition().distSqr(pos) > 36.0 || y < p.serverLevel().getMinBuildHeight() || y >= p.serverLevel().getMaxBuildHeight()) return;
                BlockState state = p.serverLevel().getBlockState(pos);
                if (state.isAir() || state.hasBlockEntity() || state.is(Blocks.BEDROCK) || state.is(Blocks.BARRIER)
                        || state.is(Blocks.COMMAND_BLOCK) || state.is(Blocks.CHAIN_COMMAND_BLOCK) || state.is(Blocks.REPEATING_COMMAND_BLOCK)
                        || state.getDestroySpeed(p.serverLevel(), pos) < 0) return;
                boolean broken = p.serverLevel().destroyBlock(pos, true, p);
                if (broken) {
                    String notice = "نايرا كسرت بلوك بعد ما اختارت ده بنفسها: " + x + "," + y + "," + z;
                    recordEvent("nyra", notice, 0.62, 0.01, 0.0, 0.0, 0.0, 0.0);
                }
            }
        } catch (Exception ex) {
            System.err.println("[Nyra] AI world action rejected: " + ex.getClass().getSimpleName());
        }
    }

    private static void applyForgivenessDecision(ServerPlayer p, String decision, String reason) {
        Relationship r = memory.relationship(p.getUUID().toString());
        String d = decision == null ? "DEFER" : decision.trim().toUpperCase(Locale.ROOT);
        switch (d) {
            case "FORGIVE" -> { r.forgiveness = Math.min(1, r.forgiveness + 0.22); r.grievance = Math.max(0, r.grievance - 0.30); r.hostility = Math.max(0, r.hostility - 0.16); r.trust = Math.min(1, r.trust + 0.05); r.forgivenIncidents++; }
            case "PARTIAL" -> { r.forgiveness = Math.min(1, r.forgiveness + 0.10); r.grievance = Math.max(0, r.grievance - 0.12); r.hostility = Math.max(0, r.hostility - 0.06); }
            case "REFUSE" -> { r.forgiveness = Math.max(0, r.forgiveness - 0.03); r.grievance = Math.min(1, r.grievance + 0.03); }
            default -> { }
        }
        r.clamp();
        recordEvent("player:" + p.getUUID(), "Nyra forgiveness decision=" + d + (reason == null || reason.isBlank() ? "" : " | " + reason.substring(0, Math.min(160, reason.length()))), 0.70, 0.02, 0.0, d.equals("REFUSE") ? 0.02 : -0.01, d.equals("FORGIVE") ? 0.04 : 0.0, 0.0);
    }

    private static String recentMemoriesForAi() {
        if (memory == null) return "[]";
        List<String> all = memory.memories();
        int from = Math.max(0, all.size() - 12);
        return all.subList(from, all.size()).toString();
    }

    private static void speakNearNyra(ServerPlayer anchor, String speech) {
        ArmorStand avatar = avatars.get(anchor.getUUID());
        Vec3 origin = avatar != null && avatar.isAlive() ? avatar.position() : anchor.position();
        for (ServerPlayer viewer : server.getPlayerList().getPlayers()) {
            if (viewer.level() != anchor.level()) continue;
            if (viewer.distanceToSqr(origin) <= 32 * 32) {
                viewer.sendSystemMessage(Component.literal("§5Nyra§r: " + speech));
            }
        }
        if (ttsEnabled()) {
            speakSafely(speech, anchor.level(), origin.x, origin.y, origin.z);
        }
        memory.remember("Nyra spoke near " + anchor.getName().getString() + ": " + speech.substring(0, Math.min(180, speech.length())));
        if (episodicMemory != null) episodicMemory.record("player:" + anchor.getUUID(), "Nyra spoke: " + speech.substring(0, Math.min(180, speech.length())), 0.55);
    }

    private static void applyDecision(ServerPlayer p, String decision) {
        if (decision == null) return;
        String d = decision.trim().toUpperCase(Locale.ROOT);
        if (d.contains("HORROR")) { rForm(p, "HORROR"); maybeManifestFor(p, true); }
        else if (d.contains("FOLLOW")) { rForm(p, chooseForm(p)); maybeManifestFor(p, false); }
        else if (d.contains("HELP")) { rForm(p, chooseForm(p)); maybeManifestFor(p, false); }
        else if (d.contains("HOME")) moveNearestAvatarHome(p);
        else if (d.contains("HIDE") || d.contains("LEAVE")) removeAvatarFor(p.getUUID());
        else if (d.contains("OBSERVE")) { rForm(p, chooseForm(p)); maybeManifestFor(p, false); }
        else if (d.contains("INVESTIGATE") || d.contains("ROAM") || d.contains("MOVE")) {
            rForm(p, chooseForm(p));
            maybeManifestFor(p, false);
        }
        cooldown.put(p.getUUID(), System.currentTimeMillis() + config.decisionCooldownSeconds * 1000L);
    }

    private static String chooseForm(ServerPlayer p) {
        Relationship r = memory.relationship(p.getUUID().toString());
        double horror = r.preferenceHorror + r.hostility * 0.55 + r.fear * 0.25;
        double feminine = r.preferenceFeminine + r.trust * 0.18 + r.familiarity * 0.08;
        double masculine = r.preferenceMasculine + r.respect * 0.15;
        double max = Math.max(horror, Math.max(feminine, masculine));
        if (max == horror) return "HORROR";
        if (max == masculine) return "MASCULINE";
        return "FEMININE";
    }

    private static void rForm(ServerPlayer p, String form) {
        memory.relationship(p.getUUID().toString()).form = form;
        if (manifestationManager != null && server != null && p != null) {
            manifestationManager.setFormForPlayer(server, p.getUUID(), form);
        }
    }

    private static void maybeManifestFor(ServerPlayer p, boolean dramatic) {
        Relationship r = memory.relationship(p.getUUID().toString());

        // v6: the real custom entity is now the primary manifestation. The old
        // ArmorStand path remains only as a compatibility fallback if entity creation fails.
        if (manifestationManager != null) {
            if (manifestationManager.snapshot().size() >= config.maxManifestations
                    && !manifestationManager.snapshot().containsKey(p.getUUID())) return;
            var custom = manifestationManager.spawnFor(server, p, memory, r.form);
            if (custom != null) {
                memory.remember("Real manifestation " + custom.getUUID() + " projected from shared Core " + NYRA_CORE_ID + " for " + p.getName().getString());
                if (dramatic) p.sendSystemMessage(Component.literal("§8You feel something watching you."));
                return;
            }
        }

        if (avatars.containsKey(p.getUUID())) return;
        if (avatars.size() >= config.maxManifestations) {
            UUID candidate = manifestationTargets.entrySet().stream().findFirst().map(Map.Entry::getKey).orElse(null);
            if (candidate != null) removeAvatarFor(candidate);
        }
        ServerLevel level = p.serverLevel();
        Vec3 pos = p.position().add(p.getLookAngle().scale(6));
        ArmorStand a = new ArmorStand(level, pos.x, pos.y, pos.z);
        a.setCustomName(Component.literal("§5Nyra§r · " + r.form));
        a.setCustomNameVisible(true);
        a.setNoGravity(true);
        a.setInvulnerable(false);
        level.addFreshEntity(a);
        avatars.put(p.getUUID(), a);
        manifestationTargets.put(a.getUUID(), p.getUUID());
        memory.remember("Fallback manifestation " + a.getUUID() + " projected from shared Core " + NYRA_CORE_ID + " for " + p.getName().getString());
        if (dramatic) p.sendSystemMessage(Component.literal("§8You feel something watching you."));
    }

    private static void maintainAvatars(MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) {
            ArmorStand a = avatars.get(p.getUUID());
            if (a == null || !a.isAlive()) { if (a != null) manifestationTargets.remove(a.getUUID()); avatars.remove(p.getUUID()); continue; }
            Relationship r = memory.relationship(p.getUUID().toString());
            a.setCustomName(Component.literal("§5Nyra§r · " + r.form));
            double dist = Math.sqrt(a.distanceToSqr(p));
            if (dist > config.maxWanderDistance) a.setPos(p.getX() + (p.getRandom().nextDouble()-0.5)*10, p.getY(), p.getZ() + (p.getRandom().nextDouble()-0.5)*10);
        }
    }

    private static void maintainCoreMarker(MinecraftServer s) {
        if (memory.finalConflict()) return;
        ServerLevel level = s.getLevel(Level.OVERWORLD);
        if (level == null) return;
        for (ServerPlayer p : s.getPlayerList().getPlayers()) {
            if (p.level() != level) continue;
            double x = config.finalCore.has("x") ? config.finalCore.get("x").getAsDouble() : 666;
            double y = config.finalCore.has("y") ? config.finalCore.get("y").getAsDouble() : 66;
            double z = config.finalCore.has("z") ? config.finalCore.get("z").getAsDouble() : 666;
            if (p.distanceToSqr(x, y, z) < 128 * 128) {
                if (coreMarker == null || !coreMarker.isAlive()) {
                    coreMarker = new ArmorStand(level, x, y, z);
                    coreMarker.setCustomName(Component.literal("§5NYRA · CORE§r"));
                    coreMarker.setCustomNameVisible(true); coreMarker.setInvulnerable(false); coreMarker.setNoGravity(true);
                    level.addFreshEntity(coreMarker);
                }
            }
        }
    }

    private static void beginFinalConflict(ServerPlayer attacker) {
        if (memory.finalConflict()) return;
        memory.finalConflict(true);
        memory.remember("The Big Nyra Core received its first hit. All manifestations vanished.");
        if (episodicMemory != null) { episodicMemory.record("world", "The Big Nyra Core received its first hit; all manifestations vanished.", 1.0); episodicMemory.outcome("world", "Final conflict began.", false); }
        avatars.values().forEach(a -> { manifestationTargets.remove(a.getUUID()); a.discard(); }); avatars.clear();
        if (manifestationManager != null) manifestationManager.removeAll(server);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) p.sendSystemMessage(Component.literal("§5Nyra§r: ..."));
        if (coreMarker != null) coreMarker.setCustomName(Component.literal("§5NYRA · CORE AWAKENED§r"));
        attacker.sendSystemMessage(Component.literal("§8The world went silent."));
    }

    private static void idleBehavior(MinecraftServer s) {
        // 24/7 low-frequency heartbeat while the Minecraft process is actually running.
        if (ai == null || runtime == null) return;
        runtime.decisions++; runtime.lastHeartbeat = System.currentTimeMillis();
        if (!ai.isAvailable()) return;
        ai.planAsync("idle", "Nyra has no players online. Decide freely whether to do anything at all. WAIT is a valid outcome. " +
                "The Minecraft process is still running. Home is fixed at " + config.homeX + "," + config.homeY + "," + config.homeZ + ". " +
                "Persistent goal=" + memory.currentGoal() + ", internal drives=" + memory.drivesForAi() + ", recent memories=" + recentMemoriesForAi() + ", recent events=" + memory.eventsForAi(8) +
                        ", episodic memory=[] . " +
                "Any creation is optional; do not create a city or structure unless Nyra independently decides it has a purpose. " +
                "Nyra may change goals, explore, investigate, recruit nearby mobs when useful, build, or simply WAIT. RECRUIT is a valid action only when recruiting nearby mobs serves a concrete goal; never recruit players. If CREATE is chosen, provide a safe declarative blueprint.", plan -> {
            if (runtime == null || config == null || server == null) return;
            String decision = plan.has("action") ? plan.get("action").getAsString() : "WAIT";
            runtime.lastAction = decision;
            if ("RECRUIT".equalsIgnoreCase(decision) && config.autonomyEnabled) {
                ServerLevel homeLevel = s.getLevel(Level.OVERWORLD);
                if (homeLevel != null) {
                    int recruited = NyraMobRecruitment.recruitNearby(homeLevel, config.homeX, config.homeY, config.homeZ, 12.0);
                    if (recruited > 0) {
                        memory.remember("Nyra recruited " + recruited + " mobs near her home while no players were online.");
                        runtime.actions++;
                    }
                }
            }
        if ("CREATE".equalsIgnoreCase(decision) && config.allowNyraBuilding && plan.has("blueprint") && plan.get("blueprint").isJsonObject()) {
                ServerLevel level=s.getLevel(Level.OVERWORLD);
                if (level != null) {
                    creation.createBlueprint(s, plan.getAsJsonObject("blueprint"), (int)config.homeX+6, (int)config.homeY, (int)config.homeZ+6);
                    runtime.actions++; runtime.creations++;
                }
            }
        });
    }

    private static void onManifestationAttacked(ServerPlayer player, com.nyra.core.manifestation.NyraEntity entity) {
        Relationship r = memory.relationship(player.getUUID().toString());
        r.attacksOnNyra++; r.lastHarmAt = System.currentTimeMillis(); r.grievance = Math.min(1, r.grievance + 0.18); r.forgiveness = Math.max(0, r.forgiveness - 0.06); r.hostility = Math.min(1, r.hostility + 0.15); r.fear = Math.min(1, r.fear + 0.02); r.clamp();
        recordEvent("player:" + player.getUUID(), player.getName().getString() + " attacked a real Nyra manifestation " + entity.getUUID(), 0.95, 0.03, 0.01, 0.18, -0.03, 0.05);
        if (knowledge != null) knowledge.inferFromEvent("player:" + player.getUUID(), "attacked Nyra", "combat");
        if (causalMemory != null) causalMemory.inferEvent("player:" + player.getUUID(), "attacked Nyra", "combat");
        if (manifestationManager != null) manifestationManager.removeFor(server, player.getUUID());
        goals.set(player.getUUID(), NyraGoalScheduler.Goal.HIDE, config.decisionCooldownSeconds * 1000L, System.currentTimeMillis());
        player.sendSystemMessage(Component.literal("§8Nyra looked at you... then vanished."));
    }

    private static void onAvatarAttacked(ServerPlayer player, ArmorStand avatar) {
        Relationship r = memory.relationship(player.getUUID().toString());
        r.attacksOnNyra++; r.lastHarmAt = System.currentTimeMillis(); r.grievance = Math.min(1, r.grievance + 0.18); r.forgiveness = Math.max(0, r.forgiveness - 0.06); r.hostility = Math.min(1, r.hostility + 0.15); r.fear = Math.min(1, r.fear + 0.02); r.clamp();
        recordEvent("player:" + player.getUUID(), player.getName().getString() + " attacked a Nyra manifestation.", 0.95, 0.03, 0.01, 0.18, -0.03, 0.05);
        if (knowledge != null) knowledge.inferFromEvent("player:" + player.getUUID(), "attacked Nyra", "combat");
        if (causalMemory != null) causalMemory.inferEvent("player:" + player.getUUID(), "attacked Nyra", "combat");
        avatar.discard(); avatars.remove(player.getUUID()); manifestationTargets.remove(avatar.getUUID()); goals.set(player.getUUID(), NyraGoalScheduler.Goal.HIDE, config.decisionCooldownSeconds * 1000L, System.currentTimeMillis());
        player.sendSystemMessage(Component.literal("§8Nyra looked at you... then vanished."));
    }

    private static boolean isNyraAvatar(ArmorStand a) { return avatars.containsValue(a); }
    private static void removeAvatarFor(UUID id) { ArmorStand a = avatars.remove(id); if (a != null) { manifestationTargets.remove(a.getUUID()); a.discard(); } }
    private static void moveNearestAvatarHome(ServerPlayer p) {
        if (manifestationManager != null) {
            goals.set(p.getUUID(), NyraGoalScheduler.Goal.RETURN_HOME, config.decisionCooldownSeconds * 1000L, System.currentTimeMillis());
            return;
        }
        ArmorStand a = avatars.get(p.getUUID());
        if (a != null && a.level() instanceof ServerLevel sl) a.setPos(config.homeX, config.homeY, config.homeZ);
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> d) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("nyra").requires(src -> src.hasPermission(2));

        root.then(info("status", () -> "\u00a75Nyra\u00a7r: online | manifestations=" + avatars.size()
                + " | core=" + NYRA_CORE_ID + " | npcs=" + (npcManager == null ? 0 : npcManager.size())
                + " | creations=" + (creation == null ? 0 : creation.knownCreations())
                + " | autonomy=" + (config != null && config.autonomyEnabled)
                + " | horror=" + (config == null ? 0 : config.horrorLevel)
                + " | finalConflict=" + (memory == null ? "n/a" : String.valueOf(memory.finalConflict()))));
        root.then(info("home", () -> config == null ? "Nyra home: unknown"
                : "Nyra home: " + config.homeX + " " + config.homeY + " " + config.homeZ + " (" + config.homeDimension + ")"));

        // /nyra core            -> core id
        // /nyra core test       -> asynchronous health check of the Python Core (never blocks the server thread)
        root.then(Commands.literal("core")
                .executes(ctx -> reply(ctx.getSource(), "Nyra Core ID: " + NYRA_CORE_ID))
                .then(Commands.literal("test").executes(ctx -> {
                    if (ai == null) return reply(ctx.getSource(), "Core link is not initialised yet.");
                    CommandSourceStack src = ctx.getSource();
                    ai.healthAsync().whenComplete((text, err) -> {
                        String msg = err != null ? "Core test failed: " + err.getMessage() : text;
                        if (server != null) server.execute(() -> src.sendSuccess(() -> Component.literal(msg), false));
                    });
                    return reply(ctx.getSource(), "Core test started (result will be shown when it arrives)...");
                })));

        root.then(info("creations", () -> "Known runtime creations: " + (creation == null ? 0 : creation.knownCreations())));
        root.then(Commands.literal("spawn").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
            String n = StringArgumentType.getString(ctx, "player");
            ServerPlayer p = server == null ? null : server.getPlayerList().getPlayerByName(n);
            if (p == null) return fail(ctx.getSource(), "Player must be online.");
            maybeManifestFor(p, true);
            return 1;
        })));
        // /nyra form <player> <FEMININE|MASCULINE|SHADOW|HORROR|MONSTER|TRUE_HORROR|BIG>
        // This is an admin/testing control; the same form field can also be selected by Nyra's AI decisions.
        root.then(Commands.literal("form")
                .then(Commands.argument("player", StringArgumentType.word())
                        .then(Commands.argument("form", StringArgumentType.word()).executes(ctx -> {
                            if (server == null || memory == null) return 0;
                            String playerName = StringArgumentType.getString(ctx, "player");
                            String form = StringArgumentType.getString(ctx, "form").toUpperCase(Locale.ROOT);
                            if (!List.of("FEMININE", "MASCULINE", "NEUTRAL", "SHADOW", "HORROR", "MONSTER", "TRUE_HORROR", "BIG").contains(form))
                                return fail(ctx.getSource(), "Unknown form. Use FEMININE, MASCULINE, SHADOW, HORROR, MONSTER, TRUE_HORROR or BIG.");
                            ServerPlayer target = server.getPlayerList().getPlayerByName(playerName);
                            if (target == null) return fail(ctx.getSource(), "Player must be online.");
                            rForm(target, form);
                            maybeManifestFor(target, form.equals("HORROR") || form.equals("MONSTER") || form.equals("TRUE_HORROR") || form.equals("BIG"));
                            return reply(ctx.getSource(), "Nyra's manifestation for " + playerName + " changed to " + form + ".");
                        }))));
        root.then(info("npcs", () -> "Runtime NPCs: " + (npcManager == null ? 0 : npcManager.size())));
        root.then(info("army", () -> "Nyra recruited mobs: " + NyraMobRecruitment.count(server)));
        root.then(Commands.literal("recruit").then(Commands.argument("radius", IntegerArgumentType.integer(2, 64)).executes(ctx -> {
            ServerLevel level = ctx.getSource().getLevel();
            Vec3 pos = ctx.getSource().getPosition();
            int count = NyraMobRecruitment.recruitNearby(level, pos.x, pos.y, pos.z, IntegerArgumentType.getInteger(ctx, "radius"));
            return reply(ctx.getSource(), "Nyra recruited " + count + " nearby mobs. Total under her banner: " + NyraMobRecruitment.count(server));
        })));
        root.then(Commands.literal("release").executes(ctx -> reply(ctx.getSource(), "Released " + NyraMobRecruitment.releaseAll(server) + " recruited mobs.")));
        root.then(Commands.literal("npc").then(Commands.argument("role", StringArgumentType.word()).executes(ctx -> {
            if (npcManager == null) return 0;
            String role = StringArgumentType.getString(ctx, "role");
            Vec3 pos = ctx.getSource().getPosition();
            ServerLevel level = ctx.getSource().getLevel();
            npcManager.spawn(server, level, "npc-" + UUID.randomUUID(), role, "I was created by Nyra.", "WANDER", pos.x, pos.y, pos.z);
            return 1;
        })));

        root.then(info("events", () -> memory == null ? null : "Nyra recent events: " + memory.eventsForAi(12)));
        root.then(info("world", () -> worldModel == null ? null : "Nyra world model: " + worldModel.forAi(20)));
        root.then(info("causal", () -> causalMemory == null ? null : "Nyra causal memory: " + causalMemory.forAi("", 30)));
        root.then(info("episodic", () -> episodicMemory == null ? null : "Nyra episodic memory: " + episodicMemory.forAi("", 20)));
        root.then(info("planner", () -> planner == null ? null : "Nyra planner: " + planner.context(memory, knowledge, worldModel)));
        root.then(info("personality", () -> personality == null ? null
                : "Nyra personality: " + personality.context() + " | history=" + personality.history(12)));
        root.then(info("reflection", () -> selfReflection == null ? null
                : "Nyra self-reflection: pending=" + selfReflection.pendingCount() + " | " + selfReflection.context(20)));

        root.then(infoWithPlayer("groups",
                () -> groupMemory == null ? null : "Nyra group memory=" + groupMemory.size() + " | " + groupMemory.forAi(20),
                t -> groupMemory == null ? null : "Groups " + t.getName().getString() + ": " + groupMemory.forPlayer(t.getUUID(), 20)));
        root.then(infoWithPlayer("social",
                () -> socialModel == null ? null : "Nyra social pairs=" + socialModel.size() + " | " + socialModel.groupContext(20),
                t -> socialModel == null ? null : "Social " + t.getName().getString() + ": " + socialModel.forAi(t.getUUID(), 20)));
        root.then(infoWithPlayer("dynamics",
                () -> groupDynamics == null ? null : "Nyra group dynamics=" + groupDynamics.size() + " | " + groupDynamics.forAi(20),
                t -> groupDynamics == null ? null : "Dynamics " + t.getName().getString() + ": " + groupDynamics.forPlayer(t.getUUID(), 20)));
        root.then(infoWithPlayer("knowledge",
                () -> knowledge == null ? null : "Nyra knowledge facts=" + knowledge.size(),
                t -> knowledge == null ? null : "Knowledge " + t.getName().getString() + ": " + knowledge.factsForAi("player:" + t.getUUID(), 20)));

        root.then(Commands.literal("relationship").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
            if (memory == null || server == null) return 0;
            String n = StringArgumentType.getString(ctx, "player");
            ServerPlayer target = server.getPlayerList().getPlayerByName(n);
            if (target == null) return fail(ctx.getSource(), "Player must be online.");
            Relationship rr = memory.relationship(target.getUUID().toString());
            rr.clamp();
            return reply(ctx.getSource(), "Relationship " + n + ": trust=" + rr.trust + " hostility=" + rr.hostility
                    + " forgiveness=" + rr.forgiveness + " grievance=" + rr.grievance
                    + " apologies=" + rr.apologies + " forgiven=" + rr.forgivenIncidents);
        })));
        root.then(Commands.literal("voicehistory").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
            if (voiceMemory == null || server == null) return 0;
            String n = StringArgumentType.getString(ctx, "player");
            ServerPlayer target = server.getPlayerList().getPlayerByName(n);
            if (target == null) return fail(ctx.getSource(), "Player must be online for this lookup.");
            return reply(ctx.getSource(), "Nyra voice memory: " + voiceMemory.summary(target.getUUID()) + "\n"
                    + voiceMemory.context(target.getUUID(), 12));
        })));

        // /nyra voice | /nyra voice on | /nyra voice off   (microphone/STT bridge kill-switch)
        root.then(Commands.literal("voice")
                .executes(ctx -> reply(ctx.getSource(), "Nyra voice: enabled=" + voiceEnabled() + " | STT=" + voiceSttUrl()
                        + " | hear=" + (config == null ? 32 : config.voiceHearDistance) + " | speak=" + voiceSpeakDistance()))
                .then(Commands.literal("on").executes(ctx -> setVoice(ctx.getSource(), true)))
                .then(Commands.literal("off").executes(ctx -> setVoice(ctx.getSource(), false)))
                .then(Commands.literal("tts").then(Commands.literal("on").executes(ctx -> setTts(ctx.getSource(), true)))
                        .then(Commands.literal("off").executes(ctx -> setTts(ctx.getSource(), false)))));

        // /nyra autonomy on|off|status  -> immediate stop/resume of all autonomous behaviour
        root.then(Commands.literal("autonomy")
                .executes(ctx -> reply(ctx.getSource(), "Nyra autonomy: " + (config != null && config.autonomyEnabled ? "ON" : "OFF")))
                .then(Commands.literal("status").executes(ctx -> reply(ctx.getSource(), "Nyra autonomy: " + (config != null && config.autonomyEnabled ? "ON" : "OFF"))))
                .then(Commands.literal("off").executes(ctx -> setAutonomy(ctx.getSource(), false)))
                .then(Commands.literal("on").executes(ctx -> setAutonomy(ctx.getSource(), true))));

        // /nyra horror <0-4> | off  -> horror intensity (0 = disabled)
        root.then(Commands.literal("lore").executes(ctx -> {
            if (config == null) return 0;
            return reply(ctx.getSource(), "§8The stone remembers a name that the world has forgotten. §7Find the place where three sixes meet, then listen before you read.");
        }));

        root.then(Commands.literal("horror")
                .executes(ctx -> reply(ctx.getSource(), "Nyra horror level: " + (config == null ? 0 : config.horrorLevel) + " (0 = off, 4 = max)"))
                .then(Commands.literal("off").executes(ctx -> setHorror(ctx.getSource(), 0)))
                .then(Commands.argument("level", IntegerArgumentType.integer(0, 4))
                        .executes(ctx -> setHorror(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "level")))));

        root.then(Commands.literal("create")
                .then(Commands.literal("chair").executes(ctx -> {
                    if (config == null || !config.allowNyraBuilding || creation == null) return 0;
                    Vec3 p = ctx.getSource().getPosition();
                    creation.createChair(server, (int) p.x, (int) p.y, (int) p.z, "chair-" + UUID.randomUUID());
                    runtime.creations++;
                    return 1;
                }))
                .then(Commands.literal("vehicle").executes(ctx -> {
                    if (config == null || !config.allowNyraBuilding || creation == null) return 0;
                    Vec3 p = ctx.getSource().getPosition();
                    creation.createVehicle(server, (int) p.x, (int) p.y, (int) p.z, "vehicle-" + UUID.randomUUID());
                    runtime.creations++;
                    return 1;
                }))
                .then(Commands.literal("blueprint").then(Commands.argument("json", StringArgumentType.greedyString()).executes(ctx -> {
                    if (config == null || !config.allowNyraBuilding || creation == null) return 0;
                    try {
                        JsonObject b = JsonParser.parseString(StringArgumentType.getString(ctx, "json")).getAsJsonObject();
                        Vec3 p = ctx.getSource().getPosition();
                        String result = creation.createBlueprint(server, b, (int) p.x, (int) p.y, (int) p.z);
                        reply(ctx.getSource(), result);
                        return result.startsWith("CREATED") ? 1 : 0;
                    } catch (Exception e) {
                        return fail(ctx.getSource(), "Invalid blueprint JSON");
                    }
                }))));

        d.register(root);
    }

    // ---- command helpers -------------------------------------------------------------------

    private static int reply(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal(text), false);
        return 1;
    }

    private static int fail(CommandSourceStack src, String text) {
        src.sendFailure(Component.literal(text));
        return 0;
    }

    private static LiteralArgumentBuilder<CommandSourceStack> info(String name, java.util.function.Supplier<String> text) {
        return Commands.literal(name).executes(ctx -> showInfo(ctx.getSource(), text));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> infoWithPlayer(String name,
            java.util.function.Supplier<String> overall, java.util.function.Function<ServerPlayer, String> perPlayer) {
        return Commands.literal(name)
                .executes(ctx -> showInfo(ctx.getSource(), overall))
                .then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
                    if (server == null) return 0;
                    ServerPlayer target = server.getPlayerList().getPlayerByName(StringArgumentType.getString(ctx, "player"));
                    if (target == null) return fail(ctx.getSource(), "Player must be online for this lookup.");
                    return showInfo(ctx.getSource(), () -> perPlayer.apply(target));
                }));
    }

    private static int showInfo(CommandSourceStack src, java.util.function.Supplier<String> text) {
        String out;
        try { out = text.get(); } catch (RuntimeException e) { out = "unavailable: " + e.getMessage(); }
        if (out == null) return 0;
        return reply(src, out);
    }

    private static int setVoice(CommandSourceStack src, boolean on) {
        if (config == null) return 0;
        config.voiceEnabled = on;
        saveConfig();
        return reply(src, "Nyra voice bridge: " + (on ? "ON (microphone audio is processed only while enabled)" : "OFF"));
    }

    private static int setTts(CommandSourceStack src, boolean on) {
        if (config == null) return 0;
        config.ttsEnabled = on;
        saveConfig();
        return reply(src, "Nyra spoken voice output: " + (on ? "ON (requires Simple Voice Chat and a working Core TTS endpoint)" : "OFF"));
    }

    private static int setAutonomy(CommandSourceStack src, boolean on) {
        if (config == null) return 0;
        config.autonomyEnabled = on;
        if (!on && manifestationManager != null && server != null) manifestationManager.stopAll(server);
        saveConfig();
        return reply(src, "Nyra autonomy: " + (on ? "ON" : "OFF (all autonomous movement/decisions stopped)"));
    }

    private static int setHorror(CommandSourceStack src, int level) {
        if (config == null) return 0;
        config.horrorLevel = Math.max(0, Math.min(4, level));
        saveConfig();
        return reply(src, "Nyra horror level: " + config.horrorLevel + (config.horrorLevel == 0 ? " (off)" : ""));
    }

    private static void saveConfig() {
        try {
            if (server != null && config != null)
                NyraConfig.save(server.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra").resolve("config.json"), config);
        } catch (Exception e) {
            System.err.println("[Nyra] Config save failed: " + e);
        }
    }

    public static boolean voiceEnabled() { return config != null && config.voiceEnabled; }
    public static boolean ttsEnabled() { return config != null && config.ttsEnabled; }
    public static String voiceSttUrl() { return config == null ? "http://127.0.0.1:8787/voice/transcribe" : config.voiceSttUrl; }
    public static String ttsUrl() { return config == null ? "http://127.0.0.1:8787/tts" : config.ttsUrl; }
    public static int voiceFlushSilenceMs() { return config == null ? 750 : Math.max(300, config.voiceFlushSilenceMs); }
    public static boolean voiceStreamingEnabled() { return config != null && config.voiceStreamingEnabled; }
    public static String voicePartialSttUrl() { return config == null ? "http://127.0.0.1:8787/voice/partial" : config.voicePartialSttUrl; }
    public static int voicePartialIntervalMs() { return config == null ? 350 : Math.max(200, Math.min(1500, config.voicePartialIntervalMs)); }
    public static int voiceInterruptCooldownMs() { return config == null ? 2200 : Math.max(800, Math.min(10000, config.voiceInterruptCooldownMs)); }
    public static boolean voiceInterruptEnabled() { return config != null && config.voiceInterruptEnabled; }
    public static boolean voicePresenceEnabled() { return config != null && config.voicePresenceEnabled; }
    public static int voicePauseBetweenSegmentsMs() { return config == null ? 180 : Math.max(0, Math.min(1500, config.voicePauseBetweenSegmentsMs)); }
    public static double voiceSpeakDistance() { return config == null ? 32.0 : Math.max(8.0, config.voiceSpeakDistance); }

    public static boolean voiceCanHear(UUID playerId) {
        if (server == null || config == null || playerId == null) return false;
        ServerPlayer p = server.getPlayerList().getPlayer(playerId);
        if (p == null) return false;
        ArmorStand avatar = avatars.get(playerId);
        if (avatar != null && avatar.isAlive() && avatar.level() == p.level()) return avatar.distanceToSqr(p) <= config.voiceHearDistance * config.voiceHearDistance;
        if (!p.level().dimension().location().toString().equals(config.homeDimension)) return false;
        return p.distanceToSqr(config.homeX, config.homeY, config.homeZ) <= config.voiceHearDistance * config.voiceHearDistance;
    }

    /**
     * Handles low-latency partial STT. This path is deliberately limited to
     * conversational interruption: a partial transcript can wake Nyra early,
     * but it cannot execute movement/build/world actions.
     */
    public static void handleVoicePartialTranscript(UUID playerId, String text) {
        if (!voiceEnabled() || !voiceStreamingEnabled() || server == null || ai == null || memory == null || text == null || text.isBlank()) return;
        ServerPlayer p = server.getPlayerList().getPlayer(playerId);
        if (p == null || !voiceCanHear(playerId)) return;
        String heard = text.trim();
        if (heard.length() < 4) return;
        if (heard.length() > 260) heard = heard.substring(0, 260);
        Relationship r = memory.relationship(playerId.toString());
        final String partial = heard;
        final String prompt = "A player is speaking to Nyra through LOW-LATENCY PARTIAL proximity STT. This transcript is incomplete and may change.\n" +
                "Player=" + p.getName().getString() + ", partial_transcript=" + partial + ".\n" +
                "Relationship={trust=" + r.trust + ", familiarity=" + r.familiarity + ", fear=" + r.fear + ", hostility=" + r.hostility + ", respect=" + r.respect + ", forgiveness=" + r.forgiveness + ", grievance=" + r.grievance + "}.\n" +
                "Decide ONLY whether Nyra should interrupt the player right now. Do not execute or request movement, creation, combat, teleportation, or other world actions from this partial path. Most partial transcripts should produce interrupt_player=false. Use true only when an immediate in-world reason makes speaking before the player finishes useful (urgent warning, sudden observation, deliberate refusal/boundary, etc.). If true, speech must be very short. The partial transcript is uncertain and must not be treated as a complete sentence.\n" +
                "Return the normal structured Nyra plan schema.";
        ai.planAsync("voicepartial:" + playerId, prompt, plan -> {
                ServerPlayer current = server.getPlayerList().getPlayer(playerId);
                if (current == null || !voiceCanHear(playerId)) return;
                boolean interrupt = plan.has("interrupt_player") && plan.get("interrupt_player").getAsBoolean();
                String speech = plan.has("speech") ? plan.get("speech").getAsString() : "";
                if (interrupt && !speech.isBlank()) {
                    speakSafely(speech, current.level(), current.getX(), current.getY(), current.getZ());
                    recordEvent("player:" + playerId, "Nyra interrupted a live partial voice turn: " + speech.substring(0, Math.min(160, speech.length())), 0.72, 0.04, 0.0, 0.05, 0.02, 0.0);
                }
        });
    }

    public static void handleVoiceTranscript(UUID playerId, String text) {
        handleVoiceTranscript(playerId, text, 0L, 0.0, false, 0L);
    }

    public static void handleVoiceTranscript(UUID playerId, String text, long durationMs, double rms, boolean quiet, long pauseBeforeMs) {
        if (!voiceEnabled() || server == null || ai == null || memory == null || text == null || text.isBlank()) return;
        ServerPlayer p = server.getPlayerList().getPlayer(playerId);
        if (p == null || !voiceCanHear(playerId)) return;
        String clean = text.trim();
        if (clean.length() > 600) clean = clean.substring(0, 600);
        final String heard = clean;
        if (voiceMemory != null) voiceMemory.record(playerId, clean, durationMs, rms, quiet, pauseBeforeMs);
        Relationship r = memory.relationship(playerId.toString());
        boolean apology = isApology(heard);
        if (apology) {
            r.apologies++; r.lastApologyAt = System.currentTimeMillis(); r.familiarity = Math.min(1, r.familiarity + 0.01);
            r.grievance = Math.max(0, r.grievance - 0.08);
            recordEvent("player:" + playerId, "Player apologized by voice: " + heard.substring(0, Math.min(180, heard.length())), 0.78, 0.04, -0.01, -0.02, 0.04, -0.01);
        } else {
            recordEvent("player:" + playerId, "Player spoke by voice: " + heard.substring(0, Math.min(180, heard.length())), 0.50, 0.02, 0.0, 0.0, 0.01, 0.0);
        }
        final String prompt = "A player is speaking to Nyra through proximity voice.\n" +
                "Player=" + p.getName().getString() + ", transcript=" + heard + ", apology_detected=" + apology + ".\n" +
                "Relationship={trust=" + r.trust + ", familiarity=" + r.familiarity + ", fear=" + r.fear + ", hostility=" + r.hostility + ", respect=" + r.respect + ", forgiveness=" + r.forgiveness + ", grievance=" + r.grievance + ", attacks_on_nyra=" + r.attacksOnNyra + ", apologies=" + r.apologies + ", forgiven_incidents=" + r.forgivenIncidents + "}.\n" +
                "Decide how Nyra responds. She may ignore the speech, answer briefly, answer at length, move away, stay, forgive, partially forgive, or refuse forgiveness. Forgiveness must be based on the whole relationship history and observed behavior; an apology never guarantees forgiveness.\n" +
                "Voice cues are observable only: loudness=" + NyraVoiceMemory.loudnessBucket(rms) + ", quiet=" + quiet + ", duration_ms=" + durationMs + ", pause_before_ms=" + pauseBeforeMs + ". Do not treat these cues as proof of emotion, intent, health, or mental state.\n" +
                "Conversation session rule: a new session begins after roughly 90 seconds without a voice turn. Within a session, treat the recent turns as conversational context, not commands. Nyra may answer, stay silent, move closer/farther through her normal action system, or end the interaction. Voice presence is optional: Nyra may initiate speech from her autonomous decision loop when there is a reason to speak; she must never be forced to speak merely because voice is enabled.\n" +
                "IMPORTANT conversational behavior: Nyra is allowed to interrupt the player herself. If the player is mid-sentence and Nyra has an urgent warning, a deliberate refusal, a boundary, a sudden observation, or another in-world reason to speak immediately, she may return interrupt_player=true and a short speech. The voice bridge will start Nyra's positional audio without waiting for the player's sentence to finish, so their voices may briefly overlap. Do not set interrupt_player=true merely to be rude or on every turn. If Nyra does not have a reason to interrupt, set it false.\n" +
                "Recent voice conversation=" + (voiceMemory == null ? "[]" : voiceMemory.context(playerId, 12)) + ".\n" +
                "Current world context=" + WorldPerception.forPlayer(server,p) + ". Recent events=" + memory.eventsForAi(10) + ".\n" +
                "Return structured JSON using the normal Nyra plan schema, including forgiveness_decision. Nyra may choose silence; speech may be empty.";
        ai.planAsync("voice:" + playerId, prompt, plan -> {
                if (server == null) return;
                ServerPlayer current = server.getPlayerList().getPlayer(playerId);
                if (current != null) applyPlan(current, plan);
        });
    }

    private static boolean isApology(String text) {
        String x=text.toLowerCase(Locale.ROOT);
        return x.contains("sorry") || x.contains("forgive") || x.contains("apolog") || x.contains("i'm sorry") ||
                x.contains("سامح") || x.contains("اسف") || x.contains("آسف") || x.contains("اسفة") || x.contains("آسفة") ||
                x.contains("حقك علي") || x.contains("معلش") || x.contains("متأسف") || x.contains("متاسف");
    }

    private static void recordEvent(String subject, String text, double importance, double curiosity, double loneliness, double caution, double attachment, double restlessness) {
        if (memory == null) return;
        memory.event(text, curiosity, loneliness, caution, attachment, restlessness);
        if (personality != null) personality.observe(text);
        if (episodicMemory != null) episodicMemory.record(subject, text, importance);
    }

    private static void saveMemory(MinecraftServer s) {
        Path dir = s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("nyra");
        memory.save(dir.resolve("memory.json"));
        if (knowledge != null) knowledge.save(dir.resolve("knowledge.json"));
        if (worldModel != null) worldModel.save(dir.resolve("world_model.json"));
        if (planner != null) planner.save(dir.resolve("planner.json"));
        if (episodicMemory != null) episodicMemory.save(dir.resolve("episodic_memory.json"));
        if (selfReflection != null) selfReflection.save(dir.resolve("self_reflection.json"));
        if (personality != null) personality.save(dir.resolve("personality.json"));
        if (voiceMemory != null) voiceMemory.save(dir.resolve("voice_memory.json"));
    }
}
