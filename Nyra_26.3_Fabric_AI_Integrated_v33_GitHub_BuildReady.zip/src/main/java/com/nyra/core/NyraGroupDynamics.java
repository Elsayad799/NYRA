package com.nyra.core;

import com.google.gson.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Longitudinal group-dynamics model. It stores only observable Minecraft behavior.
 * Role labels are hypotheses with confidence, never facts about motives or identity.
 */
public final class NyraGroupDynamics {
    public static final class RoleHypothesis {
        public String role;
        public double confidence;
        public long observations;
        public String evidence = "";
    }

    public static final class GroupDynamics {
        public String groupId;
        public List<String> members = new ArrayList<>();
        public String activity = "UNKNOWN";
        public double activityConfidence;
        public long observations;
        public long lastSeen;
        public double tempo;
        public double cohesion;
        public final Map<String, RoleHypothesis> roles = new LinkedHashMap<>();
        public final LinkedList<String> episodes = new LinkedList<>();
    }

    private static final class Sample {
        double x, y, z;
        long at;
        int dimensionHash;
    }

    private final Map<String, GroupDynamics> groups = new LinkedHashMap<>();
    private final Map<String, Sample> samples = new HashMap<>();
    private static final int MAX_GROUPS = 1000;
    private static final int MAX_EPISODES = 24;

    public synchronized void observeCluster(List<ServerPlayer> players, String source) {
        if (players == null || players.size() < 2 || players.size() > 16) return;
        List<ServerPlayer> ps = new ArrayList<>(players);
        ps.sort(Comparator.comparing(p -> p.getUUID().toString()));
        List<String> ids = new ArrayList<>();
        for (ServerPlayer p : ps) ids.add(p.getUUID().toString());
        String id = groupId(ids);
        long now = System.currentTimeMillis();
        GroupDynamics g = groups.computeIfAbsent(id, k -> { GroupDynamics x = new GroupDynamics(); x.groupId=k; return x; });
        boolean continuing = g.lastSeen > 0 && now - g.lastSeen <= 90_000L;
        g.members = new ArrayList<>(ids);
        g.observations++;
        g.lastSeen = now;

        double totalSpeed = 0;
        int movers = 0;
        int near = 0;
        for (ServerPlayer p : ps) {
            String pid = p.getUUID().toString();
            Sample prev = samples.get(pid);
            double speed = 0;
            if (prev != null && prev.dimensionHash == p.level().dimension().hashCode()) {
                double d = Math.sqrt(Math.pow(p.getX()-prev.x,2) + Math.pow(p.getY()-prev.y,2) + Math.pow(p.getZ()-prev.z,2));
                long dt = Math.max(1, now-prev.at);
                speed = Math.min(1.0, d / Math.max(0.25, dt / 1000.0) / 8.0);
                if (d >= 0.7) movers++;
            }
            totalSpeed += speed;
            Sample s = new Sample(); s.x=p.getX(); s.y=p.getY(); s.z=p.getZ(); s.at=now; s.dimensionHash=p.level().dimension().hashCode();
            samples.put(pid, s);
        }
        for (int i=0;i<ps.size();i++) for (int j=i+1;j<ps.size();j++) {
            if (ps.get(i).level().dimension().equals(ps.get(j).level().dimension()) && ps.get(i).distanceTo(ps.get(j)) <= 12.0) near++;
        }
        int pairs = ps.size() * (ps.size()-1) / 2;
        double cohesion = pairs == 0 ? 0 : (double)near / pairs;
        double tempo = totalSpeed / ps.size();
        g.tempo = smooth(g.tempo, tempo, 0.30);
        g.cohesion = smooth(g.cohesion, cohesion, 0.30);

        String activity = tempo > .18 ? (cohesion < .45 ? "TRAVEL" : "EXPLORATION") : "IDLE";
        if (g.activity.equals(activity)) g.activityConfidence = clamp(g.activityConfidence + .03);
        else { g.activity = activity; g.activityConfidence = .35; addEpisode(g, now + " | activity=" + activity + " | source=" + clip(source,24)); }
        if (!continuing) addEpisode(g, now + " | episode-start members=" + ids.size());

        updateRoles(g, ps, movers);
        while (groups.size() > MAX_GROUPS) groups.remove(groups.keySet().iterator().next());
        pruneSamples(now);
    }

    public synchronized void recordCombat(Collection<UUID> participants) {
        if (participants == null || participants.size() < 2) return;
        Set<String> ids = new HashSet<>(); for (UUID u : participants) if (u != null) ids.add(u.toString());
        long now=System.currentTimeMillis();
        for (GroupDynamics g : groups.values()) {
            int overlap=0; for(String id:ids) if(g.members.contains(id)) overlap++;
            if (overlap >= 2 && now-g.lastSeen <= 45_000L) {
                g.activity="COMBAT"; g.activityConfidence=clamp(Math.max(g.activityConfidence,.55)+.08);
                addEpisode(g, now + " | activity=COMBAT | participants=" + overlap);
            }
        }
    }

    private void updateRoles(GroupDynamics g, List<ServerPlayer> ps, int movers) {
        long now=System.currentTimeMillis();
        // Leader-like: a player repeatedly remains ahead while others stay close enough to form a cluster.
        for (ServerPlayer candidate : ps) {
            int followers=0; double ahead=0;
            for (ServerPlayer other:ps) if(other!=candidate) {
                double d=candidate.distanceTo(other);
                if(d <= 12) followers++;
                if(candidate.getDeltaMovement().length() > other.getDeltaMovement().length()+0.03) ahead += 1;
            }
            if(followers >= Math.max(1, ps.size()/2) && ahead >= Math.max(1, ps.size()/3))
                bumpRole(g, candidate.getUUID().toString(), "LEADER_LIKE", .08, "repeatedly moves ahead while cluster stays near");
        }
        // Anchor-like: low movement while most of the group moves around them.
        for(ServerPlayer p:ps) {
            Sample s=samples.get(p.getUUID().toString());
            double own=0;
            if(s!=null) own=Math.min(1, p.getDeltaMovement().length()/0.18);
            if(own < .25 && movers >= Math.max(1, ps.size()/2))
                bumpRole(g,p.getUUID().toString(),"ANCHOR_LIKE",.06,"remains comparatively stationary while others move");
        }
        // Scout-like: comparatively mobile and farther from the group, but still within the observed cluster.
        for(ServerPlayer p:ps) {
            double avg=0; for(ServerPlayer o:ps) if(o!=p) avg+=p.distanceTo(o); avg/=Math.max(1,ps.size()-1);
            if(avg >= 8 && p.getDeltaMovement().length() > .04)
                bumpRole(g,p.getUUID().toString(),"SCOUT_LIKE",.06,"repeatedly occupies the outer edge while moving");
        }
        for(RoleHypothesis r:g.roles.values()) { r.confidence=clamp(r.confidence*.995); r.observations++; }
    }

    private static void bumpRole(GroupDynamics g,String player,String role,double delta,String evidence) {
        String key=player+"|"+role; RoleHypothesis r=g.roles.computeIfAbsent(key,k->{RoleHypothesis x=new RoleHypothesis();x.role=role;return x;});
        r.confidence=clamp(r.confidence+delta); r.evidence=evidence;
    }

    public synchronized String forAi(int limit) {
        List<GroupDynamics> list=new ArrayList<>(groups.values()); list.sort(Comparator.comparingLong((GroupDynamics g)->g.lastSeen).reversed());
        int n=Math.min(Math.max(1,limit),list.size()); List<String> out=new ArrayList<>();
        for(int i=0;i<n;i++) out.add(format(list.get(i)));
        return out.toString();
    }

    public synchronized String forPlayer(UUID player,int limit) {
        if(player==null) return "[]"; String id=player.toString(); List<GroupDynamics> list=new ArrayList<>();
        for(GroupDynamics g:groups.values()) if(g.members.contains(id)) list.add(g);
        list.sort(Comparator.comparingLong((GroupDynamics g)->g.lastSeen).reversed()); int n=Math.min(Math.max(1,limit),list.size());
        List<String> out=new ArrayList<>(); for(int i=0;i<n;i++) out.add(format(list.get(i))); return out.toString();
    }
    public synchronized int size(){return groups.size();}

    private static String format(GroupDynamics g){
        List<String> roleOut=new ArrayList<>();
        for(Map.Entry<String,RoleHypothesis> e:g.roles.entrySet()) if(e.getValue().confidence>=.25)
            roleOut.add(e.getKey()+"="+e.getValue().role+":"+fmt(e.getValue().confidence));
        return "group="+g.groupId+" members="+g.members+" activity="+g.activity+" activityConfidence="+fmt(g.activityConfidence)+
                " tempo="+fmt(g.tempo)+" cohesion="+fmt(g.cohesion)+" roles="+roleOut+" episodes="+g.episodes;
    }
    private static String groupId(List<String> ids){return "g-"+UUID.nameUUIDFromBytes(String.join("|",ids).getBytes(StandardCharsets.UTF_8));}
    private static double smooth(double a,double b,double rate){return a==0?b:a+(b-a)*rate;}
    private static double clamp(double v){return Math.max(0,Math.min(1,Double.isFinite(v)?v:0));}
    private static String fmt(double v){return String.format(Locale.ROOT,"%.2f",v);}
    private static String clip(String s,int n){String x=s==null?"":s.replace('\n',' ').trim();return x.length()<=n?x:x.substring(0,n);}
    private static void addEpisode(GroupDynamics g,String line){g.episodes.addLast(line);while(g.episodes.size()>MAX_EPISODES)g.episodes.removeFirst();}
    private void pruneSamples(long now){samples.entrySet().removeIf(e->now-e.getValue().at>120_000L);}

    public synchronized void save(Path file){
        try{if(file.getParent()!=null)Files.createDirectories(file.getParent()); JsonObject root=new JsonObject();root.add("groups",new Gson().toJsonTree(groups));Files.writeString(file,new GsonBuilder().setPrettyPrinting().create().toJson(root),StandardCharsets.UTF_8);}
        catch(Exception e){System.err.println("[Nyra] Group dynamics save failed: "+e);}
    }
    public static NyraGroupDynamics load(Path file){
        NyraGroupDynamics d=new NyraGroupDynamics();
        try{if(!Files.exists(file))return d;JsonObject root=JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if(root.has("groups")&&root.get("groups").isJsonObject())for(var e:root.getAsJsonObject("groups").entrySet()){
                GroupDynamics g=new Gson().fromJson(e.getValue(),GroupDynamics.class); if(g==null||g.groupId==null||g.members==null||g.members.size()<2)continue;
                g.activity=g.activity==null?"UNKNOWN":g.activity;g.activityConfidence=clamp(g.activityConfidence);g.tempo=clamp(g.tempo);g.cohesion=clamp(g.cohesion);
                if(g.roles==null)continue; if(g.episodes==null) { /* defensive Gson compatibility */ }
                for(RoleHypothesis r:g.roles.values()) if(r!=null) r.confidence=clamp(r.confidence);
                d.groups.put(g.groupId,g);
            }
        }catch(Exception e){System.err.println("[Nyra] Group dynamics load failed: "+e);} return d;
    }
}
