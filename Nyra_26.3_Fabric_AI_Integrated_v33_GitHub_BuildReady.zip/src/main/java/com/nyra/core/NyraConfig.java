package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public final class NyraConfig {
    public boolean enabled = true;
    public String coreUrl = "http://127.0.0.1:8787";
    public int tickIntervalSeconds = 12;
    public int decisionCooldownSeconds = 20;
    public double homeX = -666, homeY = 64, homeZ = -666;
    public String homeDimension = "minecraft:overworld";
    public int maxManifestations = 8;
    public double maxWanderDistance = 64;
    public boolean allowNyraDamageToPlayers = true;
    public boolean allowNyraBuilding = true;
    public boolean allowWorldTimeControl = false;
    public boolean ttsEnabled = false;
    public String ttsUrl = "http://127.0.0.1:8787/tts";
    public boolean voiceEnabled = false;
    public String voiceSttUrl = "http://127.0.0.1:8787/voice/transcribe";
    public double voiceHearDistance = 32.0;
    public double voiceSpeakDistance = 32.0;
    public int voiceFlushSilenceMs = 750;
    public boolean voiceStreamingEnabled = false;
    public String voicePartialSttUrl = "http://127.0.0.1:8787/voice/partial";
    public int voicePartialIntervalMs = 350;
    public int voiceInterruptCooldownMs = 2200;
    public boolean voiceInterruptEnabled = true;
    public boolean voicePresenceEnabled = true;
    public int voicePauseBetweenSegmentsMs = 180;
    public int maxCreationBlocksPerMinute = 4096;
    public JsonObject finalCore = new JsonObject();

    public static NyraConfig load(Path path) {
        try {
            Files.createDirectories(path.getParent());
            if (!Files.exists(path)) {
                NyraConfig c = new NyraConfig();
                c.finalCore.addProperty("x", 29999900); c.finalCore.addProperty("y", 80); c.finalCore.addProperty("z", 29999900);
                c.finalCore.addProperty("dimension", "minecraft:overworld");
                write(path, c);
                return c;
            }
            JsonObject o = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
            NyraConfig c = new NyraConfig();
            if (o.has("enabled")) c.enabled=o.get("enabled").getAsBoolean();
            if (o.has("core_url")) c.coreUrl=o.get("core_url").getAsString();
            if (o.has("tick_interval_seconds")) c.tickIntervalSeconds=o.get("tick_interval_seconds").getAsInt();
            if (o.has("decision_cooldown_seconds")) c.decisionCooldownSeconds=o.get("decision_cooldown_seconds").getAsInt();
            if (o.has("home")) { JsonObject h=o.getAsJsonObject("home"); c.homeX=h.get("x").getAsDouble(); c.homeY=h.get("y").getAsDouble(); c.homeZ=h.get("z").getAsDouble(); }
            if (o.has("home_dimension")) c.homeDimension=o.get("home_dimension").getAsString();
            if (o.has("max_manifestations")) c.maxManifestations=o.get("max_manifestations").getAsInt();
            if (o.has("max_wander_distance")) c.maxWanderDistance=o.get("max_wander_distance").getAsDouble();
            if (o.has("allow_nyra_damage_to_players")) c.allowNyraDamageToPlayers=o.get("allow_nyra_damage_to_players").getAsBoolean();
            if (o.has("allow_nyra_building")) c.allowNyraBuilding=o.get("allow_nyra_building").getAsBoolean();
            if (o.has("allow_world_time_control")) c.allowWorldTimeControl=o.get("allow_world_time_control").getAsBoolean();
            if (o.has("tts_enabled")) c.ttsEnabled=o.get("tts_enabled").getAsBoolean();
            if (o.has("tts_url")) c.ttsUrl=o.get("tts_url").getAsString();
            if (o.has("voice_enabled")) c.voiceEnabled=o.get("voice_enabled").getAsBoolean();
            if (o.has("voice_stt_url")) c.voiceSttUrl=o.get("voice_stt_url").getAsString();
            if (o.has("voice_hear_distance")) c.voiceHearDistance=o.get("voice_hear_distance").getAsDouble();
            if (o.has("voice_speak_distance")) c.voiceSpeakDistance=o.get("voice_speak_distance").getAsDouble();
            if (o.has("voice_flush_silence_ms")) c.voiceFlushSilenceMs=o.get("voice_flush_silence_ms").getAsInt();
            if (o.has("voice_streaming_enabled")) c.voiceStreamingEnabled=o.get("voice_streaming_enabled").getAsBoolean();
            if (o.has("voice_partial_stt_url")) c.voicePartialSttUrl=o.get("voice_partial_stt_url").getAsString();
            if (o.has("voice_partial_interval_ms")) c.voicePartialIntervalMs=o.get("voice_partial_interval_ms").getAsInt();
            if (o.has("voice_interrupt_cooldown_ms")) c.voiceInterruptCooldownMs=o.get("voice_interrupt_cooldown_ms").getAsInt();
            if (o.has("voice_interrupt_enabled")) c.voiceInterruptEnabled=o.get("voice_interrupt_enabled").getAsBoolean();
            if (o.has("voice_presence_enabled")) c.voicePresenceEnabled=o.get("voice_presence_enabled").getAsBoolean();
            if (o.has("voice_pause_between_segments_ms")) c.voicePauseBetweenSegmentsMs=o.get("voice_pause_between_segments_ms").getAsInt();
            if (o.has("max_creation_blocks_per_minute")) c.maxCreationBlocksPerMinute=o.get("max_creation_blocks_per_minute").getAsInt();
            c.finalCore=o.has("final_core") ? o.getAsJsonObject("final_core") : new JsonObject();
            if (c.finalCore.size()==0) { c.finalCore.addProperty("x",29999900); c.finalCore.addProperty("y",80); c.finalCore.addProperty("z",29999900); }
            return c;
        } catch (Exception e) { System.err.println("[Nyra] Config load failed: "+e); return new NyraConfig(); }
    }
    private static void write(Path path, NyraConfig c) throws Exception {
        JsonObject o=new JsonObject(); o.addProperty("enabled",c.enabled); o.addProperty("core_url",c.coreUrl);
        o.addProperty("tick_interval_seconds",c.tickIntervalSeconds); o.addProperty("decision_cooldown_seconds",c.decisionCooldownSeconds);
        JsonObject h=new JsonObject(); h.addProperty("x",c.homeX); h.addProperty("y",c.homeY); h.addProperty("z",c.homeZ); o.add("home",h);
        o.addProperty("voice_enabled", c.voiceEnabled); o.addProperty("voice_stt_url", c.voiceSttUrl);
        o.addProperty("voice_hear_distance", c.voiceHearDistance); o.addProperty("voice_speak_distance", c.voiceSpeakDistance); o.addProperty("voice_flush_silence_ms", c.voiceFlushSilenceMs);
        o.addProperty("voice_streaming_enabled", c.voiceStreamingEnabled); o.addProperty("voice_partial_stt_url", c.voicePartialSttUrl); o.addProperty("voice_partial_interval_ms", c.voicePartialIntervalMs); o.addProperty("voice_interrupt_cooldown_ms", c.voiceInterruptCooldownMs);
        o.addProperty("voice_interrupt_enabled", c.voiceInterruptEnabled); o.addProperty("voice_presence_enabled", c.voicePresenceEnabled); o.addProperty("voice_pause_between_segments_ms", c.voicePauseBetweenSegmentsMs);
        o.addProperty("home_dimension",c.homeDimension); o.addProperty("max_manifestations",c.maxManifestations); o.addProperty("max_wander_distance",c.maxWanderDistance);
        o.addProperty("allow_nyra_damage_to_players",c.allowNyraDamageToPlayers); o.addProperty("allow_nyra_building",c.allowNyraBuilding);
        o.addProperty("allow_world_time_control",c.allowWorldTimeControl); o.addProperty("tts_enabled",c.ttsEnabled); o.addProperty("tts_url",c.ttsUrl);
        o.addProperty("max_creation_blocks_per_minute",c.maxCreationBlocksPerMinute); o.add("final_core",c.finalCore);
        Files.writeString(path,new GsonBuilder().setPrettyPrinting().create().toJson(o),StandardCharsets.UTF_8);
    }
}
