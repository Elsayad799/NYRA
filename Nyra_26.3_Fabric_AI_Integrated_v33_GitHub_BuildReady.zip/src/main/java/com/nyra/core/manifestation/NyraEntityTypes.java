package com.nyra.core.manifestation;

import com.nyra.core.NyraMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

/** Server-side registration for the real Nyra manifestation entity. */
public final class NyraEntityTypes {
    public static final ResourceKey<EntityType<?>> NYRA_KEY = ResourceKey.create(
            Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(NyraMod.MOD_ID, "manifestation"));

    public static final EntityType<NyraEntity> NYRA = register(
            NYRA_KEY,
            EntityType.Builder.of(NyraEntity::new, MobCategory.CREATURE)
                    .sized(0.72f, 1.82f)
                    .clientTrackingRange(96)
                    .updateInterval(2)
    );

    private static <T extends net.minecraft.world.entity.Entity> EntityType<T> register(
            ResourceKey<EntityType<?>> key, EntityType.Builder<T> builder) {
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
    }

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(NYRA, NyraEntity.createAttributes());
    }

    private NyraEntityTypes() {}
}
