package com.nyra.core.manifestation;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

/**
 * A physical projection of the single Nyra Core. It deliberately stores no
 * independent memory or personality; the server-side Core owns those.
 */
public final class NyraEntity extends PathfinderMob {
    private static final EntityDataAccessor<String> FORM =
            SynchedEntityData.defineId(NyraEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> CORE_ID =
            SynchedEntityData.defineId(NyraEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> TARGET_ID =
            SynchedEntityData.defineId(NyraEntity.class, EntityDataSerializers.STRING);

    public NyraEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(FORM, "NEUTRAL");
        builder.define(CORE_ID, "");
        builder.define(TARGET_ID, "");
    }

    public String form() { return entityData.get(FORM); }
    public void setForm(String value) { entityData.set(FORM, value == null ? "NEUTRAL" : value); }
    public String coreId() { return entityData.get(CORE_ID); }
    public void setCoreId(String value) { entityData.set(CORE_ID, value == null ? "" : value); }
    public String targetId() { return entityData.get(TARGET_ID); }
    public void setTargetId(String value) { entityData.set(TARGET_ID, value == null ? "" : value); }

    @Override
    protected void registerGoals() {
        // Nyra's real planning is controlled by the shared Core. Vanilla goals
        // are intentionally not added here so the projection cannot become an
        // accidental independent AI.
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }
}
