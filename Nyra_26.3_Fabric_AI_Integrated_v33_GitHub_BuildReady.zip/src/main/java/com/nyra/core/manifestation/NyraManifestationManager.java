package com.nyra.core.manifestation;

import com.nyra.core.NyraMemory;
import com.nyra.core.Relationship;
import com.nyra.core.NyraGoalScheduler;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Keeps physical manifestations tied to one shared Core identity. */
public final class NyraManifestationManager {
    private final UUID coreId;
    private final Map<UUID, UUID> byPlayer = new ConcurrentHashMap<>();
    private final NyraNavigationController navigation = new NyraNavigationController();
    private long tickCounter;

    public NyraManifestationManager(UUID coreId) { this.coreId = coreId; }

    public UUID coreId() { return coreId; }
    public Map<UUID, UUID> snapshot() { return Map.copyOf(byPlayer); }

    /** Applies the shared Core goal to physical projections without creating an independent AI. */
    public void tick(MinecraftServer server, NyraGoalScheduler goals, double homeX, double homeY, double homeZ, double maxDistance) {
        if (server == null) return;
        tickCounter++;
        for (Map.Entry<UUID, UUID> entry : byPlayer.entrySet()) {
            UUID playerId = entry.getKey();
            ServerPlayer player = server.getPlayerList().getPlayer(playerId);
            NyraEntity entity = find(server, entry.getValue());
            if (player == null || entity == null || !entity.isAlive()) {
                if (entity != null) { navigation.stop(entity); entity.discard(); }
                byPlayer.remove(playerId, entry.getValue());
                if (entity != null) navigation.forget(entity.getUUID());
                continue;
            }
            NyraGoalScheduler.Goal goal = goals.get(playerId);
            double distance = entity.distanceTo(player);
            switch (goal) {
                case FOLLOW -> {
                    if (distance > 3.0 && entity.level() == player.level())
                        navigation.follow(entity, player, 1.05, tickCounter);
                }
                case RETURN_HOME -> {
                    if (entity.level() instanceof ServerLevel level && entity.distanceToSqr(homeX, homeY, homeZ) > 9.0)
                        navigation.goTo(entity, new net.minecraft.world.phys.Vec3(homeX, homeY, homeZ), 1.0, tickCounter);
                }
                case HIDE -> {
                    if (distance < 12.0 && entity.level() == player.level()) {
                        double dx = entity.getX() - player.getX();
                        double dz = entity.getZ() - player.getZ();
                        double len = Math.max(0.001, Math.sqrt(dx * dx + dz * dz));
                        double tx = player.getX() + (dx / len) * 14.0;
                        double tz = player.getZ() + (dz / len) * 14.0;
                        navigation.goTo(entity, new net.minecraft.world.phys.Vec3(tx, entity.getY(), tz), 1.15, tickCounter);
                    }
                }
                case ROAM, OBSERVE, INVESTIGATE -> {
                    if (entity.getNavigation().isDone() && entity.getRandom().nextInt(80) == 0) {
                        double radius = Math.min(20.0, Math.max(6.0, maxDistance));
                        double tx = entity.getX() + (entity.getRandom().nextDouble() - 0.5) * radius * 2.0;
                        double tz = entity.getZ() + (entity.getRandom().nextDouble() - 0.5) * radius * 2.0;
                        navigation.goTo(entity, new net.minecraft.world.phys.Vec3(tx, entity.getY(), tz), 0.65, tickCounter);
                    }
                }
                case BUILD, WAIT -> navigation.stop(entity);
            }
            entity.getLookControl().setLookAt(player, 25.0f, 25.0f);
        }
    }

    private NyraEntity find(MinecraftServer server, UUID entityId) {
        for (ServerLevel level : server.getAllLevels()) {
            var e = level.getEntity(entityId);
            if (e instanceof NyraEntity n) return n;
        }
        return null;
    }

    public NyraEntity spawnFor(MinecraftServer server, ServerPlayer player, NyraMemory memory, String form) {
        if (player == null) return null;
        ServerLevel level = player.serverLevel();
        UUID existingId = byPlayer.get(player.getUUID());
        if (existingId != null) {
            var existing = level.getEntity(existingId);
            if (existing instanceof NyraEntity n && n.isAlive()) return n;
            byPlayer.remove(player.getUUID());
        }

        NyraEntity entity = NyraEntityTypes.NYRA.create(level);
        if (entity == null) return null;
        entity.moveTo(player.getX() + 2.0, player.getY(), player.getZ() + 1.5, player.getYRot() + 180.0f, 0.0f);
        entity.setCoreId(coreId.toString());
        entity.setTargetId(player.getUUID().toString());
        entity.setForm(form == null ? "NEUTRAL" : form);
        level.addFreshEntity(entity);
        byPlayer.put(player.getUUID(), entity.getUUID());
        return entity;
    }

    public void removeFor(MinecraftServer server, UUID playerId) {
        UUID entityId = byPlayer.remove(playerId);
        if (entityId == null) return;
        for (ServerLevel level : server.getAllLevels()) {
            var e = level.getEntity(entityId);
            if (e != null) { navigation.stop((NyraEntity) e); e.discard(); return; }
        }
    }

    public void removeAll(MinecraftServer server) {
        for (UUID playerId : byPlayer.keySet().toArray(UUID[]::new)) removeFor(server, playerId);
        byPlayer.clear();
    }
}
