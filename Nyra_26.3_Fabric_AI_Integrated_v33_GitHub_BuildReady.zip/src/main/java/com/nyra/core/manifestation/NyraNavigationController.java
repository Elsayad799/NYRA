package com.nyra.core.manifestation;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Shared-Core movement controller. It does not create an independent AI: it
 * only executes navigation decisions selected by the Nyra Core.
 *
 * The controller deliberately uses Minecraft's native PathfinderMob navigation
 * rather than teleporting Nyra. It also watches for stalled paths and requests
 * a fresh path when the entity stops making progress.
 */
public final class NyraNavigationController {
    private static final int REPATH_INTERVAL_TICKS = 12;
    private static final int STUCK_AFTER_TICKS = 50;
    private static final double MIN_PROGRESS_SQR = 0.09;

    private static final class State {
        long lastPathTick;
        long lastProgressTick;
        Vec3 lastPosition;
        Vec3 target;
    }

    private final Map<UUID, State> states = new ConcurrentHashMap<>();

    public void forget(UUID entityId) {
        states.remove(entityId);
    }

    public void stop(NyraEntity entity) {
        if (entity == null) return;
        entity.getNavigation().stop();
        states.remove(entity.getUUID());
    }

    public void follow(NyraEntity entity, ServerPlayer player, double speed, long tick) {
        if (entity == null || player == null || entity.level() != player.level()) return;
        navigate(entity, player.position(), speed, tick);
    }

    public void goTo(NyraEntity entity, Vec3 target, double speed, long tick) {
        if (entity == null || target == null) return;
        navigate(entity, target, speed, tick);
    }

    private void navigate(NyraEntity entity, Vec3 target, double speed, long tick) {
        State state = states.computeIfAbsent(entity.getUUID(), id -> new State());
        Vec3 current = entity.position();
        if (state.lastPosition == null || current.distanceToSqr(state.lastPosition) >= MIN_PROGRESS_SQR) {
            state.lastPosition = current;
            state.lastProgressTick = tick;
        }

        boolean targetChanged = state.target == null || state.target.distanceToSqr(target) > 4.0;
        boolean stale = tick - state.lastPathTick >= REPATH_INTERVAL_TICKS;
        boolean stuck = tick - state.lastProgressTick >= STUCK_AFTER_TICKS;
        boolean done = entity.getNavigation().isDone();

        if (targetChanged || done || stale || stuck) {
            if (stuck) entity.getNavigation().stop();
            entity.getNavigation().moveTo(target.x, target.y, target.z, Math.max(0.15, speed));
            state.target = target;
            state.lastPathTick = tick;
            state.lastProgressTick = tick;
            state.lastPosition = current;
        }
    }
}
