package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Structured, revisable knowledge derived only from observable in-game events.
 * Confidence is evidence strength, not certainty; newer evidence can revise old facts.
 */
public final class NyraKnowledge {
    public static final class Fact {
        public String subject;
        public String key;
        public String value;
        public double confidence;
        public long firstSeen;
        public long lastSeen;
        public int observations;
        public String source;

        public Fact() {}
        Fact(String subject, String key, String value, double confidence, String source) {
            this.subject = subject; this.key = key; this.value = value;
            this.confidence = clamp(confidence); this.source = source;
            this.firstSeen = this.lastSeen = System.currentTimeMillis(); this.observations = 1;
        }
    }

    private final Map<String, Map<String, Fact>> facts = new LinkedHashMap<>();

    public synchronized void observeFact(String subject, String key, String value, double confidence, String source) {
        if (blank(subject) || blank(key) || blank(value)) return;
        subject = subject.trim(); key = key.trim(); value = value.trim();
        Map<String, Fact> byKey = facts.computeIfAbsent(subject, k -> new LinkedHashMap<>());
        Fact old = byKey.get(key);
        if (old == null) {
            byKey.put(key, new Fact(subject, key, value, confidence, source));
            return;
        }
        // Evidence for the same value accumulates; conflicting evidence revises confidence.
        if (old.value.equalsIgnoreCase(value)) {
            old.confidence = clamp(old.confidence + (1.0 - old.confidence) * clamp(confidence) * 0.35);
        } else {
            double incoming = clamp(confidence);
            double total = Math.max(0.001, old.confidence + incoming);
            if (incoming >= old.confidence * 0.70) {
                old.value = value;
                old.confidence = clamp(incoming / total + old.confidence * 0.15);
            } else {
                old.confidence = clamp(old.confidence * 0.92);
            }
        }
        old.lastSeen = System.currentTimeMillis(); old.observations++; old.source = source == null ? old.source : source;
    }

    public synchronized void inferFromEvent(String subject, String event, String source) {
        if (blank(subject) || blank(event)) return;
        String e = event.toLowerCase(Locale.ROOT);
        if (e.contains("attacked") || e.contains("attack")) {
            observeFact(subject, "behavior", "threatening", 0.82, source);
            observeFact(subject, "nyra_response", "avoidance may be appropriate", 0.62, source);
        } else if (e.contains("threatening chat") || e.contains("kill") || e.contains("قتلك") || e.contains("اقتل")) {
            observeFact(subject, "behavior", "threatening", 0.70, source);
        } else if (e.contains("help") || e.contains("helped") || e.contains("protected") || e.contains("ساعد")) {
            observeFact(subject, "behavior", "helpful", 0.65, source);
        } else if (e.contains("curious") || e.contains("question") || e.contains("سأل") || e.contains("يسأل")) {
            observeFact(subject, "behavior", "curious", 0.60, source);
        }
    }

    public synchronized void observePlayer(String uuid, String name, String dimension, double x, double y, double z) {
        if (blank(uuid)) return;
        String subject = "player:" + uuid;
        if (!blank(name)) observeFact(subject, "name", name, 1.0, "server-observation");
        if (!blank(dimension)) observeFact(subject, "last_dimension", dimension, 0.95, "server-observation");
        String pos = ((int)Math.floor(x / 16.0)) + "," + ((int)Math.floor(y / 8.0)) + "," + ((int)Math.floor(z / 16.0));
        observeFact(subject, "last_region", pos, 0.90, "server-observation");
    }

    public synchronized String factsForAi(String subject, int limit) {
        if (blank(subject)) return "[]";
        Map<String, Fact> map = facts.get(subject);
        if (map == null || map.isEmpty()) return "[]";
        List<Fact> list = new ArrayList<>(map.values());
        list.sort(Comparator.comparingDouble((Fact f) -> f.confidence).reversed().thenComparingLong(f -> -f.lastSeen));
        StringBuilder out = new StringBuilder("[");
        int n = 0, max = Math.max(1, limit);
        for (Fact f : list) {
            if (n++ >= max) break;
            if (out.length() > 1) out.append(", ");
            out.append(f.key).append("=").append(f.value).append(" (confidence=")
               .append(String.format(Locale.ROOT, "%.2f", f.confidence)).append(")");
        }
        return out.append("]").toString();
    }

    public synchronized List<Fact> facts(String subject) {
        Map<String, Fact> map = facts.get(subject);
        return map == null ? List.of() : new ArrayList<>(map.values());
    }

    public synchronized int size() {
        return facts.values().stream().mapToInt(Map::size).sum();
    }

    public synchronized void save(Path file) {
        try {
            if (file.getParent() != null) Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject();
            for (var subject : facts.entrySet()) {
                JsonObject obj = new JsonObject();
                for (var e : subject.getValue().entrySet()) obj.add(e.getKey(), new Gson().toJsonTree(e.getValue()));
                root.add(subject.getKey(), obj);
            }
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        } catch (Exception e) { System.err.println("[Nyra] Knowledge save failed: " + e); }
    }

    public static NyraKnowledge load(Path file) {
        NyraKnowledge k = new NyraKnowledge();
        try {
            if (!Files.exists(file)) return k;
            JsonElement parsed = JsonParser.parseString(Files.readString(file));
            if (!parsed.isJsonObject()) return k;
            Gson gson = new Gson();
            for (var subject : parsed.getAsJsonObject().entrySet()) {
                if (!subject.getValue().isJsonObject()) continue;
                Map<String, Fact> byKey = new LinkedHashMap<>();
                for (var e : subject.getValue().getAsJsonObject().entrySet()) {
                    try {
                        Fact f = gson.fromJson(e.getValue(), Fact.class);
                        if (f != null && !blank(f.key)) { f.confidence = clamp(f.confidence); byKey.put(e.getKey(), f); }
                    } catch (Exception ignored) {}
                }
                if (!byKey.isEmpty()) k.facts.put(subject.getKey(), byKey);
            }
        } catch (Exception e) { System.err.println("[Nyra] Knowledge load failed: " + e); }
        return k;
    }

    private static boolean blank(String s) { return s == null || s.isBlank(); }
    private static double clamp(double v) { return Math.max(0.0, Math.min(1.0, v)); }
}
