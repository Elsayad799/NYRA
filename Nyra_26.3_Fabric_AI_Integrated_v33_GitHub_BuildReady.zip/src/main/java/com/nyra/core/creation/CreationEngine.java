package com.nyra.core.creation;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

/**
 * Safe runtime content layer. The AI supplies data, never executable Java.
 * Content is translated to allow-listed vanilla commands and bounded block edits.
 */
public final class CreationEngine {
    private static final Gson GSON = new Gson();
    private static final Set<String> ALLOWED_BLOCKS = Set.of(
            "minecraft:air", "minecraft:stone", "minecraft:cobblestone", "minecraft:deepslate",
            "minecraft:oak_planks", "minecraft:spruce_planks", "minecraft:dark_oak_planks",
            "minecraft:oak_log", "minecraft:glass", "minecraft:glass_pane", "minecraft:iron_block",
            "minecraft:iron_bars", "minecraft:lantern", "minecraft:sea_lantern", "minecraft:redstone_lamp",
            "minecraft:water", "minecraft:rail", "minecraft:powered_rail", "minecraft:gold_block",
            "minecraft:quartz_block", "minecraft:blackstone", "minecraft:obsidian"
    );
    private final Map<String, Long> created = new ConcurrentHashMap<>();
    private final Map<String, String> blueprints = new ConcurrentHashMap<>();
    private long lastWindow = System.currentTimeMillis();
    private int blocksThisWindow = 0;
    private final int maxBlocksPerMinute;

    public CreationEngine(int maxBlocksPerMinute) {
        this.maxBlocksPerMinute = Math.max(64, Math.min(20000, maxBlocksPerMinute));
    }

    public synchronized String create(MinecraftServer server, String json) {
        try {
            CreationBlueprint b = GSON.fromJson(json, CreationBlueprint.class);
            List<String> errors = CreationValidator.validate(b);
            if (!errors.isEmpty()) return "REJECTED: " + String.join(", ", errors);
            int estimated = estimateBlocks(b);
            if (!consumeBudget(estimated)) return "REJECTED: creation rate limit";
            for (CreationBlueprint.Primitive p : b.primitives) {
                if (!ALLOWED_BLOCKS.contains(p.block)) return "REJECTED: block not allowed: " + p.block;
            }
            for (CreationBlueprint.Primitive p : b.primitives) {
                int x1=b.x+p.x, y1=b.y+p.y, z1=b.z+p.z;
                int x2=x1+p.dx-1, y2=y1+p.dy-1, z2=z1+p.dz-1;
                String command = (p.dx==1 && p.dy==1 && p.dz==1)
                        ? "setblock " + x1 + " " + y1 + " " + z1 + " " + p.block
                        : "fill " + x1 + " " + y1 + " " + z1 + " " + x2 + " " + y2 + " " + z2 + " " + p.block;
                run(server, command);
            }
            created.put(b.id, System.currentTimeMillis());
            blueprints.put(b.id, GSON.toJson(b));
            return "CREATED " + b.id + " blocks=" + estimated;
        } catch (JsonSyntaxException | IllegalArgumentException e) {
            return "REJECTED: invalid blueprint";
        } catch (Exception e) {
            return "FAILED: " + e.getClass().getSimpleName() + ": " + e.getMessage();
        }
    }

    public synchronized String createBlueprint(MinecraftServer server, JsonObject blueprint, int fallbackX, int fallbackY, int fallbackZ) {
        if (blueprint == null) return "REJECTED: blueprint is null";
        if (!blueprint.has("x")) blueprint.addProperty("x", fallbackX);
        if (!blueprint.has("y")) blueprint.addProperty("y", fallbackY);
        if (!blueprint.has("z")) blueprint.addProperty("z", fallbackZ);
        if (!blueprint.has("id")) blueprint.addProperty("id", "ai-" + UUID.randomUUID());
        return create(server, GSON.toJson(blueprint));
    }

    public synchronized String createChair(MinecraftServer server, int x, int y, int z, String id) {
        CreationBlueprint b = new CreationBlueprint(); b.id = id; b.kind = "chair"; b.x=x; b.y=y; b.z=z; b.maxBlocks=16;
        add(b,"minecraft:dark_oak_planks",0,0,0,1,1,1);
        add(b,"minecraft:dark_oak_planks",0,1,0,1,1,1);
        add(b,"minecraft:dark_oak_planks",0,2,0,1,1,1);
        add(b,"minecraft:dark_oak_planks",0,1,1,1,2,1);
        add(b,"minecraft:dark_oak_planks",0,0,1,1,1,1);
        add(b,"minecraft:dark_oak_planks",0,0,0,1,1,1);
        return create(server, GSON.toJson(b));
    }

    public synchronized String createVehicle(MinecraftServer server, int x, int y, int z, String id) {
        CreationBlueprint b = new CreationBlueprint(); b.id=id; b.kind="vehicle"; b.x=x; b.y=y; b.z=z; b.maxBlocks=128;
        for (int dx=0; dx<5; dx++) for (int dz=0; dz<9; dz++) add(b,"minecraft:iron_block",dx,0,dz,1,1,1);
        for (int dx=0; dx<5; dx++) for (int dz=1; dz<8; dz++) add(b,"minecraft:glass",dx,1,dz,1,1,1);
        for (int dx=0; dx<5; dx++) add(b,"minecraft:iron_block",dx,1,0,1,1,1);
        return create(server, GSON.toJson(b));
    }

    public synchronized String createCity(MinecraftServer server, int x, int y, int z, String id) {
        CreationBlueprint b = new CreationBlueprint(); b.id=id; b.kind="city"; b.x=x; b.y=y; b.z=z; b.maxBlocks=4096;
        for (int bx=0; bx<32; bx++) for (int bz=0; bz<32; bz++) if (bx%8==0 || bz%8==0) add(b,"minecraft:stone",bx,0,bz,1,1,1);
        for (int bx=2; bx<30; bx+=8) for (int bz=2; bz<30; bz+=8) {
            for (int yy=0; yy<5; yy++) for (int xx=0; xx<5; xx++) for (int zz=0; zz<5; zz++)
                if (xx==0 || xx==4 || zz==0 || zz==4 || yy==4) add(b,"minecraft:deepslate",bx+xx,yy+1,bz+zz,1,1,1);
            add(b,"minecraft:glass",bx+2,2,bz,1,1,1);
            add(b,"minecraft:glass",bx+2,2,bz+4,1,1,1);
        }
        return create(server, GSON.toJson(b));
    }

    private static void add(CreationBlueprint b, String block, int x,int y,int z,int dx,int dy,int dz) {
        CreationBlueprint.Primitive p=new CreationBlueprint.Primitive(); p.block=block; p.x=x;p.y=y;p.z=z;p.dx=dx;p.dy=dy;p.dz=dz;b.primitives.add(p);
    }

    private int estimateBlocks(CreationBlueprint b) {
        long total=0; for (CreationBlueprint.Primitive p:b.primitives) total += (long)p.dx*p.dy*p.dz;
        return (int)Math.min(Integer.MAX_VALUE,total);
    }

    private boolean consumeBudget(int amount) {
        long now=System.currentTimeMillis();
        if (now-lastWindow>=60000) { lastWindow=now; blocksThisWindow=0; }
        if (amount>maxBlocksPerMinute || blocksThisWindow+amount>maxBlocksPerMinute) return false;
        blocksThisWindow += amount; return true;
    }

    private static void run(MinecraftServer server, String command) {
        CommandSourceStack source = server.createCommandSourceStack().withPermission(4);
        server.getCommands().performPrefixedCommand(source, command);
    }

    public int knownCreations() { return created.size(); }

    public synchronized void save(Path file) {
        try {
            Files.createDirectories(file.getParent());
            var root = new com.google.gson.JsonObject();
            var items = new com.google.gson.JsonArray();
            for (var e : blueprints.entrySet()) {
                var item = new com.google.gson.JsonObject();
                item.addProperty("id", e.getKey());
                item.addProperty("createdAt", created.getOrDefault(e.getKey(), 0L));
                item.add("blueprint", com.google.gson.JsonParser.parseString(e.getValue()));
                items.add(item);
            }
            root.add("creations", items);
            Files.writeString(file, new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        } catch (Exception e) {
            System.err.println("[Nyra] Creation registry save failed: " + e);
        }
    }

    public synchronized void load(Path file) {
        try {
            if (!Files.exists(file)) return;
            var root = com.google.gson.JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (!root.has("creations")) return;
            for (var e : root.getAsJsonArray("creations")) {
                var item = e.getAsJsonObject();
                String id = item.get("id").getAsString();
                blueprints.put(id, item.get("blueprint").toString());
                created.put(id, item.has("createdAt") ? item.get("createdAt").getAsLong() : 0L);
            }
        } catch (Exception e) {
            System.err.println("[Nyra] Creation registry load failed: " + e);
        }
    }

    public synchronized String blueprint(String id) { return blueprints.get(id); }
}
