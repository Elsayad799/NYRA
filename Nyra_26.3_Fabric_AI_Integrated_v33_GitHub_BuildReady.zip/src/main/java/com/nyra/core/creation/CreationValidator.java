package com.nyra.core.creation;

import java.util.*;

public final class CreationValidator {
    private CreationValidator() {}

    public static List<String> validate(CreationBlueprint b) {
        List<String> errors = new ArrayList<>();
        if (b == null) { errors.add("blueprint is null"); return errors; }
        if (b.id == null || b.id.isBlank() || b.id.length() > 64) errors.add("invalid id");
        if (b.kind == null || b.kind.isBlank()) errors.add("invalid kind");
        if (b.primitives == null) errors.add("primitives is null");
        else if (b.primitives.size() > Math.min(4096, Math.max(1, b.maxBlocks))) errors.add("too many primitives");
        if (b.width < 1 || b.width > 64 || b.height < 1 || b.height > 64 || b.depth < 1 || b.depth > 64)
            errors.add("dimensions out of bounds");
        if (b.maxBlocks < 1 || b.maxBlocks > 4096) errors.add("maxBlocks out of bounds");
        if (b.primitives != null) {
            for (CreationBlueprint.Primitive p : b.primitives) {
                if (p == null || p.block == null || !p.block.matches("[a-z0-9_.-]+:[a-z0-9_/.-]+")) {
                    errors.add("invalid block id"); break;
                }
                if (p.dx < 1 || p.dy < 1 || p.dz < 1 || p.dx > 16 || p.dy > 16 || p.dz > 16) {
                    errors.add("primitive size out of bounds"); break;
                }
            }
        }
        return errors;
    }
}
