package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Persistent world model: places, anomalies, creations and long-term threads. */
public final class NyraWorldModel {
    public static final class Place { public String id,name,dimension; public int x,y,z; public long lastSeen; public int observations; }
    public static final class Anomaly { public String id,description,dimension; public int x,y,z; public double confidence; public long firstSeen,lastSeen; public int observations; }
    public static final class ThreadState { public String id,title,status; public double importance; public long updatedAt; public String note; }
    private final Map<String,Place> places = new LinkedHashMap<>();
    private final Map<String,Anomaly> anomalies = new LinkedHashMap<>();
    private final Map<String,ThreadState> threads = new LinkedHashMap<>();

    public synchronized void observePlace(String id,String name,String dimension,int x,int y,int z) {
        if (blank(id)) return; Place p=places.computeIfAbsent(id,k->new Place());
        p.id=id; if(!blank(name))p.name=name; p.dimension=dimension; p.x=x;p.y=y;p.z=z;p.lastSeen=System.currentTimeMillis();p.observations++;
    }
    public synchronized void observeAnomaly(String id,String description,String dimension,int x,int y,int z,double confidence) {
        if(blank(id)||blank(description))return; Anomaly a=anomalies.get(id);
        if(a==null){a=new Anomaly();a.id=id;a.description=description;a.dimension=dimension;a.x=x;a.y=y;a.z=z;a.confidence=clamp(confidence);a.firstSeen=System.currentTimeMillis();anomalies.put(id,a);} else {
            a.confidence=clamp(a.confidence+(1-a.confidence)*clamp(confidence)*0.3); a.description=description; a.dimension=dimension;a.x=x;a.y=y;a.z=z;
        } a.lastSeen=System.currentTimeMillis();a.observations++;
    }
    public synchronized void upsertThread(String id,String title,String status,double importance,String note){
        if(blank(id))return; ThreadState t=threads.computeIfAbsent(id,k->new ThreadState());t.id=id;t.title=title;t.status=status;t.importance=clamp(importance);t.note=note;t.updatedAt=System.currentTimeMillis();
    }
    public synchronized String forAi(int limit){
        StringBuilder s=new StringBuilder("{places:["); int n=0; for(Place p:places.values()){if(n++>=limit)break;s.append(p.name).append("@").append(p.dimension).append(":").append(p.x).append(",").append(p.y).append(",").append(p.z).append("; ");}
        s.append("], anomalies:[");n=0; for(Anomaly a:sortedAnomalies()){if(n++>=limit)break;s.append(a.description).append(" (confidence=").append(String.format(Locale.ROOT,"%.2f",a.confidence)).append(")@").append(a.x).append(",").append(a.y).append(",").append(a.z).append("; ");}
        s.append("], long_term_threads:[");n=0; for(ThreadState t:sortedThreads()){if(n++>=limit)break;s.append(t.id).append("=").append(t.title).append("/").append(t.status).append("/importance=").append(String.format(Locale.ROOT,"%.2f",t.importance)).append("; ");}
        return s.append("]}").toString();
    }
    private List<Anomaly> sortedAnomalies(){List<Anomaly> l=new ArrayList<>(anomalies.values());l.sort(Comparator.comparingDouble((Anomaly a)->a.confidence).reversed());return l;}
    private List<ThreadState> sortedThreads(){List<ThreadState> l=new ArrayList<>(threads.values());l.sort(Comparator.comparingDouble((ThreadState t)->t.importance).reversed().thenComparingLong(t->-t.updatedAt));return l;}
    public synchronized int places(){return places.size();} public synchronized int anomalies(){return anomalies.size();} public synchronized int threads(){return threads.size();}
    public synchronized void save(Path file){try{if(file.getParent()!=null)Files.createDirectories(file.getParent());JsonObject r=new JsonObject();r.add("places",new Gson().toJsonTree(places));r.add("anomalies",new Gson().toJsonTree(anomalies));r.add("threads",new Gson().toJsonTree(threads));Files.writeString(file,new GsonBuilder().setPrettyPrinting().create().toJson(r),StandardCharsets.UTF_8);}catch(Exception e){System.err.println("[Nyra] World model save failed: "+e);}}
    public static NyraWorldModel load(Path file){NyraWorldModel w=new NyraWorldModel();try{if(!Files.exists(file))return w;JsonObject r=JsonParser.parseString(Files.readString(file)).getAsJsonObject();Gson g=new Gson();if(r.has("places"))for(var e:r.getAsJsonObject("places").entrySet())w.places.put(e.getKey(),g.fromJson(e.getValue(),Place.class));if(r.has("anomalies"))for(var e:r.getAsJsonObject("anomalies").entrySet())w.anomalies.put(e.getKey(),g.fromJson(e.getValue(),Anomaly.class));if(r.has("threads"))for(var e:r.getAsJsonObject("threads").entrySet())w.threads.put(e.getKey(),g.fromJson(e.getValue(),ThreadState.class));}catch(Exception e){System.err.println("[Nyra] World model load failed: "+e);}return w;}
    private static boolean blank(String s){return s==null||s.isBlank();}private static double clamp(double v){return Math.max(0,Math.min(1,v));}
}
