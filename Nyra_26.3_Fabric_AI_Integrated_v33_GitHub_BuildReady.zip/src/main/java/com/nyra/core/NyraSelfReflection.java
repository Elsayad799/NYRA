package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Persistent self-reflection for Nyra's shared Core.
 * It records what Nyra expected, what was later observed, and lessons that can
 * influence future decisions. It does not execute actions or force outcomes.
 */
public final class NyraSelfReflection {
    public static final class Reflection {
        public String id = "";
        public String subject = "world";
        public String action = "WAIT";
        public String goal = "WAIT";
        public String expectedOutcome = "";
        public String observedOutcome = "";
        public String assessment = "UNCERTAIN";
        public String lesson = "";
        public double confidence = 0.50;
        public long createdAt = 0L;
        public long reflectedAt = 0L;
        public int observations = 0;
        public boolean pending = true;
    }

    private static final int MAX = 300;
    private final LinkedHashMap<String, Reflection> reflections = new LinkedHashMap<>();

    public synchronized String recordDecision(String subject, String action, String goal, String expectedOutcome) {
        Reflection r = new Reflection();
        long now = System.currentTimeMillis();
        r.id = "reflection:" + Long.toString(now, 36) + ":" + Integer.toHexString(Math.abs(Objects.hash(subject, action, goal, expectedOutcome)));
        r.subject = safe(subject, "world");
        r.action = safe(action, "WAIT").toUpperCase(Locale.ROOT);
        r.goal = safe(goal, "WAIT").toUpperCase(Locale.ROOT);
        r.expectedOutcome = clip(expectedOutcome, 320);
        r.createdAt = now;
        r.confidence = 0.50;
        reflections.put(r.id, r);
        trim();
        return r.id;
    }

    /** Attach observable evidence to the most recent matching pending decision. */
    public synchronized boolean observe(String subject, String observedOutcome, String assessment, String lesson, double confidenceDelta) {
        Reflection r = latestPending(subject);
        if (r == null) return false;
        r.observedOutcome = clip(observedOutcome, 360);
        r.assessment = normalizeAssessment(assessment);
        r.lesson = clip(lesson, 360);
        r.confidence = clamp01(r.confidence + Math.max(-0.30, Math.min(0.30, confidenceDelta)));
        r.observations++;
        r.reflectedAt = System.currentTimeMillis();
        r.pending = !("SUCCESS".equals(r.assessment) || "PARTIAL".equals(r.assessment) || "NEUTRAL".equals(r.assessment) || "FAILURE".equals(r.assessment));
        return true;
    }

    public synchronized boolean observeById(String id, String observedOutcome, String assessment, String lesson, double confidenceDelta) {
        Reflection r = reflections.get(id);
        if (r == null) return false;
        r.observedOutcome = clip(observedOutcome, 360);
        r.assessment = normalizeAssessment(assessment);
        r.lesson = clip(lesson, 360);
        r.confidence = clamp01(r.confidence + Math.max(-0.30, Math.min(0.30, confidenceDelta)));
        r.observations++;
        r.reflectedAt = System.currentTimeMillis();
        r.pending = !("SUCCESS".equals(r.assessment) || "PARTIAL".equals(r.assessment) || "NEUTRAL".equals(r.assessment) || "FAILURE".equals(r.assessment));
        return true;
    }

    public synchronized Reflection latestPending(String subject) {
        String wanted = safe(subject, "world");
        List<Reflection> list = new ArrayList<>(reflections.values());
        Collections.reverse(list);
        for (Reflection r : list) {
            if (r.pending && ("world".equals(wanted) || "world".equals(r.subject) || wanted.equals(r.subject))) return r;
        }
        return null;
    }

    public synchronized Reflection latest() {
        if (reflections.isEmpty()) return null;
        return reflections.values().stream().reduce((a,b) -> b).orElse(null);
    }

    public synchronized String context(int limit) {
        List<Reflection> list = new ArrayList<>(reflections.values());
        list.sort(Comparator.comparingLong((Reflection r) -> r.reflectedAt > 0 ? r.reflectedAt : r.createdAt).reversed());
        StringBuilder out = new StringBuilder("[");
        int n = 0;
        for (Reflection r : list) {
            if (n++ >= Math.max(1, limit)) break;
            if (n > 1) out.append(", ");
            out.append("{id=").append(r.id)
               .append(", action=").append(r.action)
               .append(", goal=").append(r.goal)
               .append(", expected=").append(r.expectedOutcome)
               .append(", observed=").append(r.observedOutcome)
               .append(", assessment=").append(r.assessment)
               .append(", lesson=").append(r.lesson)
               .append(", confidence=").append(String.format(Locale.ROOT, "%.2f", r.confidence))
               .append(", pending=").append(r.pending).append("}");
        }
        return out.append("]").toString();
    }

    public synchronized int pendingCount() {
        int n = 0; for (Reflection r : reflections.values()) if (r.pending) n++; return n;
    }

    public synchronized int size() { return reflections.size(); }

    public synchronized void save(Path file) {
        try {
            if (file.getParent() != null) Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject();
            root.add("reflections", new Gson().toJsonTree(reflections));
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        } catch (Exception e) { System.err.println("[Nyra] Self-reflection save failed: " + e); }
    }

    public static NyraSelfReflection load(Path file) {
        NyraSelfReflection m = new NyraSelfReflection();
        try {
            if (!Files.exists(file)) return m;
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.has("reflections") && root.get("reflections").isJsonObject()) {
                Gson g = new Gson();
                for (var e : root.getAsJsonObject("reflections").entrySet()) {
                    Reflection r = g.fromJson(e.getValue(), Reflection.class);
                    if (r.id == null || r.id.isBlank()) r.id = e.getKey();
                    m.reflections.put(e.getKey(), r);
                }
            }
            m.trim();
        } catch (Exception e) { System.err.println("[Nyra] Self-reflection load failed: " + e); }
        return m;
    }

    private void trim() {
        while (reflections.size() > MAX) reflections.remove(reflections.keySet().iterator().next());
    }
    private static String safe(String s, String fallback) { return s == null || s.isBlank() ? fallback : s.trim(); }
    private static String clip(String s, int max) { String x = s == null ? "" : s.trim(); return x.length() <= max ? x : x.substring(0, max); }
    private static double clamp01(double v) { return Math.max(0, Math.min(1, v)); }
    private static String normalizeAssessment(String s) {
        String x = safe(s, "UNCERTAIN").toUpperCase(Locale.ROOT);
        return Set.of("SUCCESS", "PARTIAL", "NEUTRAL", "FAILURE", "UNCERTAIN").contains(x) ? x : "UNCERTAIN";
    }
}
