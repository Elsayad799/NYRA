package com.nyra.core;

import com.google.gson.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class NyraMemory {
    private final Map<String, Relationship> players = new HashMap<>();
    private final List<String> memories = new ArrayList<>();
    private final List<String> eventLog = new ArrayList<>();
    private boolean finalConflict = false;
    private String currentGoal = "WAIT";
    private long goalStartedAt = 0L;
    private final List<String> goalHistory = new ArrayList<>();
    // Slow-changing internal drives. They influence decisions but never force a specific action.
    private double curiosity = 0.35;
    private double loneliness = 0.10;
    private double caution = 0.45;
    private double attachment = 0.20;
    private double restlessness = 0.25;

    public synchronized Relationship relationship(String uuid) { return players.computeIfAbsent(uuid, k -> new Relationship()); }
    public synchronized Collection<Map.Entry<String, Relationship>> allRelationships() { return new ArrayList<>(players.entrySet()); }
    public synchronized void remember(String text) { if (text == null || text.isBlank()) return; memories.add(text); if (memories.size() > 500) memories.remove(0); }
    public synchronized List<String> memories() { return new ArrayList<>(memories); }
    public synchronized List<String> recentEvents(int limit) {
        int from = Math.max(0, eventLog.size() - Math.max(1, limit));
        return new ArrayList<>(eventLog.subList(from, eventLog.size()));
    }
    public synchronized void event(String text) {
        if (text == null || text.isBlank()) return;
        String entry = System.currentTimeMillis() + " | " + text;
        eventLog.add(entry);
        if (eventLog.size() > 300) eventLog.remove(0);
        remember("EVENT: " + text);
    }
    public synchronized void event(String text, double curiosityDelta, double lonelinessDelta, double cautionDelta, double attachmentDelta, double restlessnessDelta) {
        event(text);
        updateDrives(curiosityDelta, lonelinessDelta, cautionDelta, attachmentDelta, restlessnessDelta);
    }
    public synchronized String eventsForAi(int limit) {
        return String.join(" || ", recentEvents(limit));
    }
    public synchronized boolean finalConflict() { return finalConflict; }
    public synchronized String currentGoal() { return currentGoal; }
    public synchronized void setCurrentGoal(String goal) {
        if (goal == null || goal.isBlank()) goal = "WAIT";
        goal = goal.toUpperCase(Locale.ROOT);
        if (!goal.equals(currentGoal)) {
            currentGoal = goal; goalStartedAt = System.currentTimeMillis();
            goalHistory.add(goal);
            if (goalHistory.size() > 100) goalHistory.remove(0);
        }
    }
    public synchronized long goalStartedAt() { return goalStartedAt; }
    public synchronized List<String> goalHistory() { return new ArrayList<>(goalHistory); }
    public synchronized void finalConflict(boolean v) { finalConflict = v; }
    public synchronized double curiosity() { return curiosity; }
    public synchronized double loneliness() { return loneliness; }
    public synchronized double caution() { return caution; }
    public synchronized double attachment() { return attachment; }
    public synchronized double restlessness() { return restlessness; }
    public synchronized void updateDrives(double curiosityDelta, double lonelinessDelta, double cautionDelta, double attachmentDelta, double restlessnessDelta) {
        curiosity = clamp(curiosity + curiosityDelta); loneliness = clamp(loneliness + lonelinessDelta);
        caution = clamp(caution + cautionDelta); attachment = clamp(attachment + attachmentDelta);
        restlessness = clamp(restlessness + restlessnessDelta);
    }
    public synchronized String drivesForAi() {
        return String.format(Locale.ROOT, "curiosity=%.2f, loneliness=%.2f, caution=%.2f, attachment=%.2f, restlessness=%.2f", curiosity, loneliness, caution, attachment, restlessness);
    }
    private static double clamp(double v) { return Math.max(0.0, Math.min(1.0, v)); }

    public synchronized void save(Path file) {
        try {
            Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject(); root.addProperty("finalConflict", finalConflict);
            root.addProperty("currentGoal", currentGoal);
            root.addProperty("goalStartedAt", goalStartedAt);
            JsonObject drives = new JsonObject();
            drives.addProperty("curiosity", curiosity); drives.addProperty("loneliness", loneliness);
            drives.addProperty("caution", caution); drives.addProperty("attachment", attachment); drives.addProperty("restlessness", restlessness);
            root.add("drives", drives);
            root.add("goalHistory", new Gson().toJsonTree(goalHistory));
            root.add("eventLog", new Gson().toJsonTree(eventLog));
            JsonObject ps = new JsonObject();
            for (var e : players.entrySet()) ps.add(e.getKey(), new Gson().toJsonTree(e.getValue()));
            root.add("players", ps); root.add("memories", new Gson().toJsonTree(memories));
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        } catch (Exception e) { System.err.println("[Nyra] Memory save failed: " + e); }
    }
    public static NyraMemory load(Path file) {
        NyraMemory m = new NyraMemory();
        try {
            if (!Files.exists(file)) return m;
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            m.finalConflict = root.has("finalConflict") && root.get("finalConflict").getAsBoolean();
            m.currentGoal = root.has("currentGoal") ? root.get("currentGoal").getAsString() : "WAIT";
            m.goalStartedAt = root.has("goalStartedAt") ? root.get("goalStartedAt").getAsLong() : 0L;
            if (root.has("drives") && root.get("drives").isJsonObject()) {
                JsonObject d = root.getAsJsonObject("drives");
                m.curiosity = d.has("curiosity") ? clamp(d.get("curiosity").getAsDouble()) : m.curiosity;
                m.loneliness = d.has("loneliness") ? clamp(d.get("loneliness").getAsDouble()) : m.loneliness;
                m.caution = d.has("caution") ? clamp(d.get("caution").getAsDouble()) : m.caution;
                m.attachment = d.has("attachment") ? clamp(d.get("attachment").getAsDouble()) : m.attachment;
                m.restlessness = d.has("restlessness") ? clamp(d.get("restlessness").getAsDouble()) : m.restlessness;
            }
            if (root.has("goalHistory") && root.get("goalHistory").isJsonArray()) for (JsonElement e : root.getAsJsonArray("goalHistory")) m.goalHistory.add(e.getAsString());
            if (root.has("eventLog") && root.get("eventLog").isJsonArray()) for (JsonElement e : root.getAsJsonArray("eventLog")) m.eventLog.add(e.getAsString());
            if (root.has("players")) for (var e : root.getAsJsonObject("players").entrySet()) m.players.put(e.getKey(), new Gson().fromJson(e.getValue(), Relationship.class));
            if (root.has("memories")) for (JsonElement e : root.getAsJsonArray("memories")) m.memories.add(e.getAsString());
        } catch (Exception e) { System.err.println("[Nyra] Memory load failed: " + e); }
        return m;
    }
}
