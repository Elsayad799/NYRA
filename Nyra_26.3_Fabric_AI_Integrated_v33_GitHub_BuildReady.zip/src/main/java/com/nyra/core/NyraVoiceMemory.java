package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Persistent, bounded conversational memory for Nyra's proximity-voice interactions.
 *  Stores observable voice/session metadata only; it does not claim to infer emotions or mental states.
 */
public final class NyraVoiceMemory {
    private static final int MAX_TURNS_PER_PLAYER = 24;
    private static final int MAX_PLAYERS = 256;
    private static final long SESSION_GAP_MS = 90_000L;
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    public void record(UUID playerId, String transcript, long durationMs, double rms, boolean quiet, long pauseBeforeMs) {
        if (playerId == null || transcript == null || transcript.isBlank()) return;
        String id = playerId.toString();
        Session s = sessions.computeIfAbsent(id, k -> new Session());
        synchronized (s) {
            Turn t = new Turn();
            t.text = transcript.substring(0, Math.min(600, transcript.length()));
            t.at = System.currentTimeMillis();
            t.durationMs = Math.max(0, Math.min(30_000, durationMs));
            t.rms = Math.max(0, Math.min(32767, rms));
            t.loudness = loudnessBucket(rms);
            t.quiet = quiet;
            t.pauseBeforeMs = Math.max(0, Math.min(60_000, pauseBeforeMs));
            boolean newSession = s.lastAt == 0 || (t.at - s.lastAt) > SESSION_GAP_MS;
            if (newSession) {
                s.sessionCount++;
                s.sessionStartedAt = t.at;
                s.currentSessionTurns = 0;
            }
            s.currentSessionTurns++;
            t.session = s.sessionCount;
            t.turnIndex = s.currentSessionTurns;
            s.turns.add(t);
            while (s.turns.size() > MAX_TURNS_PER_PLAYER) s.turns.remove(0);
            s.turnCount++;
            s.lastAt = t.at;
        }
        trimPlayers();
    }

    public String context(UUID playerId, int maxTurns) {
        if (playerId == null) return "[]";
        Session s = sessions.get(playerId.toString());
        if (s == null) return "[]";
        synchronized (s) {
            int from = Math.max(0, s.turns.size() - Math.max(1, Math.min(12, maxTurns)));
            JsonArray arr = new JsonArray();
            for (int i = from; i < s.turns.size(); i++) {
                Turn t = s.turns.get(i);
                JsonObject o = new JsonObject();
                o.addProperty("text", t.text);
                o.addProperty("age_seconds", Math.max(0, (System.currentTimeMillis() - t.at) / 1000));
                o.addProperty("duration_ms", t.durationMs);
                o.addProperty("loudness", t.loudness);
                o.addProperty("quiet", t.quiet);
                o.addProperty("pause_before_ms", t.pauseBeforeMs);
                o.addProperty("session", t.session);
                o.addProperty("turn_index", t.turnIndex);
                arr.add(o);
            }
            return arr.toString();
        }
    }

    public String summary(UUID playerId) {
        if (playerId == null) return "No voice history.";
        Session s = sessions.get(playerId.toString());
        if (s == null) return "No voice history.";
        synchronized (s) {
            return "turns=" + s.turnCount + ", retained=" + s.turns.size() + ", sessions=" + s.sessionCount + ", current_session_turns=" + s.currentSessionTurns + ", last_at=" + s.lastAt;
        }
    }

    public void save(Path file) {
        try {
            Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject();
            JsonObject players = new JsonObject();
            for (Map.Entry<String, Session> e : sessions.entrySet()) {
                Session s = e.getValue();
                synchronized (s) {
                    JsonObject so = new JsonObject();
                    so.addProperty("turn_count", s.turnCount);
                    so.addProperty("last_at", s.lastAt);
                    so.addProperty("session_count", s.sessionCount);
                    so.addProperty("session_started_at", s.sessionStartedAt);
                    so.addProperty("current_session_turns", s.currentSessionTurns);
                    JsonArray turns = new JsonArray();
                    for (Turn t : s.turns) turns.add(toJson(t));
                    so.add("turns", turns);
                    players.add(e.getKey(), so);
                }
            }
            root.add("players", players);
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ignored) { }
    }

    public static NyraVoiceMemory load(Path file) {
        NyraVoiceMemory m = new NyraVoiceMemory();
        if (!Files.exists(file)) return m;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject players = root.has("players") && root.get("players").isJsonObject() ? root.getAsJsonObject("players") : new JsonObject();
            for (Map.Entry<String, JsonElement> e : players.entrySet()) {
                if (!e.getValue().isJsonObject()) continue;
                JsonObject so = e.getValue().getAsJsonObject();
                Session s = new Session();
                s.turnCount = so.has("turn_count") ? so.get("turn_count").getAsLong() : 0;
                s.lastAt = so.has("last_at") ? so.get("last_at").getAsLong() : 0;
                s.sessionCount = so.has("session_count") ? so.get("session_count").getAsLong() : 0;
                s.sessionStartedAt = so.has("session_started_at") ? so.get("session_started_at").getAsLong() : 0;
                s.currentSessionTurns = so.has("current_session_turns") ? so.get("current_session_turns").getAsInt() : 0;
                if (so.has("turns") && so.get("turns").isJsonArray()) {
                    for (JsonElement el : so.getAsJsonArray("turns")) {
                        if (!el.isJsonObject()) continue;
                        JsonObject o = el.getAsJsonObject();
                        Turn t = new Turn();
                        t.text = o.has("text") ? o.get("text").getAsString() : "";
                        t.at = o.has("at") ? o.get("at").getAsLong() : 0;
                        t.durationMs = o.has("duration_ms") ? o.get("duration_ms").getAsLong() : 0;
                        t.rms = o.has("rms") ? o.get("rms").getAsDouble() : 0;
                        t.loudness = o.has("loudness") ? o.get("loudness").getAsString() : loudnessBucket(t.rms);
                        t.quiet = o.has("quiet") && o.get("quiet").getAsBoolean();
                        t.pauseBeforeMs = o.has("pause_before_ms") ? o.get("pause_before_ms").getAsLong() : 0;
                        t.session = o.has("session") ? o.get("session").getAsLong() : 0;
                        t.turnIndex = o.has("turn_index") ? o.get("turn_index").getAsInt() : 0;
                        if (!t.text.isBlank()) s.turns.add(t);
                    }
                }
                while (s.turns.size() > MAX_TURNS_PER_PLAYER) s.turns.remove(0);
                m.sessions.put(e.getKey(), s);
            }
            m.trimPlayers();
        } catch (Exception ignored) { }
        return m;
    }

    private void trimPlayers() {
        if (sessions.size() <= MAX_PLAYERS) return;
        sessions.entrySet().stream().sorted(Comparator.comparingLong(e -> e.getValue().lastAt)).limit(sessions.size() - MAX_PLAYERS).map(Map.Entry::getKey).toList().forEach(sessions::remove);
    }

    private static JsonObject toJson(Turn t) {
        JsonObject o = new JsonObject();
        o.addProperty("text", t.text); o.addProperty("at", t.at); o.addProperty("duration_ms", t.durationMs);
        o.addProperty("rms", t.rms); o.addProperty("loudness", t.loudness); o.addProperty("quiet", t.quiet); o.addProperty("pause_before_ms", t.pauseBeforeMs); o.addProperty("session", t.session); o.addProperty("turn_index", t.turnIndex);
                o.addProperty("session", t.session);
                o.addProperty("turn_index", t.turnIndex);
        return o;
    }

    public static String loudnessBucket(double rms) {
        if (rms < 220) return "quiet";
        if (rms < 900) return "normal";
        if (rms < 3000) return "loud";
        return "very_loud";
    }

    private static final class Session {
        long turnCount;
        long lastAt;
        long sessionCount;
        long sessionStartedAt;
        int currentSessionTurns;
        final List<Turn> turns = new ArrayList<>();
    }
    private static final class Turn {
        String text = "";
        long at;
        long durationMs;
        double rms;
        String loudness = "normal";
        boolean quiet;
        long pauseBeforeMs;
        long session;
        int turnIndex;
    }
}
