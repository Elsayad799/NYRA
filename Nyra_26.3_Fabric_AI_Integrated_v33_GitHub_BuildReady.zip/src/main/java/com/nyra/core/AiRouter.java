package com.nyra.core;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;

/** Thin client for the external Nyra Core. Identity and memory stay in Minecraft. */
public final class AiRouter {
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    private final String base;
    public AiRouter(String base) { this.base = base == null ? "http://127.0.0.1:8787" : base.replaceAll("/$", ""); }

    public String decide(String prompt) {
        JsonObject o = post("/decide", prompt);
        return o == null ? "" : getString(o, "text", "");
    }

    public JsonObject plan(String prompt) {
        JsonObject o = post("/plan", prompt);
        return o == null ? new JsonObject() : o;
    }

    public JsonObject reflect(String prompt) {
        JsonObject o = post("/reflect", prompt);
        return o == null ? new JsonObject() : o;
    }

    private JsonObject post(String path, String prompt) {
        try {
            JsonObject req = new JsonObject();
            req.addProperty("prompt", prompt == null ? "" : prompt);
            HttpRequest r = HttpRequest.newBuilder(URI.create(base + path))
                    .timeout(Duration.ofSeconds(20))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(req.toString()))
                    .build();
            HttpResponse<String> res = http.send(r, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() / 100 == 2) return JsonParser.parseString(res.body()).getAsJsonObject();
        } catch (Exception ignored) { }
        return null;
    }

    private static String getString(JsonObject o, String key, String fallback) {
        try { return o.has(key) ? o.get(key).getAsString() : fallback; }
        catch (Exception e) { return fallback; }
    }
}
