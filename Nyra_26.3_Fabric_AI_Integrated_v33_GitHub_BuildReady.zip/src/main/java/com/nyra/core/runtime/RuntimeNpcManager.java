package com.nyra.core.runtime;

import com.google.gson.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Data-driven NPC layer for AI-created worlds. NPCs are runtime state, not executable code.
 * The AI can describe role/dialogue/behavior; this manager performs only allow-listed behavior.
 */
public final class RuntimeNpcManager {
    public static final String TAG = "nyra_runtime_npc";
    private static final double WALK_SPEED = 0.055;
    private static final double MAX_WANDER = 18.0;
    private final Map<UUID, Npc> npcs = new ConcurrentHashMap<>();
    private final Random random = new Random();

    public static final class Npc {
        public UUID entityId;
        public String id;
        public String role;
        public String dialogue;
        public String behavior;
        public String homeDimension;
        public double homeX, homeY, homeZ;
        public long createdAt;
        public long nextThink;

        Npc() {}
        Npc(UUID entityId, String id, String role, String dialogue, String behavior, Entity e) {
            this.entityId = entityId; this.id=id; this.role=role; this.dialogue=dialogue;
            this.behavior=behavior; this.homeDimension=e.level().dimension().location().toString();
            this.homeX=e.getX(); this.homeY=e.getY(); this.homeZ=e.getZ();
            this.createdAt=System.currentTimeMillis(); this.nextThink=createdAt+500L;
        }
    }

    public ArmorStand spawn(MinecraftServer server, ServerLevel level, String id, String role,
                            String dialogue, String behavior, double x, double y, double z) {
        if (server == null || level == null) return null;
        ArmorStand stand = new ArmorStand(level, x, y, z);
        stand.addTag(TAG);
        stand.addTag("nyra_npc_role_" + safe(role));
        stand.setCustomName(Component.literal("§d" + safe(role)));
        stand.setCustomNameVisible(true);
        stand.setNoGravity(false);
        stand.setInvulnerable(false);
        level.addFreshEntity(stand);
        npcs.put(stand.getUUID(), new Npc(stand.getUUID(), safe(id), safe(role),
                limit(dialogue, 240), safe(behavior), stand));
        return stand;
    }

    public boolean isNpc(Entity entity) {
        return entity instanceof ArmorStand a && a.getTags().contains(TAG);
    }

    public boolean interact(ServerPlayer player, Entity entity) {
        if (!isNpc(entity)) return false;
        Npc npc = npcs.get(entity.getUUID());
        if (npc == null) return false;
        String text = npc.dialogue == null || npc.dialogue.isBlank()
                ? "..." : npc.dialogue;
        player.sendSystemMessage(Component.literal("§d" + npc.role + "§r: " + text));
        npc.nextThink = System.currentTimeMillis() + 3000L;
        return true;
    }

    public void tick(MinecraftServer server) {
        long now = System.currentTimeMillis();
        for (Npc npc : npcs.values()) {
            if (now < npc.nextThink) continue;
            Entity e = find(server, npc.entityId);
            if (!(e instanceof ArmorStand stand) || !stand.isAlive()) {
                npcs.remove(npc.entityId); continue;
            }
            npc.nextThink = now + 1800L + random.nextInt(3000);
            if ("STATIONARY".equalsIgnoreCase(npc.behavior)) continue;
            if ("FOLLOW_NEAREST".equalsIgnoreCase(npc.behavior)) {
                ServerPlayer p = nearest(server, stand);
                if (p != null && p.level() == stand.level() && p.distanceToSqr(stand) < 28*28) {
                    moveToward(stand, p.position(), 0.07);
                    continue;
                }
            }
            if ("GUARD".equalsIgnoreCase(npc.behavior)) {
                if (stand.distanceToSqr(npc.homeX, npc.homeY, npc.homeZ) > MAX_WANDER*MAX_WANDER) {
                    moveToward(stand, new Vec3(npc.homeX,npc.homeY,npc.homeZ), 0.09);
                }
                continue;
            }
            // Default: bounded village/city wandering around the NPC's home point.
            double tx=npc.homeX+(random.nextDouble()-0.5)*MAX_WANDER*2;
            double tz=npc.homeZ+(random.nextDouble()-0.5)*MAX_WANDER*2;
            moveToward(stand, new Vec3(tx, npc.homeY, tz), WALK_SPEED);
        }
    }

    private static void moveToward(ArmorStand stand, Vec3 target, double speed) {
        Vec3 d=target.subtract(stand.position());
        double h=Math.sqrt(d.x*d.x+d.z*d.z);
        if(h<0.5) return;
        double dx=d.x/h*speed, dz=d.z/h*speed;
        if(stand.level().noCollision(stand, stand.getBoundingBox().move(dx,0,dz))) {
            stand.setPos(stand.getX()+dx, stand.getY(), stand.getZ()+dz);
            stand.setYRot((float)(Math.atan2(-dx,dz)*180/Math.PI));
        }
    }

    private static ServerPlayer nearest(MinecraftServer server, Entity e) {
        ServerPlayer best=null; double bestD=Double.MAX_VALUE;
        for(ServerPlayer p:server.getPlayerList().getPlayers()) if(p.level()==e.level()) {
            double d=p.distanceToSqr(e); if(d<bestD){bestD=d;best=p;}
        }
        return best;
    }

    private static Entity find(MinecraftServer server, UUID id) {
        for(var level:server.getAllLevels()){ Entity e=level.getEntity(id); if(e!=null)return e; }
        return null;
    }

    public int size(){return npcs.size();}
    public Collection<Npc> snapshot(){return List.copyOf(npcs.values());}

    public void removeAll(MinecraftServer server){
        for(UUID id:npcs.keySet()){Entity e=find(server,id);if(e!=null)e.discard();}
        npcs.clear();
    }

    public synchronized void save(Path file){
        try{
            Files.createDirectories(file.getParent()); JsonArray arr=new JsonArray();
            for(Npc n:npcs.values()){
                JsonObject o=new JsonObject(); o.addProperty("entityId",n.entityId.toString());
                o.addProperty("id",n.id);o.addProperty("role",n.role);o.addProperty("dialogue",n.dialogue);
                o.addProperty("behavior",n.behavior);o.addProperty("dimension",n.homeDimension);
                o.addProperty("x",n.homeX);o.addProperty("y",n.homeY);o.addProperty("z",n.homeZ);o.addProperty("createdAt",n.createdAt);arr.add(o);
            }
            JsonObject root=new JsonObject();root.add("npcs",arr);
            Files.writeString(file,new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        }catch(Exception e){System.err.println("[Nyra] NPC save failed: "+e);}
    }

    public synchronized void load(Path file){
        // Entity references are world-specific and are intentionally not respawned here.
        // Existing NPC entities are discovered by tag during server startup/tick.
        if(!Files.exists(file)) return;
    }

    private static String safe(String s){if(s==null||s.isBlank())return"npc";return s.replaceAll("[^a-zA-Z0-9_-]","_").substring(0,Math.min(32,s.length()));}
    private static String limit(String s,int n){if(s==null)return"";return s.length()>n?s.substring(0,n):s;}
}
