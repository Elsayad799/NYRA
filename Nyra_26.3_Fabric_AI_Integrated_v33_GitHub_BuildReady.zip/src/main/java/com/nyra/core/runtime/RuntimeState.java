package com.nyra.core.runtime;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public final class RuntimeState {
    public long decisions;
    public long actions;
    public long creations;
    public long lastHeartbeat;
    public String lastAction = "";

    public synchronized void save(Path file) {
        try { Files.createDirectories(file.getParent()); Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(this), StandardCharsets.UTF_8); }
        catch (Exception e) { System.err.println("[Nyra] Runtime state save failed: " + e); }
    }
    public static RuntimeState load(Path file) {
        try { if (Files.exists(file)) return new Gson().fromJson(Files.readString(file), RuntimeState.class); }
        catch (Exception e) { System.err.println("[Nyra] Runtime state load failed: " + e); }
        return new RuntimeState();
    }
}
