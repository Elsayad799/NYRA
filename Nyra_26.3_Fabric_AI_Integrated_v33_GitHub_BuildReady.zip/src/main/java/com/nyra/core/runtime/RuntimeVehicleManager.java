package com.nyra.core.runtime;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Lightweight server-side vehicles for AI-created content.
 * The vehicle is represented by a bounded Minecraft entity and its motion is
 * derived from the rider's view direction; no executable AI code is loaded.
 */
public final class RuntimeVehicleManager {
    public static final String TAG = "nyra_runtime_vehicle";
    private static final double MAX_SPEED = 0.38;
    private static final double MAX_STEP = 0.75;
    private final Map<UUID, Vehicle> vehicles = new ConcurrentHashMap<>();

    public record Vehicle(UUID entityId, String id, String type, long createdAt) {}

    public ArmorStand spawn(MinecraftServer server, ServerPlayer owner, String id, String type,
                            double x, double y, double z) {
        if (server == null || owner == null) return null;
        ArmorStand stand = new ArmorStand(owner.serverLevel(), x, y, z);
        stand.addTag(TAG);
        stand.addTag("nyra_vehicle_" + sanitize(type));
        stand.setCustomName(Component.literal("§5Nyra§r · " + sanitize(type)));
        stand.setCustomNameVisible(true);
        stand.setNoGravity(true);
        stand.setInvulnerable(false);
        owner.serverLevel().addFreshEntity(stand);
        vehicles.put(stand.getUUID(), new Vehicle(stand.getUUID(), id, type, System.currentTimeMillis()));
        return stand;
    }

    public boolean isVehicle(Entity entity) {
        return entity instanceof ArmorStand a && a.getTags().contains(TAG);
    }

    public boolean interact(ServerPlayer player, Entity entity) {
        if (!isVehicle(entity)) return false;
        if (!(entity instanceof ArmorStand stand)) return false;
        if (player.isPassenger()) {
            player.stopRiding();
            player.sendSystemMessage(Component.literal("§8You leave the Nyra vehicle."));
            return true;
        }
        if (stand.getPassengers().isEmpty()) {
            player.startRiding(stand, true);
            player.sendSystemMessage(Component.literal("§5Nyra§r: You are driving. Look where you want to go."));
            return true;
        }
        player.sendSystemMessage(Component.literal("§8Someone is already using this vehicle."));
        return true;
    }

    public void tick(MinecraftServer server) {
        for (Vehicle v : vehicles.values()) {
            Entity e = find(server, v.entityId());
            if (!(e instanceof ArmorStand stand) || !stand.isAlive()) {
                vehicles.remove(v.entityId());
                continue;
            }
            if (stand.getPassengers().isEmpty()) continue;
            Entity rider = stand.getPassengers().getFirst();
            if (!(rider instanceof ServerPlayer player)) continue;
            if (player.level() != stand.level()) continue;

            Vec3 look = player.getLookAngle();
            double horizontal = Math.sqrt(look.x * look.x + look.z * look.z);
            if (horizontal < 0.01) continue;
            double speed = MAX_SPEED;
            double dx = (look.x / horizontal) * speed;
            double dz = (look.z / horizontal) * speed;
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len > MAX_STEP) { dx *= MAX_STEP / len; dz *= MAX_STEP / len; }
            double nx = stand.getX() + dx;
            double nz = stand.getZ() + dz;
            if (stand.level().noCollision(stand, stand.getBoundingBox().move(dx, 0, dz))) {
                stand.setPos(nx, stand.getY(), nz);
            }
            stand.setYRot(player.getYRot());
            stand.setXRot(0);
        }
    }

    public int size() { return vehicles.size(); }
    public Collection<Vehicle> snapshot() { return List.copyOf(vehicles.values()); }

    public void removeAll(MinecraftServer server) {
        for (UUID id : vehicles.keySet()) {
            Entity e = find(server, id);
            if (e != null) e.discard();
        }
        vehicles.clear();
    }

    private static Entity find(MinecraftServer server, UUID id) {
        for (var level : server.getAllLevels()) {
            Entity e = level.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    private static String sanitize(String s) {
        if (s == null || s.isBlank()) return "vehicle";
        return s.replaceAll("[^a-zA-Z0-9_-]", "_").substring(0, Math.min(24, s.length()));
    }
}
