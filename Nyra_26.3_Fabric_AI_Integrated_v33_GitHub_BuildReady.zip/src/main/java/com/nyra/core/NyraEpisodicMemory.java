package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Persistent episodic memory for the shared Nyra Core.
 * Events are grouped into bounded, revisable episodes. Episodes are summaries
 * of observable in-game history, not claims about real-world people.
 */
public final class NyraEpisodicMemory {
    public static final class Episode {
        public String id = "";
        public String subject = "world";
        public String title = "";
        public String status = "ACTIVE";
        public String outcome = "";
        public long startedAt = 0L;
        public long updatedAt = 0L;
        public int eventCount = 0;
        public final List<String> events = new ArrayList<>();
        public final List<String> turningPoints = new ArrayList<>();
    }

    private static final int MAX_EPISODES = 250;
    private static final int MAX_EVENTS_PER_EPISODE = 18;
    private static final long EPISODE_GAP_MS = 15 * 60_000L;
    private final LinkedHashMap<String, Episode> episodes = new LinkedHashMap<>();
    private final Map<String, String> activeBySubject = new HashMap<>();

    public synchronized String record(String subject, String event, double importance) {
        if (event == null || event.isBlank()) return "";
        String safeSubject = (subject == null || subject.isBlank()) ? "world" : subject;
        long now = System.currentTimeMillis();
        Episode ep = activeEpisode(safeSubject, now);
        if (ep == null) {
            ep = new Episode();
            ep.id = "episode:" + Long.toString(now, 36) + ":" + Integer.toHexString(Math.abs(Objects.hash(safeSubject, event)));
            ep.subject = safeSubject;
            ep.title = titleFor(event);
            ep.status = "ACTIVE";
            ep.startedAt = now;
            episodes.put(ep.id, ep);
            activeBySubject.put(safeSubject, ep.id);
            trim();
        }
        String compact = event.trim();
        if (compact.length() > 220) compact = compact.substring(0, 220);
        ep.events.add(now + " | " + compact);
        if (ep.events.size() > MAX_EVENTS_PER_EPISODE) ep.events.remove(0);
        ep.eventCount++;
        ep.updatedAt = now;
        if (importance >= 0.65 || isTurningPoint(compact)) {
            ep.turningPoints.add(compact);
            if (ep.turningPoints.size() > 6) ep.turningPoints.remove(0);
        }
        ep.title = refineTitle(ep.title, compact);
        return ep.id;
    }

    public synchronized void decision(String subject, String action, String reason, String nextStep) {
        StringBuilder e = new StringBuilder("Nyra decision: ").append(action == null ? "WAIT" : action);
        if (reason != null && !reason.isBlank()) e.append(" | reason=").append(reason);
        if (nextStep != null && !nextStep.isBlank()) e.append(" | next_step=").append(nextStep);
        record(subject, e.toString(), "WAIT".equalsIgnoreCase(action) ? 0.35 : 0.70);
    }

    public synchronized void outcome(String subject, String outcome, boolean completed) {
        String safeSubject = (subject == null || subject.isBlank()) ? "world" : subject;
        String id = activeBySubject.get(safeSubject);
        Episode ep = id == null ? null : episodes.get(id);
        if (ep == null) {
            record(safeSubject, outcome, 0.65);
            id = activeBySubject.get(safeSubject);
            ep = id == null ? null : episodes.get(id);
        }
        if (ep == null) return;
        ep.outcome = outcome == null ? "" : outcome.substring(0, Math.min(300, outcome.length()));
        ep.status = completed ? "COMPLETED" : "OPEN";
        ep.updatedAt = System.currentTimeMillis();
        if (completed) activeBySubject.remove(safeSubject);
    }

    public synchronized String forAi(String subject, int limit) {
        List<Episode> list = new ArrayList<>();
        for (Episode ep : episodes.values()) {
            if (subject == null || subject.isBlank() || subject.equals(ep.subject) || "world".equals(ep.subject) || "nyra".equals(ep.subject)) list.add(ep);
        }
        list.sort(Comparator.comparingLong((Episode e) -> e.updatedAt).reversed());
        StringBuilder out = new StringBuilder("[");
        int n = 0;
        for (Episode ep : list) {
            if (n++ >= Math.max(1, limit)) break;
            if (n > 1) out.append(", ");
            out.append("{id=").append(ep.id)
               .append(", subject=").append(ep.subject)
               .append(", title=").append(ep.title)
               .append(", status=").append(ep.status)
               .append(", events=").append(ep.eventCount)
               .append(", outcome=").append(ep.outcome)
               .append(", turning_points=").append(ep.turningPoints)
               .append("}");
        }
        return out.append("]").toString();
    }

    public synchronized String detail(String id) {
        Episode ep = episodes.get(id);
        if (ep == null) return "episode not found";
        return "Episode " + ep.id + " | " + ep.title + " | status=" + ep.status + " | subject=" + ep.subject +
                " | events=" + ep.events + " | turningPoints=" + ep.turningPoints + " | outcome=" + ep.outcome;
    }

    public synchronized int size() { return episodes.size(); }

    public synchronized void save(Path file) {
        try {
            if (file.getParent() != null) Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject();
            root.add("episodes", new Gson().toJsonTree(episodes));
            root.add("activeBySubject", new Gson().toJsonTree(activeBySubject));
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        } catch (Exception e) { System.err.println("[Nyra] Episodic memory save failed: " + e); }
    }

    public static NyraEpisodicMemory load(Path file) {
        NyraEpisodicMemory m = new NyraEpisodicMemory();
        try {
            if (!Files.exists(file)) return m;
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            Gson g = new Gson();
            if (root.has("episodes") && root.get("episodes").isJsonObject()) {
                for (var e : root.getAsJsonObject("episodes").entrySet()) {
                    Episode ep = g.fromJson(e.getValue(), Episode.class);
                    if (ep.events == null) ep.events.clear();
                    if (ep.turningPoints == null) ep.turningPoints.clear();
                    m.episodes.put(e.getKey(), ep);
                }
            }
            if (root.has("activeBySubject") && root.get("activeBySubject").isJsonObject()) {
                for (var e : root.getAsJsonObject("activeBySubject").entrySet()) m.activeBySubject.put(e.getKey(), e.getValue().getAsString());
            }
            m.trim();
        } catch (Exception e) { System.err.println("[Nyra] Episodic memory load failed: " + e); }
        return m;
    }

    private Episode activeEpisode(String subject, long now) {
        String id = activeBySubject.get(subject);
        Episode ep = id == null ? null : episodes.get(id);
        if (ep == null) return null;
        if (now - ep.updatedAt > EPISODE_GAP_MS || "COMPLETED".equals(ep.status)) {
            ep.status = "CLOSED";
            activeBySubject.remove(subject);
            return null;
        }
        return ep;
    }

    private void trim() {
        while (episodes.size() > MAX_EPISODES) {
            String oldest = episodes.keySet().iterator().next();
            episodes.remove(oldest);
            activeBySubject.values().removeIf(oldest::equals);
        }
    }

    private static boolean isTurningPoint(String e) {
        String s = e.toLowerCase(Locale.ROOT);
        return s.contains("attacked") || s.contains("changed goal") || s.contains("core") || s.contains("anomaly") ||
               s.contains("created") || s.contains("completed") || s.contains("abandoned") || s.contains("disappeared");
    }

    private static String titleFor(String e) {
        String s = e.toLowerCase(Locale.ROOT);
        if (s.contains("attacked")) return "Encounter involving an attack";
        if (s.contains("joined")) return "Player encounter begins";
        if (s.contains("disconnected")) return "Player encounter ends";
        if (s.contains("anomaly") || s.contains("investigate")) return "Investigation thread";
        if (s.contains("changed goal")) return "Goal transition";
        return "Unfolding encounter";
    }

    private static String refineTitle(String old, String e) {
        if (old == null || old.isBlank() || "Unfolding encounter".equals(old)) return titleFor(e);
        return old;
    }
}
