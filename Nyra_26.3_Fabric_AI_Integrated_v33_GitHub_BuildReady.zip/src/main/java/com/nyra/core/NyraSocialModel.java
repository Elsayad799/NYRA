package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Shared, probabilistic model of observable player-to-player social patterns. */
public final class NyraSocialModel {
    public static final class PairState {
        public String a, b;
        public double cooperationScore, avoidanceScore, conflictScore, familiarityScore, confidence;
        public long observations, lastObserved;
        public final LinkedList<String> observationsLog = new LinkedList<>();
    }

    private final Map<String, PairState> pairs = new LinkedHashMap<>();
    private static final int MAX_PAIRS = 4000;
    private static final int MAX_LOG = 12;

    public synchronized PairState observePair(UUID playerA, UUID playerB, String signal, double confidence, String source) {
        if (playerA == null || playerB == null || playerA.equals(playerB)) return null;
        String key = key(playerA, playerB);
        PairState p = pairs.computeIfAbsent(key, k -> { PairState x = new PairState(); String[] ab=k.split("|", -1); x.a=ab[0]; x.b=ab[1]; return x; });
        double c = clamp(confidence);
        String s = signal == null ? "observation" : signal.toLowerCase(Locale.ROOT);
        if (s.contains("cooper") || s.contains("help") || s.contains("follow")) p.cooperationScore = move(p.cooperationScore, c, .08);
        if (s.contains("avoid") || s.contains("distance")) p.avoidanceScore = move(p.avoidanceScore, c, .06);
        if (s.contains("conflict") || s.contains("attack") || s.contains("hostile")) p.conflictScore = move(p.conflictScore, c, .10);
        if (s.contains("presence") || s.contains("shared") || s.contains("chat")) p.familiarityScore = move(p.familiarityScore, c, .04);
        p.confidence = clamp(Math.max(p.confidence, c * .65) + .01);
        p.observations++; p.lastObserved=System.currentTimeMillis();
        p.observationsLog.addLast(p.lastObserved + " | " + clip(signal, 90) + " | source=" + clip(source, 40) + " | conf=" + String.format(Locale.ROOT,"%.2f",c));
        while (p.observationsLog.size()>MAX_LOG) p.observationsLog.removeFirst();
        while (pairs.size()>MAX_PAIRS) pairs.remove(pairs.keySet().iterator().next());
        return p;
    }

    public synchronized void observeCoPresence(UUID a, UUID b, String dimension, double distance, String source) {
        if (distance < 0 || distance > 48) return;
        double confidence = Math.max(.20, 1.0 - distance / 48.0);
        observePair(a,b,"presence/shared proximity distance="+String.format(Locale.ROOT,"%.1f",distance)+" dimension="+clip(dimension,40),confidence,source);
    }

    public synchronized String forAi(UUID player, int limit) {
        if (player == null) return "[]";
        List<PairState> list=new ArrayList<>(); String id=player.toString();
        for(PairState p:pairs.values()) if(p.a.equals(id)||p.b.equals(id)) list.add(p);
        list.sort(Comparator.comparingLong((PairState p)->p.lastObserved).reversed());
        int n=Math.min(Math.max(1,limit),list.size()); List<String> out=new ArrayList<>();
        for(int i=0;i<n;i++) out.add(format(list.get(i), id));
        return out.toString();
    }

    public synchronized String groupContext(int limit) {
        List<PairState> list=new ArrayList<>(pairs.values()); list.sort(Comparator.comparingLong((PairState p)->p.lastObserved).reversed());
        int n=Math.min(Math.max(1,limit),list.size()); List<String> out=new ArrayList<>();
        for(int i=0;i<n;i++) out.add(format(list.get(i), null));
        return out.toString();
    }

    public synchronized int size(){return pairs.size();}

    private static String format(PairState p,String focus){
        String other=focus==null?"":(p.a.equals(focus)?p.b:p.a);
        return "pair="+p.a+"~"+p.b+(other.isBlank()?"":" other="+other)+" cooperation="+fmt(p.cooperationScore)+" avoidance="+fmt(p.avoidanceScore)+" conflict="+fmt(p.conflictScore)+" familiarity="+fmt(p.familiarityScore)+" confidence="+fmt(p.confidence)+" observations="+p.observations;
    }
    private static String key(UUID a,UUID b){String x=a.toString(),y=b.toString();return x.compareTo(y)<0?x+"|"+y:y+"|"+x;}
    private static double move(double old,double signal,double rate){return clamp(old+(signal-old)*rate);}
    private static double clamp(double v){return Math.max(0,Math.min(1,Double.isFinite(v)?v:0));}
    private static String fmt(double v){return String.format(Locale.ROOT,"%.2f",v);}
    private static String clip(String s,int n){String x=s==null?"":s.replace('\n',' ').trim();return x.length()<=n?x:x.substring(0,n);}

    public synchronized void save(Path file){try{if(file.getParent()!=null)Files.createDirectories(file.getParent());JsonObject root=new JsonObject();root.add("pairs",new Gson().toJsonTree(pairs));Files.writeString(file,new GsonBuilder().setPrettyPrinting().create().toJson(root),StandardCharsets.UTF_8);}catch(Exception e){System.err.println("[Nyra] Social model save failed: "+e);}}
    public static NyraSocialModel load(Path file){NyraSocialModel m=new NyraSocialModel();try{if(!Files.exists(file))return m;JsonObject root=JsonParser.parseString(Files.readString(file)).getAsJsonObject();if(root.has("pairs")&&root.get("pairs").isJsonObject()){for(var e:root.getAsJsonObject("pairs").entrySet()){PairState p=new Gson().fromJson(e.getValue(),PairState.class);if(p==null||p.a==null||p.b==null)continue;p.cooperationScore=clamp(p.cooperationScore);p.avoidanceScore=clamp(p.avoidanceScore);p.conflictScore=clamp(p.conflictScore);p.familiarityScore=clamp(p.familiarityScore);p.confidence=clamp(p.confidence);while(p.observationsLog.size()>MAX_LOG)p.observationsLog.removeFirst();m.pairs.put(key(UUID.fromString(p.a),UUID.fromString(p.b)),p);}}}catch(Exception e){System.err.println("[Nyra] Social model load failed: "+e);}return m;}
}
