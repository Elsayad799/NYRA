package com.nyra.core;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

import java.util.Locale;

/** Lightweight world snapshot used as input to the external Nyra Core. */
public final class WorldPerception {
    public static String forPlayer(MinecraftServer server, ServerPlayer p) {
        int nearbyPlayers = 0, nearbyEntities = 0;
        double radius2 = 32 * 32;
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            if (other != p && other.level() == p.level() && other.distanceToSqr(p) <= radius2) nearbyPlayers++;
        }
        for (Entity e : p.level().getEntities(p, p.getBoundingBox().inflate(32), e -> e != p)) nearbyEntities++;

        Level level = p.level();
        String dimension = level.dimension().location().toString();
        long time = level.getDayTime();
        String phase = time % 24000L < 12000L ? "DAY" : "NIGHT";
        String weather = level.isThundering() ? "THUNDER" : (level.isRaining() ? "RAIN" : "CLEAR");
        String facing = p.getDirection().getName().toUpperCase(Locale.ROOT);

        return "dimension=" + dimension +
                ", position=" + p.blockPosition().toShortString() +
                ", nearbyPlayers=" + nearbyPlayers +
                ", nearbyEntities=" + nearbyEntities +
                ", phase=" + phase +
                ", weather=" + weather +
                ", facing=" + facing;
    }
}
