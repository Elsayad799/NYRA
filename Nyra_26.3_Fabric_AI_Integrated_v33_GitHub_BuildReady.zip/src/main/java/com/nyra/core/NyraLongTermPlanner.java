package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Advisory long-term planner for the shared Nyra Core.
 * It does not execute actions and never forces a goal. It prepares a compact
 * planning context that the AI can accept, revise, replace, or ignore.
 */
public final class NyraLongTermPlanner {
    public static final class State {
        public String currentThread = "";
        public String phase = "IDLE";
        public long startedAt = 0L;
        public long lastProgressAt = 0L;
        public int steps = 0;
        public int completed = 0;
        public int abandoned = 0;

        public synchronized void start(String thread) {
            if (thread == null || thread.isBlank()) return;
            currentThread = thread;
            phase = "ACTIVE";
            startedAt = System.currentTimeMillis();
            lastProgressAt = startedAt;
            steps = 0;
        }
        public synchronized void progress() { if (!currentThread.isBlank()) { phase = "ACTIVE"; lastProgressAt = System.currentTimeMillis(); steps++; } }
        public synchronized void complete() { if (!currentThread.isBlank()) completed++; phase = "IDLE"; currentThread = ""; steps = 0; }
        public synchronized void abandon() { if (!currentThread.isBlank()) abandoned++; phase = "IDLE"; currentThread = ""; steps = 0; }
        public synchronized boolean stagnant(long now, long thresholdMs) { return !currentThread.isBlank() && now - lastProgressAt >= thresholdMs; }
    }

    private final State state = new State();
    private final long stagnationMs;

    public NyraLongTermPlanner(long stagnationMs) { this.stagnationMs = Math.max(60_000L, stagnationMs); }
    public State state() { return state; }

    /** Returns advisory context only; the model remains the final decision-maker. */
    public synchronized String context(NyraMemory memory, NyraKnowledge knowledge, NyraWorldModel world) {
        long now = System.currentTimeMillis();
        StringBuilder s = new StringBuilder();
        s.append("planner={phase=").append(state.phase)
         .append(", thread=").append(state.currentThread.isBlank() ? "none" : state.currentThread)
         .append(", steps=").append(state.steps)
         .append(", stagnant=").append(state.stagnant(now, stagnationMs))
         .append(", completed=").append(state.completed)
         .append(", abandoned=").append(state.abandoned).append("; ");
        s.append("candidate_focus=[");
        if (world != null && world.anomalies() > 0) s.append("revisit_uncertain_anomalies,");
        if (world != null && world.places() > 0) s.append("connect_known_places,");
        if (knowledge != null && knowledge.size() > 0) s.append("re-evaluate_player_evidence,");
        if (memory != null && memory.currentGoal() != null && !memory.currentGoal().isBlank()) s.append("continue_or_reassess_current_goal,");
        s.append("free_exploration_or_WAIT]");
        s.append(", rule=advisory_only; no objective is mandatory; Nyra may reject every candidate and choose another goal or WAIT}");
        return s.toString();
    }

    public synchronized void save(Path file) {
        try {
            if (file.getParent() != null) Files.createDirectories(file.getParent());
            JsonObject o = new JsonObject();
            o.addProperty("currentThread", state.currentThread); o.addProperty("phase", state.phase);
            o.addProperty("startedAt", state.startedAt); o.addProperty("lastProgressAt", state.lastProgressAt);
            o.addProperty("steps", state.steps); o.addProperty("completed", state.completed); o.addProperty("abandoned", state.abandoned);
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(o), StandardCharsets.UTF_8);
        } catch (Exception e) { System.err.println("[Nyra] Planner save failed: " + e); }
    }

    public static NyraLongTermPlanner load(Path file, long stagnationMs) {
        NyraLongTermPlanner p = new NyraLongTermPlanner(stagnationMs);
        try {
            if (!Files.exists(file)) return p;
            JsonObject o = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            p.state.currentThread = o.has("currentThread") ? o.get("currentThread").getAsString() : "";
            p.state.phase = o.has("phase") ? o.get("phase").getAsString() : "IDLE";
            p.state.startedAt = o.has("startedAt") ? o.get("startedAt").getAsLong() : 0L;
            p.state.lastProgressAt = o.has("lastProgressAt") ? o.get("lastProgressAt").getAsLong() : 0L;
            p.state.steps = o.has("steps") ? o.get("steps").getAsInt() : 0;
            p.state.completed = o.has("completed") ? o.get("completed").getAsInt() : 0;
            p.state.abandoned = o.has("abandoned") ? o.get("abandoned").getAsInt() : 0;
        } catch (Exception e) { System.err.println("[Nyra] Planner load failed: " + e); }
        return p;
    }

    public synchronized void acceptThread(String id) { if (id != null && !id.isBlank() && !id.equals(state.currentThread)) state.start(id); }
    public synchronized void recordDecision(String id, String action, String reason) {
        if (id != null && !id.isBlank()) acceptThread(id);
        if ("WAIT".equalsIgnoreCase(action)) return;
        if (reason != null && !reason.isBlank()) state.progress();
    }
}
