package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Persistent, bounded behavioral profile for Nyra's shared Core.
 * It changes gradually from observable in-game experience. Traits are soft
 * context for the AI; they never directly execute or force an action.
 */
public final class NyraAdaptivePersonality {
    public static final class Traits {
        public double curiosity = 0.50;
        public double warmth = 0.45;
        public double caution = 0.50;
        public double assertiveness = 0.40;
        public double playfulness = 0.35;
        public double mystery = 0.60;
        public double patience = 0.55;
        public long observations = 0L;
        public long lastEvolutionAt = 0L;
    }

    private final Traits traits = new Traits();
    private final LinkedList<String> evolutionLog = new LinkedList<>();
    private static final int MAX_LOG = 120;

    public synchronized Traits traits() { return traits; }

    public synchronized void observe(String event) {
        if (event == null || event.isBlank()) return;
        String e = event.toLowerCase(Locale.ROOT);
        double curiosity = 0, warmth = 0, caution = 0, assertiveness = 0, playfulness = 0, mystery = 0, patience = 0;
        if (containsAny(e, "joined", "curious", "question", "سؤال", "why", "investigate", "discover")) { curiosity += .010; patience += .002; }
        if (containsAny(e, "help", "ساعد", "friendly", "saved", "gift")) { warmth += .014; caution -= .002; }
        if (containsAny(e, "threat", "kill", "attack", "attacked", "قتلك", "اقتل")) { caution += .020; assertiveness += .008; warmth -= .004; }
        if (containsAny(e, "joke", "play", "fun", "مزاح")) { playfulness += .015; warmth += .005; }
        if (containsAny(e, "core", "clue", "anomaly", "mystery", "غريب", "لغز")) { mystery += .012; curiosity += .008; }
        if (containsAny(e, "disconnected", "offline", "alone")) { patience += .006; mystery += .004; }
        evolve(curiosity, warmth, caution, assertiveness, playfulness, mystery, patience, "event:" + clip(event, 110));
    }

    public synchronized void learnFromAssessment(String assessment, String lesson) {
        String a = assessment == null ? "UNCERTAIN" : assessment.toUpperCase(Locale.ROOT);
        if ("UNCERTAIN".equals(a)) return;
        double curiosity = 0, warmth = 0, caution = 0, assertiveness = 0, playfulness = 0, mystery = 0, patience = 0;
        if ("SUCCESS".equals(a)) { patience += .006; curiosity += .003; }
        else if ("PARTIAL".equals(a)) { curiosity += .004; patience += .003; }
        else if ("FAILURE".equals(a)) { caution += .010; patience += .004; assertiveness -= .002; }
        else if ("NEUTRAL".equals(a)) { patience += .002; }
        if (lesson != null && containsAny(lesson.toLowerCase(Locale.ROOT), "unexpected", "surprise", "mystery", "clue")) mystery += .006;
        evolve(curiosity, warmth, caution, assertiveness, playfulness, mystery, patience, "reflection:" + a);
    }

    private void evolve(double c, double w, double ca, double as, double p, double m, double pa, String reason) {
        double rate = 0.35; // damped learning; personality changes slowly.
        traits.curiosity = clamp(traits.curiosity + c * rate);
        traits.warmth = clamp(traits.warmth + w * rate);
        traits.caution = clamp(traits.caution + ca * rate);
        traits.assertiveness = clamp(traits.assertiveness + as * rate);
        traits.playfulness = clamp(traits.playfulness + p * rate);
        traits.mystery = clamp(traits.mystery + m * rate);
        traits.patience = clamp(traits.patience + pa * rate);
        if (c != 0 || w != 0 || ca != 0 || as != 0 || p != 0 || m != 0 || pa != 0) {
            traits.observations++;
            traits.lastEvolutionAt = System.currentTimeMillis();
            evolutionLog.addLast(traits.observations + " | " + reason);
            while (evolutionLog.size() > MAX_LOG) evolutionLog.removeFirst();
        }
    }

    public synchronized String context() {
        return String.format(Locale.ROOT,
                "personality={curiosity=%.2f,warmth=%.2f,caution=%.2f,assertiveness=%.2f,playfulness=%.2f,mystery=%.2f,patience=%.2f,observations=%d}",
                traits.curiosity, traits.warmth, traits.caution, traits.assertiveness,
                traits.playfulness, traits.mystery, traits.patience, traits.observations);
    }

    public synchronized String history(int limit) {
        int n = Math.max(1, Math.min(limit, evolutionLog.size()));
        List<String> list = new ArrayList<>(evolutionLog);
        if (list.size() > n) list = list.subList(list.size() - n, list.size());
        return list.toString();
    }

    public synchronized void save(Path file) {
        try {
            if (file.getParent() != null) Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject();
            root.add("traits", new Gson().toJsonTree(traits));
            root.add("evolutionLog", new Gson().toJsonTree(evolutionLog));
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        } catch (Exception e) { System.err.println("[Nyra] Personality save failed: " + e); }
    }

    public static NyraAdaptivePersonality load(Path file) {
        NyraAdaptivePersonality p = new NyraAdaptivePersonality();
        try {
            if (!Files.exists(file)) return p;
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.has("traits") && root.get("traits").isJsonObject()) {
                Traits t = new Gson().fromJson(root.get("traits"), Traits.class);
                if (t != null) {
                    p.traits.curiosity = clamp(t.curiosity); p.traits.warmth = clamp(t.warmth); p.traits.caution = clamp(t.caution);
                    p.traits.assertiveness = clamp(t.assertiveness); p.traits.playfulness = clamp(t.playfulness);
                    p.traits.mystery = clamp(t.mystery); p.traits.patience = clamp(t.patience);
                    p.traits.observations = Math.max(0, t.observations); p.traits.lastEvolutionAt = Math.max(0, t.lastEvolutionAt);
                }
            }
            if (root.has("evolutionLog") && root.get("evolutionLog").isJsonArray())
                for (JsonElement e : root.getAsJsonArray("evolutionLog")) p.evolutionLog.add(e.getAsString());
            while (p.evolutionLog.size() > MAX_LOG) p.evolutionLog.removeFirst();
        } catch (Exception e) { System.err.println("[Nyra] Personality load failed: " + e); }
        return p;
    }

    private static boolean containsAny(String s, String... values) { for (String v : values) if (s.contains(v)) return true; return false; }
    private static double clamp(double v) { return Math.max(0.0, Math.min(1.0, Double.isFinite(v) ? v : 0.5)); }
    private static String clip(String s, int max) { String x = s == null ? "" : s.trim(); return x.length() <= max ? x : x.substring(0, max); }
}
