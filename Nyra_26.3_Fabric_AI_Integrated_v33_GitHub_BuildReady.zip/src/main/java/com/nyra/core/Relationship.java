package com.nyra.core;

public class Relationship {
    public double trust = 0.0;
    public double familiarity = 0.0;
    public double fear = 0.0;
    public double hostility = 0.0;
    public double respect = 0.0;
    public double curiosity = 0.0;
    public double preferenceFeminine = 0.33;
    public double preferenceMasculine = 0.33;
    public double preferenceHorror = 0.34;
    public int attacksOnNyra = 0;
    public double forgiveness = 0.0;
    public double grievance = 0.0;
    public long lastApologyAt = 0;
    public long lastHarmAt = 0;
    public int apologies = 0;
    public int forgivenIncidents = 0;
    public long lastSeen = 0;
    public long lastFormChange = 0;
    public String form = "FEMININE";

    public void clamp() {
        trust = clamp01(trust); familiarity = clamp01(familiarity); fear = clamp01(fear);
        hostility = clamp01(hostility); forgiveness = clamp01(forgiveness); grievance = clamp01(grievance); respect = clamp01(respect); curiosity = clamp01(curiosity);
        preferenceFeminine = clamp01(preferenceFeminine); preferenceMasculine = clamp01(preferenceMasculine); preferenceHorror = clamp01(preferenceHorror);
    }
    private static double clamp01(double x) { return Math.max(0, Math.min(1, x)); }
}
