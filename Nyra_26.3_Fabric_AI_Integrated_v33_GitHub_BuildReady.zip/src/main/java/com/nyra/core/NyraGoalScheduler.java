package com.nyra.core;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Shared-Core goal scheduler. It is intentionally Minecraft-API independent so the
 * decision policy can be tested without launching a server.
 */
public final class NyraGoalScheduler {
    public enum Goal { OBSERVE, ROAM, BUILD, INVESTIGATE, FOLLOW, HIDE, RETURN_HOME, WAIT }
    private final Map<UUID, Goal> goals = new ConcurrentHashMap<>();
    private final Map<UUID, Long> nextAllowed = new ConcurrentHashMap<>();

    public Goal get(UUID manifestationOrPlayer) { return goals.getOrDefault(manifestationOrPlayer, Goal.OBSERVE); }

    public boolean ready(UUID id, long now) { return now >= nextAllowed.getOrDefault(id, 0L); }

    public void set(UUID id, Goal goal, long cooldownMs, long now) {
        goals.put(id, goal == null ? Goal.WAIT : goal);
        nextAllowed.put(id, now + Math.max(0L, cooldownMs));
    }

    public void remove(UUID id) { goals.remove(id); nextAllowed.remove(id); }

    public Map<UUID, Goal> snapshot() { return Map.copyOf(goals); }
}
