package com.nyra.core;

import com.google.gson.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.MinecraftServer;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Longitudinal memory of observable player groups. It stores only in-game behavior. */
public final class NyraGroupMemory {
    public static final class GroupState {
        public String id;
        public List<String> members = new ArrayList<>();
        public long firstSeen, lastSeen;
        public long observations, sharedEpisodes;
        public double stability, confidence;
        public int peakSize;
        public String status = "ACTIVE";
        public long lastMemberChange;
        public long splitCount, reformationCount;
        public final LinkedList<String> timeline = new LinkedList<>();
    }

    private final Map<String, GroupState> groups = new LinkedHashMap<>();
    private static final int MAX_GROUPS = 1200;
    private static final int MAX_TIMELINE = 18;

    public synchronized GroupState observe(Collection<UUID> members, String dimension, String source) {
        if (members == null || members.size() < 2 || members.size() > 16) return null;
        List<String> ids = new ArrayList<>();
        for (UUID u : members) if (u != null) ids.add(u.toString());
        Collections.sort(ids);
        String id = groupId(ids);
        long now = System.currentTimeMillis();
        GroupState g = groups.computeIfAbsent(id, k -> {
            GroupState x = new GroupState(); x.id = k; x.firstSeen = now; x.members = new ArrayList<>(ids); return x;
        });
        boolean continuing = now - g.lastSeen <= 90_000L;
        if (continuing) g.stability = clamp(g.stability + .08);
        else g.stability = clamp(g.stability * .65 + .15);
        g.confidence = clamp(Math.max(g.confidence, .35) + .015);
        if (g.peakSize < ids.size()) g.peakSize = ids.size();
        if (!g.members.equals(ids)) {
            g.lastMemberChange = now;
            if (g.status.equals("DORMANT") || g.status.equals("DISSOLVED") || g.status.equals("FRAGMENTED")) g.reformationCount++;
        }
        g.status = "ACTIVE";
        g.lastSeen = now; g.observations++; g.sharedEpisodes += continuing ? 0 : 1;
        g.members = new ArrayList<>(ids);
        g.timeline.addLast(now + " | members=" + ids.size() + " | dim=" + clip(dimension, 36) + " | source=" + clip(source, 36));
        while (g.timeline.size() > MAX_TIMELINE) g.timeline.removeFirst();
        while (groups.size() > MAX_GROUPS) groups.remove(groups.keySet().iterator().next());
        return g;
    }

    public synchronized void observeOnlineClusters(MinecraftServer server) {
        if (server == null) return;
        List<ServerPlayer> ps = server.getPlayerList().getPlayers();
        if (ps.size() < 2) return;
        boolean[] used = new boolean[ps.size()];
        for (int i = 0; i < ps.size(); i++) {
            if (used[i]) continue;
            List<Integer> component = new ArrayList<>();
            ArrayDeque<Integer> q = new ArrayDeque<>(); q.add(i); used[i] = true;
            while (!q.isEmpty()) {
                int x = q.removeFirst(); component.add(x);
                for (int j = 0; j < ps.size(); j++) {
                    if (used[j]) continue;
                    if (!ps.get(x).level().dimension().equals(ps.get(j).level().dimension())) continue;
                    if (ps.get(x).distanceTo(ps.get(j)) <= 32.0) { used[j] = true; q.add(j); }
                }
            }
            if (component.size() >= 2 && component.size() <= 16) {
                List<UUID> members = new ArrayList<>();
                String dim = ps.get(component.get(0)).level().dimension().location().toString();
                for (int idx : component) members.add(ps.get(idx).getUUID());
                observe(members, dim, "online-proximity");
            }
        }
        evolveLifecycle(ps);
    }

    /** Marks groups as dormant, dissolved, or fragmented from only observable membership changes. */
    private synchronized void evolveLifecycle(List<ServerPlayer> online) {
        long now = System.currentTimeMillis();
        Set<String> onlineIds = new HashSet<>();
        for (ServerPlayer p : online) onlineIds.add(p.getUUID().toString());
        for (GroupState g : groups.values()) {
            long age = now - g.lastSeen;
            if (age > 600_000L) {
                if (!"DISSOLVED".equals(g.status)) addTimeline(g, now + " | group dissolved/inactive");
                g.status = "DISSOLVED";
                g.stability = clamp(g.stability * .88);
            } else if (age > 90_000L) {
                if ("ACTIVE".equals(g.status)) addTimeline(g, now + " | group became dormant");
                g.status = "DORMANT";
                g.stability = clamp(g.stability * .96);
            }
        }
        // If a previous group is now represented by two or more smaller observed groups,
        // record a fragmentation event without claiming motives or hidden relationships.
        List<GroupState> current = new ArrayList<>();
        for (GroupState g : groups.values()) if ("ACTIVE".equals(g.status) && g.lastSeen >= now - 30_000L) current.add(g);
        for (GroupState old : groups.values()) {
            if (old.members.size() < 3 || old.lastSeen < now - 180_000L || "FRAGMENTED".equals(old.status)) continue;
            int matches = 0;
            for (GroupState newer : current) {
                if (newer == old || newer.members.size() >= old.members.size()) continue;
                int overlap = 0; for (String id : newer.members) if (old.members.contains(id)) overlap++;
                if (overlap >= 2) matches++;
            }
            if (matches >= 2) {
                old.status = "FRAGMENTED"; old.splitCount++;
                addTimeline(old, now + " | group fragmented into smaller observed clusters");
                old.confidence = clamp(old.confidence + .02);
            }
        }
    }

    private static void addTimeline(GroupState g, String line) {
        g.timeline.addLast(line);
        while (g.timeline.size() > MAX_TIMELINE) g.timeline.removeFirst();
    }

    public synchronized String forAi(int limit) {
        List<GroupState> list = new ArrayList<>(groups.values());
        list.sort(Comparator.comparingLong((GroupState g) -> g.lastSeen).reversed());
        int n = Math.min(Math.max(1, limit), list.size());
        List<String> out = new ArrayList<>();
        for (int i=0;i<n;i++) out.add(format(list.get(i)));
        return out.toString();
    }

    public synchronized String forPlayer(UUID player, int limit) {
        if (player == null) return "[]";
        String id = player.toString(); List<GroupState> list = new ArrayList<>();
        for (GroupState g : groups.values()) if (g.members.contains(id)) list.add(g);
        list.sort(Comparator.comparingLong((GroupState g) -> g.lastSeen).reversed());
        int n = Math.min(Math.max(1, limit), list.size()); List<String> out = new ArrayList<>();
        for (int i=0;i<n;i++) out.add(format(list.get(i)));
        return out.toString();
    }

    public synchronized int size() { return groups.size(); }

    private static String format(GroupState g) {
        return "group=" + g.id + " members=" + g.members + " status=" + g.status +
                " observations=" + g.observations + " sharedEpisodes=" + g.sharedEpisodes +
                " peakSize=" + g.peakSize + " splitCount=" + g.splitCount +
                " reformationCount=" + g.reformationCount + " stability=" + fmt(g.stability) +
                " confidence=" + fmt(g.confidence) + " lastSeen=" + g.lastSeen;
    }
    private static String groupId(List<String> ids) {
        return "g-" + UUID.nameUUIDFromBytes(String.join("|", ids).getBytes(StandardCharsets.UTF_8));
    }
    private static double clamp(double v) { return Math.max(0, Math.min(1, Double.isFinite(v) ? v : 0)); }
    private static String fmt(double v) { return String.format(Locale.ROOT, "%.2f", v); }
    private static String clip(String s, int n) { String x=s==null?"":s.replace('\n',' ').trim(); return x.length()<=n?x:x.substring(0,n); }

    public synchronized void save(Path file) {
        try {
            if (file.getParent()!=null) Files.createDirectories(file.getParent());
            JsonObject root=new JsonObject(); root.add("groups", new Gson().toJsonTree(groups));
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        } catch (Exception e) { System.err.println("[Nyra] Group memory save failed: " + e); }
    }

    public static NyraGroupMemory load(Path file) {
        NyraGroupMemory m=new NyraGroupMemory();
        try {
            if (!Files.exists(file)) return m;
            JsonObject root=JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.has("groups") && root.get("groups").isJsonObject()) {
                for (var e : root.getAsJsonObject("groups").entrySet()) {
                    GroupState g=new Gson().fromJson(e.getValue(), GroupState.class);
                    if (g==null || g.id==null || g.members==null || g.members.size()<2) continue;
                    g.stability=clamp(g.stability); g.confidence=clamp(g.confidence);
                    if (g.status == null || g.status.isBlank()) g.status = "ACTIVE";
                    if (g.peakSize < g.members.size()) g.peakSize = g.members.size();
                    if (g.timeline==null) { /* Gson normally restores the field; keep defensive compatibility. */ }
                    while (g.timeline.size()>MAX_TIMELINE) g.timeline.removeFirst();
                    m.groups.put(g.id,g);
                }
            }
        } catch (Exception e) { System.err.println("[Nyra] Group memory load failed: " + e); }
        return m;
    }
}
