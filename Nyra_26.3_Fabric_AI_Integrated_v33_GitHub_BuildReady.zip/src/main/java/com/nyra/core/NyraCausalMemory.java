package com.nyra.core;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Persistent causal graph for the shared Nyra Core.
 * It stores only observable in-game relationships between events, effects and decisions.
 * Causal links are evidence, not certainty, and can be reinforced or weakened.
 */
public final class NyraCausalMemory {
    public static final class Link {
        public String id = "";
        public String cause = "";
        public String effect = "";
        public String subject = "";
        public double confidence = 0.5;
        public int observations = 0;
        public long firstSeen = 0L;
        public long lastSeen = 0L;
        public String lastEvidence = "";
    }

    private final Map<String, Link> links = new LinkedHashMap<>();
    private static final int MAX_LINKS = 600;

    public synchronized void observe(String subject, String cause, String effect, double evidence, String source) {
        if (blank(cause) || blank(effect)) return;
        subject = subject == null ? "world" : subject;
        String id = Integer.toHexString(Objects.hash(subject, normalize(cause), normalize(effect)));
        Link l = links.get(id);
        long now = System.currentTimeMillis();
        if (l == null) {
            l = new Link(); l.id = id; l.cause = cause; l.effect = effect; l.subject = subject;
            l.confidence = clamp(evidence); l.firstSeen = now; links.put(id, l);
        } else {
            double e = clamp(evidence);
            l.confidence = clamp(l.confidence + (e - l.confidence) * 0.22);
        }
        l.observations++;
        l.lastSeen = now;
        l.lastEvidence = source == null ? "" : source;
        trim();
    }

    /** Deterministic, transparent in-game inference from an observable event. */
    public synchronized void inferEvent(String subject, String event, String source) {
        if (blank(event)) return;
        String e = event.toLowerCase(Locale.ROOT);
        if (e.contains("threat")) observe(subject, "player threatened Nyra", "Nyra increases caution toward player", 0.72, source);
        if (e.contains("attacked nyra") || e.contains("attacked")) observe(subject, "player attacked Nyra", "Nyra remembers hostility and may avoid player", 0.88, source);
        if (e.contains("joined")) observe(subject, "player joined", "player becomes available for observation", 0.92, source);
        if (e.contains("disconnected")) observe(subject, "player disconnected", "Nyra has fewer immediate social signals", 0.78, source);
        if (e.contains("help") || e.contains("helpful")) observe(subject, "player offered help", "Nyra may increase trust/attachment", 0.68, source);
        if (e.contains("curious") || e.contains("question")) observe(subject, "player showed curiosity", "Nyra may reveal or investigate information", 0.64, source);
        if (e.contains("changed goal")) observe("nyra", "Nyra changed goal", "previous plan was reconsidered", 0.60, source);
        if (e.contains("investigate") || e.contains("anomaly")) observe("nyra", "Nyra noticed an anomaly", "investigation may become relevant", 0.58, source);
    }

    public synchronized String forAi(String subject, int limit) {
        List<Link> list = new ArrayList<>();
        for (Link l : links.values()) if (subject == null || subject.isBlank() || subject.equals(l.subject) || "world".equals(l.subject) || "nyra".equals(l.subject)) list.add(l);
        list.sort(Comparator.comparingDouble((Link l) -> l.confidence).reversed().thenComparingLong(l -> -l.lastSeen));
        StringBuilder s = new StringBuilder("["); int n = 0;
        for (Link l : list) {
            if (n++ >= Math.max(1, limit)) break;
            if (n > 1) s.append(", ");
            s.append("{").append("subject=").append(l.subject)
             .append(", cause=").append(l.cause)
             .append(", effect=").append(l.effect)
             .append(", confidence=").append(String.format(Locale.ROOT, "%.2f", l.confidence))
             .append(", observations=").append(l.observations).append("}");
        }
        return s.append("]").toString();
    }

    public synchronized int size() { return links.size(); }

    private void trim() {
        while (links.size() > MAX_LINKS) {
            String oldest = null; long t = Long.MAX_VALUE;
            for (var e : links.entrySet()) if (e.getValue().lastSeen < t) { t = e.getValue().lastSeen; oldest = e.getKey(); }
            if (oldest == null) break; links.remove(oldest);
        }
    }

    public synchronized void save(Path file) {
        try {
            if (file.getParent() != null) Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject(); root.add("links", new Gson().toJsonTree(links));
            Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(root), StandardCharsets.UTF_8);
        } catch (Exception e) { System.err.println("[Nyra] Causal memory save failed: " + e); }
    }

    public static NyraCausalMemory load(Path file) {
        NyraCausalMemory c = new NyraCausalMemory();
        try {
            if (!Files.exists(file)) return c;
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            Gson g = new Gson();
            if (root.has("links") && root.get("links").isJsonObject())
                for (var e : root.getAsJsonObject("links").entrySet()) c.links.put(e.getKey(), g.fromJson(e.getValue(), Link.class));
        } catch (Exception e) { System.err.println("[Nyra] Causal memory load failed: " + e); }
        return c;
    }

    private static String normalize(String s) { return s.toLowerCase(Locale.ROOT).trim(); }
    private static boolean blank(String s) { return s == null || s.isBlank(); }
    private static double clamp(double v) { return Math.max(0.0, Math.min(1.0, v)); }
}
