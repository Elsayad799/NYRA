package com.nyra.voice;

import com.nyra.core.NyraMod;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.audiochannel.AudioPlayer;
import de.maxhenkel.voicechat.api.audiochannel.LocationalAudioChannel;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import de.maxhenkel.voicechat.api.mp3.Mp3Decoder;
import de.maxhenkel.voicechat.api.opus.OpusDecoder;
import de.maxhenkel.voicechat.api.packets.MicrophonePacket;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/** Optional Simple Voice Chat bridge: microphone -> STT -> Nyra Core and Nyra TTS -> positional voice. */
public final class NyraVoicePlugin implements VoicechatPlugin {
    private static final Map<UUID, Stream> streams = new ConcurrentHashMap<>();
    private static VoicechatServerApi api;
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
    private static final Set<AudioPlayer> ACTIVE_PLAYERS = ConcurrentHashMap.newKeySet();
    private static final ScheduledExecutorService FLUSH = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "nyra-voice-flush"); t.setDaemon(true); return t;
    });

    @Override public String getPluginId() { return "nyra_voice_bridge"; }

    @Override public void initialize(VoicechatApi voicechat) {
        if (voicechat instanceof VoicechatServerApi serverApi) {
            api = serverApi;
            FLUSH.scheduleAtFixedRate(NyraVoicePlugin::flushExpired, 250, 250, TimeUnit.MILLISECONDS);
            System.out.println("[Nyra] Simple Voice Chat bridge initialized.");
        }
    }

    @Override public void registerEvents(EventRegistration registration) {
        registration.registerEvent(MicrophonePacketEvent.class, this::onMicrophone);
    }

    private void onMicrophone(MicrophonePacketEvent event) {
        if (!NyraMod.voiceEnabled() || api == null) return;
        try {
            UUID id = event.getSenderConnection().getPlayer().getUuid();
            if (!NyraMod.voiceCanHear(id)) return;
            if (NyraMod.voiceInterruptEnabled()) interruptSpeech();
            MicrophonePacket packet = event.getPacket();
            byte[] opus = packet.getOpusEncodedData();
            if (opus == null || opus.length == 0) return;
            Stream st = streams.computeIfAbsent(id, k -> new Stream(api.createDecoder()));
            short[] pcm = st.decoder.decode(opus);
            if (pcm == null || pcm.length == 0) return;
            st.lastPacket = System.currentTimeMillis();
            double rms = rms(pcm);
            if (st.pcm.size() == 0) { st.speechStarted = st.lastPacket; st.pauseBefore = Math.max(0, st.lastPacket - st.lastFlush); }
            st.rmsSum += rms; st.rmsSamples++; st.packetCount++;
            if (rms > 350.0) st.lastSpeech = st.lastPacket;
            if (rms > 180.0 || st.pcm.size() > 0) {
                byte[] raw = new byte[pcm.length * 2];
                for (int i=0;i<pcm.length;i++) { raw[i*2]=(byte)(pcm[i]&255); raw[i*2+1]=(byte)((pcm[i]>>8)&255); }
                st.pcm.write(raw);
            }
            if (NyraMod.voiceStreamingEnabled() && st.lastPacket - st.lastPartialSent >= NyraMod.voicePartialIntervalMs() && st.pcm.size() > 2400) {
                st.lastPartialSent = st.lastPacket;
                sendPartial(id, st);
            }
            if (st.pcm.size() > 48000 * 2 * 10) flush(id, st);
        } catch (Throwable ignored) { }
    }

    private static void sendPartial(UUID id, Stream s) {
        byte[] pcm=s.pcm.toByteArray();
        if (pcm.length < 2400) return;
        CompletableFuture.runAsync(() -> {
            try {
                JsonObject body=new JsonObject(); body.addProperty("player_id",id.toString()); body.addProperty("session_id",s.sessionId.toString());
                body.addProperty("audio_wav_base64",Base64.getEncoder().encodeToString(wav(pcm,48000,1,16))); body.addProperty("partial",true); body.addProperty("final",false);
                HttpRequest req=HttpRequest.newBuilder(URI.create(NyraMod.voicePartialSttUrl())).timeout(Duration.ofSeconds(5)).header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(body.toString())).build();
                HttpResponse<String> res=HTTP.send(req,HttpResponse.BodyHandlers.ofString());
                if(res.statusCode()/100==2){ JsonObject o=JsonParser.parseString(res.body()).getAsJsonObject(); String text=o.has("text")?o.get("text").getAsString():""; if(!text.isBlank() && !text.equals(s.lastPartialText)){ s.lastPartialText=text; NyraMod.handleVoicePartialTranscript(id,text); } }
            } catch(Exception ignored) { }
        });
    }

    private static double rms(short[] pcm) {
        double sum=0; for(short v:pcm){ double x=v; sum += x*x; }
        return Math.sqrt(sum/Math.max(1,pcm.length));
    }

    private static void flushExpired() {
        long now=System.currentTimeMillis();
        for (Map.Entry<UUID,Stream> e : streams.entrySet()) {
            Stream s=e.getValue();
            if (s.pcm.size() > 4800 && now-s.lastSpeech >= NyraMod.voiceFlushSilenceMs()) flush(e.getKey(),s);
        }
    }

    private static void flush(UUID id, Stream s) {
        byte[] pcm=s.pcm.toByteArray();
        long now = System.currentTimeMillis();
        long duration = s.speechStarted > 0 ? Math.max(0, now - s.speechStarted) : 0;
        double avgRms = s.rmsSamples == 0 ? 0 : s.rmsSum / s.rmsSamples;
        boolean quiet = avgRms < 220.0;
        long pauseBefore = s.pauseBefore;
        s.pcm.reset(); s.lastSpeech=now; s.lastFlush=now; s.lastPartialSent=now; s.lastPartialText=""; s.speechStarted=0; s.pauseBefore=0; s.rmsSum=0; s.rmsSamples=0; s.packetCount=0;
        if (pcm.length < 4800) return;
        CompletableFuture.runAsync(() -> {
            try {
                String b64=Base64.getEncoder().encodeToString(wav(pcm,48000,1,16));
                JsonObject body=new JsonObject(); body.addProperty("player_id",id.toString()); body.addProperty("audio_wav_base64",b64);
                HttpRequest req=HttpRequest.newBuilder(URI.create(NyraMod.voiceSttUrl())).timeout(Duration.ofSeconds(15))
                        .header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(body.toString())).build();
                HttpResponse<String> res=HTTP.send(req,HttpResponse.BodyHandlers.ofString());
                if(res.statusCode()/100==2){
                    JsonObject o=JsonParser.parseString(res.body()).getAsJsonObject();
                    String text=o.has("text")?o.get("text").getAsString():"";
                    if(!text.isBlank()) NyraMod.handleVoiceTranscript(id,text,duration,avgRms,quiet,pauseBefore);
                }
            } catch(Exception ignored) { }
        });
    }

    /** Stop Nyra voice playback when a nearby player starts speaking. */
    public static void interruptSpeech() {
        for (AudioPlayer player : ACTIVE_PLAYERS) {
            try { if (player != null && player.isPlaying()) player.stopPlaying(); } catch (Throwable ignored) { }
        }
        ACTIVE_PLAYERS.clear();
    }

    /**
     * Speaks through a locational channel. Long replies are segmented at natural
     * punctuation so Nyra has small pauses instead of one uninterrupted audio blob.
     */
    public static void speakAt(String text, Object serverLevel, double x, double y, double z) {
        if (!NyraMod.ttsEnabled() || api == null || text == null || text.isBlank()) return;
        final List<String> segments = splitSpeech(text);
        CompletableFuture.runAsync(() -> {
            try {
                for (String segment : segments) {
                    if (segment.isBlank()) continue;
                    if (!NyraMod.ttsEnabled()) break;
                    JsonObject body=new JsonObject();
                    body.addProperty("text",segment);
                    body.addProperty("lang",System.getenv().getOrDefault("NYRA_TTS_LANG","ar"));
                    HttpRequest req=HttpRequest.newBuilder(URI.create(NyraMod.ttsUrl())).timeout(Duration.ofSeconds(20))
                            .header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(body.toString())).build();
                    HttpResponse<byte[]> res=HTTP.send(req,HttpResponse.BodyHandlers.ofByteArray());
                    if(res.statusCode()/100!=2 || res.body().length==0) return;
                    Mp3Decoder decoder=api.createMp3Decoder(new java.io.ByteArrayInputStream(res.body()));
                    if(decoder==null) return;
                    short[] audio=decoder.decode();
                    if(audio==null || audio.length==0) return;
                    var level=api.fromServerLevel(serverLevel);
                    var pos=api.createPosition(x,y,z);
                    LocationalAudioChannel channel=api.createLocationalAudioChannel(UUID.randomUUID(),level,pos);
                    if(channel==null) return;
                    channel.setDistance((float)NyraMod.voiceSpeakDistance());
                    AudioPlayer player=api.createAudioPlayer(channel,api.createEncoder(),audio);
                    if(player==null) return;
                    ACTIVE_PLAYERS.add(player);
                    try {
                        player.startPlaying();
                        long waitMs=Math.max(250, (long)((audio.length / 48000.0) * 1000.0) + 80);
                        Thread.sleep(waitMs);
                    } finally {
                        try { if (player.isPlaying()) player.stopPlaying(); } catch (Throwable ignored) { }
                        ACTIVE_PLAYERS.remove(player);
                    }
                    if (segments.size() > 1) Thread.sleep(Math.max(0, NyraMod.voicePauseBetweenSegmentsMs()));
                }
            } catch(Exception ignored) { }
        });
    }

    private static List<String> splitSpeech(String text) {
        String clean=text.replaceAll("\\s+", " ").trim();
        if (clean.length() <= 180) return List.of(clean);
        List<String> out=new ArrayList<>();
        StringBuilder cur=new StringBuilder();
        for (String word : clean.split(" ")) {
            if (cur.length()+word.length()+1 > 180 && cur.length()>0) { out.add(cur.toString().trim()); cur.setLength(0); }
            cur.append(word).append(' ');
            if (cur.length() >= 110 && word.matches(".*[.!?،؛:]$")) { out.add(cur.toString().trim()); cur.setLength(0); }
        }
        if (cur.length()>0) out.add(cur.toString().trim());
        return out.isEmpty()?List.of(clean):out;
    }

    private static byte[] wav(byte[] pcm,int sampleRate,int channels,int bits) {
        ByteArrayOutputStream out=new ByteArrayOutputStream(pcm.length+44);
        try {
            out.write("RIFF".getBytes()); writeLE(out,36+pcm.length,4); out.write("WAVEfmt ".getBytes()); writeLE(out,16,4);
            writeLE(out,1,2); writeLE(out,channels,2); writeLE(out,sampleRate,4); writeLE(out,sampleRate*channels*bits/8,4);
            writeLE(out,channels*bits/8,2); writeLE(out,bits,2); out.write("data".getBytes()); writeLE(out,pcm.length,4); out.write(pcm);
        } catch(Exception ignored) { }
        return out.toByteArray();
    }
    private static void writeLE(ByteArrayOutputStream o,int v,int n){for(int i=0;i<n;i++)o.write((v>>(8*i))&255);}

    private static final class Stream {
        final OpusDecoder decoder; final ByteArrayOutputStream pcm=new ByteArrayOutputStream(); final UUID sessionId=UUID.randomUUID();
        volatile String lastPartialText=""; volatile long lastPacket,lastSpeech,lastFlush,speechStarted,pauseBefore,lastPartialSent;
        volatile double rmsSum; volatile long rmsSamples; volatile int packetCount;
        Stream(OpusDecoder d){decoder=d; long now=System.currentTimeMillis();lastPacket=lastSpeech=lastFlush=now;}
    }
}
