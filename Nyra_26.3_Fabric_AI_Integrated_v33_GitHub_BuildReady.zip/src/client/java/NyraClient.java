package com.nyra.client;

import com.nyra.client.render.NyraEntityModel;
import com.nyra.client.render.NyraEntityRenderer;
import com.nyra.client.render.NyraModelLayers;
import com.nyra.core.manifestation.NyraEntityTypes;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;

/** Client-only registration. The server never loads renderer/model classes. */
public final class NyraClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        NyraModelLayers.register();
        EntityRenderers.register(NyraEntityTypes.NYRA, NyraEntityRenderer::new);
    }
}
