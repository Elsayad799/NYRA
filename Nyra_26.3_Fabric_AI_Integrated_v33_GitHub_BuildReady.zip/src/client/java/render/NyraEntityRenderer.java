package com.nyra.client.render;

import com.nyra.core.NyraMod;
import com.nyra.core.manifestation.NyraEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.ResourceLocation;

public final class NyraEntityRenderer extends MobRenderer<NyraEntity, LivingEntityRenderState, NyraEntityModel> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
            NyraMod.MOD_ID, "textures/entity/nyra.png");

    public NyraEntityRenderer(EntityRendererProvider.Context context) {
        super(context, new NyraEntityModel(context.bakeLayer(NyraModelLayers.MAIN)), 0.28f);
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
        return TEXTURE;
    }
}
