package com.nyra.client.render;

import com.nyra.core.NyraMod;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.resources.ResourceLocation;

public final class NyraModelLayers {
    public static final ModelLayerLocation MAIN = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(NyraMod.MOD_ID, "manifestation"), "main");

    public static LayerDefinition create() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-4, -12, -2, 8, 12, 4), PartPose.ZERO);
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 16)
                        .addBox(-3, -18, -3, 6, 6, 6), PartPose.ZERO);
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(24, 0)
                        .addBox(-1, -11, -1.5f, 2, 10, 3), PartPose.offset(5, 0, 0));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(34, 0)
                        .addBox(-1, -11, -1.5f, 2, 10, 3), PartPose.offset(-5, 0, 0));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(24, 13)
                        .addBox(-1.5f, 0, -1.5f, 3, 10, 3), PartPose.offset(2, 0, 0));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(36, 13)
                        .addBox(-1.5f, 0, -1.5f, 3, 10, 3), PartPose.offset(-2, 0, 0));
        return LayerDefinition.create(mesh, 64, 32);
    }

    public static void register() {
        net.minecraft.client.model.geom.EntityModelSet.class.getName();
        net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry.registerModelLayer(MAIN, NyraModelLayers::create);
    }

    private NyraModelLayers() {}
}
