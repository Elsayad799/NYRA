package com.nyra.client.render;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartNames;
import net.minecraft.resources.ResourceLocation;

public final class NyraEntityModel extends EntityModel<LivingEntityRenderState> {
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;

    public NyraEntityModel(ModelPart root) {
        super(root);
        this.head = root.getChild("head");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
    }

    @Override
    public void setupAnim(LivingEntityRenderState state) {
        float walk = state.walkAnimationPos * 0.6662f;
        float speed = Math.min(state.walkAnimationSpeed, 1.0f);
        leftLeg.xRot = (float)Math.cos(walk) * 1.2f * speed;
        rightLeg.xRot = (float)Math.cos(walk + Math.PI) * 1.2f * speed;
        leftArm.xRot = (float)Math.cos(walk + Math.PI) * 0.8f * speed;
        rightArm.xRot = (float)Math.cos(walk) * 0.8f * speed;
        head.xRot = state.xRot * ((float)Math.PI / 180f);
        head.yRot = state.yRot * ((float)Math.PI / 180f);
    }
}
