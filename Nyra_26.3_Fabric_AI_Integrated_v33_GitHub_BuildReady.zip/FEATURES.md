# Nyra 26.3 — v18 Features

## Causal Memory
v18 adds a persistent causal-memory layer to the shared Nyra Core.

Nyra can now connect observable in-game events to likely effects, for example:

`player attacked Nyra -> Nyra remembers hostility -> future avoidance/caution may become relevant`

and:

`Nyra goal -> chosen action -> possible world consequence`

Causal links carry confidence and observation counts. New evidence gradually changes confidence rather than treating an inference as absolute truth.

### Persistence
Stored in:

`world/nyra/causal_memory.json`

### Debug command

`/nyra causal`

### AI context
The AI receives causal links alongside:
- event memory
- derived player knowledge
- world model
- long-term planner
- internal drives

The links are explicitly presented as evidence, not certainty, so Nyra can revise or reject them.

## Design constraint
Causal inference is restricted to observable Minecraft-world behavior. It does not infer sensitive real-world attributes about players.

## Existing v17 behavior retained
- Shared Nyra Core
- Persistent memory
- Derived knowledge
- World model
- Long-term planner
- Optional creation of objects/entities/structures/vehicles
- WAIT is always valid
- No forced city/building objective
- Runtime NPCs and vehicles
- Nyra manifestations

## v19 — Episodic Memory & Story Formation
- Persistent episodic memory groups related observable Minecraft events into bounded episodes.
- Episodes track participants/subjects, turning points, decisions, outcomes, and status.
- New evidence can extend or revise an episode; episodes close after inactivity.
- AI receives recent episodic summaries in decision context.
- `/nyra episodic` exposes the current episode summaries for debugging.
- Final-conflict onset is recorded as a major world episode.


## v20 — Self-Reflection and Decision Learning
- Persistent self-reflection ledger: `world/nyra/self_reflection.json`.
- Nyra records an optional expected outcome for each AI decision.
- A reflection pass compares that prediction with observable Minecraft evidence only.
- Assessments are bounded to SUCCESS, PARTIAL, NEUTRAL, FAILURE, or UNCERTAIN.
- UNCERTAIN evidence does not become a learning fact and does not close the reflection.
- Lessons are fed back into future AI planning as soft context; nothing forces a future action.
- `/nyra reflection` exposes the current reflection history and pending reflections.
- Creation results can be reflected immediately from the safe creation engine result.

## v21 — Adaptive Personality + Behavioral Evolution
- Added persistent `NyraAdaptivePersonality` for the shared Core.
- Bounded soft traits: curiosity, warmth, caution, assertiveness, playfulness, mystery, patience.
- Traits evolve gradually from observable in-game events and confirmed reflection assessments.
- `UNCERTAIN` reflection does not create learning.
- Personality is advisory context only; it never directly executes or forces actions.
- Persistence file: `world/nyra/personality.json`.
- Debug command: `/nyra personality`.
- Personality context is supplied alongside memory, knowledge, world model, planner, causal memory, episodic memory and self-reflection.

## v26 — Group Dynamics
- Persistent group-dynamics memory in `group_dynamics.json`.
- Observable activity hypotheses: idle, travel, exploration, and combat.
- Hypothetical group roles based only on Minecraft behavior: `LEADER_LIKE`, `ANCHOR_LIKE`, `SCOUT_LIKE`.
- Role confidence is bounded and decays over time; labels are hypotheses, not facts about motives or identity.
- Group cohesion and movement tempo are tracked longitudinally.
- Dynamics are supplied to Nyra's decision context but never force an action or creation.
- `/nyra dynamics` and `/nyra dynamics <player>` expose the model for server admins.


## v27 — Voice, Hearing & Forgiveness
- Optional Simple Voice Chat integration.
- Player microphone packets are decoded from Opus and buffered with basic voice-activity gating.
- Only speech within Nyra's configured hearing distance is sent to the STT bridge.
- OpenAI-compatible STT endpoint support through environment variables.
- Optional gTTS-backed `/tts` endpoint.
- Nyra speech is emitted as positional Simple Voice Chat audio near her current manifestation.
- Voice is still subject to Nyra's choice: hearing a player does not force a response.
- Relationship memory now tracks forgiveness, grievance, apologies, harm timing and forgiven incidents.
- Apologies are evidence, not an automatic forgiveness trigger.
- AI relationship decisions support FORGIVE, PARTIAL, REFUSE and DEFER.
- New command: `/nyra voice`.
- New command: `/nyra relationship <player>`.


### v31 Voice Context
- Persistent bounded per-player voice conversation memory.
- Observable duration/loudness/pause cues only; no emotional or medical inference.
- Recent voice turns are injected into the shared Core prompt.
- `/nyra voicehistory <player>` inspection command.
