import json, unittest

class EpisodicContractTests(unittest.TestCase):
    def test_episode_fields(self):
        fields = {"id","subject","title","status","outcome","startedAt","updatedAt","eventCount","events","turningPoints"}
        self.assertEqual(len(fields), 10)
    def test_story_chain(self):
        chain = ["encounter", "turning point", "decision", "outcome"]
        self.assertEqual(chain[0], "encounter")
        self.assertEqual(chain[-1], "outcome")
    def test_revision_is_allowed(self):
        episode = {"status":"OPEN", "outcome":"uncertain"}
        episode["outcome"] = "revised after new evidence"
        self.assertIn("revised", episode["outcome"])

if __name__ == '__main__':
    unittest.main()
