import json, os, subprocess, sys, urllib.request, time

p=subprocess.Popen([sys.executable, "server.py"], cwd=os.path.dirname(__file__))
try:
    time.sleep(1.0)
    with urllib.request.urlopen("http://127.0.0.1:8787/health", timeout=2) as r:
        data=json.loads(r.read())
    assert data["ok"] is True
    req=urllib.request.Request("http://127.0.0.1:8787/plan", data=json.dumps({"prompt":"Return exactly one token: WAIT"}).encode(), headers={"Content-Type":"application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=5) as r:
        plan=json.loads(r.read())
    assert plan["action"] in {"SPEAK","OBSERVE","FOLLOW","LEAVE","HIDE","HELP","HORROR","HOME","WAIT","CREATE"}
    print("Nyra Core smoke test: PASS")
finally:
    p.terminate(); p.wait(timeout=3)

def test_navigation_controller_exists_and_replans_when_stalled():
    from pathlib import Path
    p = Path(__file__).resolve().parents[1] / 'src/main/java/com/nyra/core/manifestation/NyraNavigationController.java'
    text = p.read_text(encoding='utf-8')
    assert 'STUCK_AFTER_TICKS' in text
    assert 'REPATH_INTERVAL_TICKS' in text
    assert 'getNavigation().moveTo' in text
    assert 'getNavigation().stop' in text


def test_manifestation_manager_uses_shared_navigation_controller():
    from pathlib import Path
    p = Path(__file__).resolve().parents[1] / 'src/main/java/com/nyra/core/manifestation/NyraManifestationManager.java'
    text = p.read_text(encoding='utf-8')
    assert 'NyraNavigationController navigation' in text
    assert 'navigation.follow' in text
    assert 'navigation.goTo' in text
    assert 'navigation.stop(entity)' in text
