import unittest

class SelfReflectionContractTests(unittest.TestCase):
    def test_decision_prediction_fields(self):
        decision = {"action":"INVESTIGATE", "goal":"INVESTIGATE", "expected_outcome":"find evidence"}
        self.assertIn("expected_outcome", decision)

    def test_assessments_are_bounded(self):
        allowed = {"SUCCESS", "PARTIAL", "NEUTRAL", "FAILURE", "UNCERTAIN"}
        self.assertEqual(len(allowed), 5)

    def test_uncertain_does_not_become_learning_fact(self):
        reflection = {"assessment":"UNCERTAIN", "confidence_delta":0.0, "lesson":""}
        self.assertEqual(reflection["confidence_delta"], 0.0)
        self.assertEqual(reflection["lesson"], "")

    def test_learning_loop(self):
        chain = ["decision", "prediction", "observable evidence", "assessment", "lesson", "future context"]
        self.assertEqual(chain[0], "decision")
        self.assertEqual(chain[-1], "future context")

    def test_persistence_file_name(self):
        self.assertEqual("self_reflection.json", "self_reflection.json")

if __name__ == '__main__':
    unittest.main()
