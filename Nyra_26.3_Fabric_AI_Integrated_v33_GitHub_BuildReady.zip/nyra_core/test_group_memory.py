from pathlib import Path

def test_group_memory_persists_temporal_fields():
    source=Path(__file__).resolve().parents[1]/"src/main/java/com/nyra/core/NyraGroupMemory.java"
    text=source.read_text()
    for token in ("firstSeen", "lastSeen", "observations", "sharedEpisodes", "stability", "confidence", "timeline"):
        assert token in text

def test_group_identity_is_order_independent():
    ids=["a","b","c"]
    assert "|".join(sorted(ids)) == "|".join(sorted(reversed(ids)))

def test_group_memory_is_in_game_only():
    source=Path(__file__).resolve().parents[1]/"src/main/java/com/nyra/core/NyraGroupMemory.java"
    text=source.read_text().lower()
    forbidden=["religion","race","ethnicity","sexual orientation","political affiliation","medical"]
    assert not any(x in text for x in forbidden)


def test_group_lifecycle_fields_exist():
    source=Path(__file__).resolve().parents[1]/"src/main/java/com/nyra/core/NyraGroupMemory.java"
    text=source.read_text()
    for token in ("status", "peakSize", "splitCount", "reformationCount", "evolveLifecycle", "FRAGMENTED", "DISSOLVED"):
        assert token in text

def test_group_lifecycle_is_observable_only():
    source=Path(__file__).resolve().parents[1]/"src/main/java/com/nyra/core/NyraGroupMemory.java"
    text=source.read_text().lower()
    forbidden=["shell", "runtime.exec", "processbuilder"]
    assert not any(x in text for x in forbidden)
