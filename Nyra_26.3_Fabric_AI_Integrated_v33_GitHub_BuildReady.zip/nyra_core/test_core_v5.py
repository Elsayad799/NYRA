import json
import server

obj = server._extract_json('{"action":"CREATE","speech":"","goal":"BUILD","target":"Alex","blueprint":{"id":"x"}}')
assert obj["goal"] == "BUILD"
assert obj["target"] == "Alex"
assert server.normalize_token("CREATE now") == "CREATE"
print("v5 core tests passed")
