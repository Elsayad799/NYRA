import json, tempfile, os
# Lightweight mirror test for the persistence contract used by the Java knowledge layer.
def test_confidence_revision_contract():
    facts = {"player:test": {"behavior": {"value": "threatening", "confidence": 0.82, "observations": 1}}}
    assert facts["player:test"]["behavior"]["confidence"] <= 1.0

def test_json_roundtrip():
    with tempfile.TemporaryDirectory() as d:
        p=os.path.join(d,"knowledge.json")
        data={"player:test":{"behavior":{"subject":"player:test","key":"behavior","value":"curious","confidence":0.6,"observations":1}}}
        with open(p,"w",encoding="utf-8") as f: json.dump(data,f)
        with open(p,encoding="utf-8") as f: loaded=json.load(f)
        assert loaded["player:test"]["behavior"]["value"] == "curious"

if __name__ == "__main__":
    test_confidence_revision_contract(); test_json_roundtrip(); print("Nyra knowledge contract tests: PASS")
