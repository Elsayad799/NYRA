import json
from pathlib import Path

# Contract tests for the Java social model's persistence shape and invariants.
def test_pair_key_is_order_independent():
    a='00000000-0000-0000-0000-000000000001'; b='00000000-0000-0000-0000-000000000002'
    assert '|'.join(sorted((a,b))) == '|'.join(sorted((b,a)))

def test_scores_are_bounded():
    for v in (0, .5, 1): assert 0 <= v <= 1

def test_social_model_does_not_encode_sensitive_attributes():
    source=Path(__file__).resolve().parents[1]/'src/main/java/com/nyra/core/NyraSocialModel.java'
    text=source.read_text().lower()
    forbidden=['religion','race','ethnicity','sexual orientation','political affiliation','medical']
    assert not any(x in text for x in forbidden)

def test_persistence_shape_is_explicit():
    source=Path(__file__).resolve().parents[1]/'src/main/java/com/nyra/core/NyraSocialModel.java'
    text=source.read_text()
    assert 'root.add("pairs"' in text
    assert 'NyraSocialModel load' in text
