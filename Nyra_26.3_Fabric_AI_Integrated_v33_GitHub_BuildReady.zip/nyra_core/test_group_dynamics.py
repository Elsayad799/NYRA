from pathlib import Path

SRC = Path(__file__).parents[0].parent / "src/main/java/com/nyra/core/NyraGroupDynamics.java"
TEXT = SRC.read_text(encoding="utf-8")


def test_group_dynamics_is_persistent_and_observable_only():
    for token in ["GroupDynamics", "observeCluster", "save(Path file)", "load(Path file)", "LEADER_LIKE", "ANCHOR_LIKE", "SCOUT_LIKE"]:
        assert token in TEXT
    assert "shell" not in TEXT.lower()
    assert "Runtime.getRuntime" not in TEXT
    assert "ProcessBuilder" not in TEXT


def test_role_confidence_is_bounded():
    assert "r.confidence=clamp" in TEXT
    assert "activityConfidence=clamp" in TEXT
    assert "tempo=clamp" in TEXT
    assert "cohesion=clamp" in TEXT


def test_activity_is_hypothesis_not_forced_world_action():
    for token in ["TRAVEL", "EXPLORATION", "IDLE", "COMBAT", "UNKNOWN"]:
        assert token in TEXT
    assert "createBlueprint" not in TEXT
    assert "execute" not in TEXT.lower()
