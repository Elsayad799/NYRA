from pathlib import Path

ROOT = Path(__file__).parent
SERVER = (ROOT / "server.py").read_text(encoding="utf-8")
REL = (ROOT.parent / "src/main/java/com/nyra/core/Relationship.java").read_text(encoding="utf-8")
MOD = (ROOT.parent / "src/main/java/com/nyra/core/NyraMod.java").read_text(encoding="utf-8")
PLUGIN = (ROOT.parent / "src/main/java/com/nyra/voice/NyraVoicePlugin.java").read_text(encoding="utf-8")


def test_voice_endpoints_exist():
    assert 'self.path == "/tts"' in SERVER
    assert 'self.path == "/voice/transcribe"' in SERVER


def test_stt_is_environment_configured():
    assert 'NYRA_STT_URL' in SERVER
    assert 'NYRA_STT_KEY' in SERVER
    assert 'NYRA_STT_MODEL' in SERVER
    assert 'Authorization' in SERVER


def test_voice_bridge_is_proximity_aware():
    assert 'voiceCanHear' in PLUGIN
    assert 'voice_hear_distance' in (ROOT.parent / "src/main/java/com/nyra/core/NyraConfig.java").read_text(encoding="utf-8")


def test_voice_bridge_uses_opus_and_positional_audio():
    assert 'OpusDecoder' in PLUGIN
    assert 'createLocationalAudioChannel' in PLUGIN
    assert 'createAudioPlayer' in PLUGIN


def test_forgiveness_state_is_persistent_relationship_data():
    for field in ("forgiveness", "grievance", "lastApologyAt", "lastHarmAt", "apologies", "forgivenIncidents"):
        assert field in REL


def test_apology_does_not_automatically_forgive():
    assert 'applyForgivenessDecision' in MOD
    assert 'apology_detected=' in MOD
    assert 'an apology never guarantees forgiveness' in MOD


def test_no_host_shell_in_voice_bridge():
    forbidden = ("Runtime.getRuntime().exec", "ProcessBuilder", "os.system", "subprocess")
    assert not any(x in PLUGIN for x in forbidden)

def test_voice_memory_tracks_sessions():
    src = (ROOT.parent / "src/main/java/com/nyra/core/NyraVoiceMemory.java").read_text(encoding="utf-8")
    assert "SESSION_GAP_MS" in src
    assert "sessionCount" in src
    assert "currentSessionTurns" in src
    assert '"session"' in src

def test_voice_prompt_allows_silence_and_movement():
    src = (ROOT.parent / "src/main/java/com/nyra/core/NyraMod.java").read_text(encoding="utf-8")
    assert "Nyra may answer, stay silent, move closer/farther" in src
    assert "voiceMemory.context(playerId, 12)" in src


def test_voice_presence_and_interruption():
    plugin = PLUGIN
    mod = MOD
    cfg = (ROOT.parent / "src/main/java/com/nyra/core/NyraConfig.java").read_text(encoding="utf-8")
    assert "interruptSpeech" in plugin
    assert "ACTIVE_PLAYERS" in plugin
    assert "voiceInterruptEnabled" in mod
    assert "voicePresenceEnabled" in mod
    assert "voice_interrupt_enabled" in cfg
    assert "voice_presence_enabled" in cfg

def test_voice_playback_has_natural_segmentation():
    assert "splitSpeech" in PLUGIN
    assert "voicePauseBetweenSegmentsMs" in PLUGIN
    assert "stopPlaying" in PLUGIN


def test_voice_ai_can_choose_to_interrupt_player():
    assert "interrupt_player" in SERVER
    assert "interrupt_reason" in SERVER
    assert "interrupt_player" in MOD
    assert "voices may briefly overlap" in MOD
    assert "voice bridge will start Nyra's positional audio" in MOD

def test_interrupt_requires_speech():
    assert "if interrupt_player and not speech.strip(): interrupt_player = False" in SERVER


def test_streaming_partial_interrupt_path():
    assert "voiceStreamingEnabled" in MOD
    assert "voicePartialSttUrl" in MOD
    assert "handleVoicePartialTranscript" in MOD
    voice_plugin = (ROOT.parent / "src/main/java/com/nyra/voice/NyraVoicePlugin.java").read_text()
    assert "sessionId" in voice_plugin
    assert "sendPartial" in voice_plugin
    assert "NYRA_PARTIAL_STT_URL" in SERVER

def test_partial_path_does_not_execute_world_actions():
    start = MOD.find("public static void handleVoicePartialTranscript")
    end = MOD.find("public static void handleVoiceTranscript(UUID playerId, String text)")
    chunk = MOD[start:end]
    assert "NyraVoicePlugin.speakAt" in chunk
    assert "applyPlan" not in chunk
    assert "Do not execute or request movement" in chunk
