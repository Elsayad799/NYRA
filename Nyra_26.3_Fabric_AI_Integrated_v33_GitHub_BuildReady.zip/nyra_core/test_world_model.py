import json, tempfile, unittest

class WorldModelContractTests(unittest.TestCase):
    def test_world_model_contract_example(self):
        sample = {"places": {}, "anomalies": {}, "threads": {}}
        self.assertEqual(set(sample), {"places", "anomalies", "threads"})
    def test_persistence_shape(self):
        with tempfile.NamedTemporaryFile(mode='w+', suffix='.json') as f:
            json.dump({"places":{"p":{}},"anomalies":{"a":{}},"threads":{"t":{}}}, f)
            f.flush(); f.seek(0)
            data=json.load(f)
            self.assertIn("places", data); self.assertIn("anomalies", data); self.assertIn("threads", data)

if __name__ == '__main__': unittest.main()
