import unittest

class PlannerContractTests(unittest.TestCase):
    def test_advisory_contract(self):
        context = "planner={phase=ACTIVE, thread=thread:one, stagnant=false; candidate_focus=[free_exploration_or_WAIT]; rule=advisory_only}"
        self.assertIn("advisory_only", context)
        self.assertIn("free_exploration_or_WAIT", context)

    def test_plan_fields(self):
        plan = {"action":"INVESTIGATE","goal":"INVESTIGATE","thread_id":"thread:anomaly","next_step":"revisit cave","commitment":"long-term"}
        self.assertEqual(plan["goal"], "INVESTIGATE")
        self.assertTrue(plan["thread_id"])
        self.assertTrue(plan["next_step"])

    def test_persistence_contract(self):
        fields = {"currentThread", "phase", "startedAt", "lastProgressAt", "steps", "completed", "abandoned"}
        self.assertEqual(len(fields), 7)

if __name__ == '__main__':
    unittest.main()
