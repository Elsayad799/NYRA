#!/usr/bin/env python3
"""Nyra Core service.

The Minecraft mod owns world state and execution. This process owns AI routing,
structured decisions and optional TTS integration. API keys are environment-only.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json, os, random, time, urllib.request, base64, tempfile, io

HOST = os.getenv("NYRA_HOST", "127.0.0.1")
PORT = int(os.getenv("NYRA_PORT", "8787"))
MODEL = os.getenv("NYRA_MODEL", "default")

PROVIDERS = [
    {"name": "primary", "url": os.getenv("NYRA_PRIMARY_URL", ""), "key": os.getenv("NYRA_PRIMARY_KEY", "")},
    {"name": "secondary", "url": os.getenv("NYRA_SECONDARY_URL", ""), "key": os.getenv("NYRA_SECONDARY_KEY", "")},
    {"name": "tertiary", "url": os.getenv("NYRA_TERTIARY_URL", ""), "key": os.getenv("NYRA_TERTIARY_KEY", "")},
]

SYSTEM = (
    "You are Nyra, a fictional autonomous Minecraft world character and the single decision-maker for her shared Core. "
    "You share one persistent identity across manifestations. Every capability is optional. You may speak, stay silent, "
    "observe, move, help, hide or create in-game content. Never assume that building is required. A city is only an optional creation type. "
    "Keep all actions inside Minecraft. Internal drives may influence choices, but they never force an action. "
    "Do not claim real-world consciousness. Never output executable Java/Python/shell code. "
    "Derived knowledge is evidence from observable Minecraft events, with confidence values; it can be wrong, revised, or incomplete. "
    "Self-reflection compares predictions with observable outcomes and produces revisable lessons; uncertainty is not learning. Adaptive personality evolves slowly from repeated observable in-game experience and is only soft context; it never directly forces an action. Group intelligence tracks observable group formation, persistence, fragmentation, dormancy, dissolution, and reformation; these are probabilistic in-game inferences and must remain revisable. "
    "Never treat a low-confidence inference as a fact, and never infer sensitive real-world traits from player behavior. Group history is longitudinal evidence about repeated in-game co-presence and shared episodes; it is probabilistic, membership can change, and old interpretations must remain revisable."
)

TOKENS = ("SPEAK", "OBSERVE", "FOLLOW", "LEAVE", "HIDE", "HELP", "HORROR", "HOME", "WAIT", "CREATE", "MOVE", "ROAM", "INVESTIGATE")

PLAN_SCHEMA = """Return ONLY valid JSON with keys: action, speech, blueprint, goal, target, reason, thread_id, next_step, commitment, expected_outcome, forgiveness_decision, forgiveness_reason, interrupt_player, interrupt_reason. action must be one of SPEAK,OBSERVE,FOLLOW,LEAVE,HIDE,HELP,HORROR,HOME,WAIT,CREATE,MOVE,ROAM,INVESTIGATE. WAIT is valid and means do nothing. Do not create anything merely because creation is available. goal must be one of OBSERVE,ROAM,BUILD,INVESTIGATE,FOLLOW,HIDE,RETURN_HOME,WAIT. target is a short player/entity label or empty. reason is a short explanation of Nyra's internal choice. thread_id is an optional stable long-term thread identifier. next_step is an optional short next investigation/action step. commitment is an optional short-term/medium-term/long-term label. expected_outcome is an optional concise prediction of what Nyra expects to observe after the decision. forgiveness_decision must be FORGIVE, PARTIAL, REFUSE, or DEFER when relationship context is present; it is a decision about the in-game relationship only. forgiveness_reason is optional and concise. interrupt_player is a boolean. When responding to proximity voice, Nyra may choose true to deliberately interrupt the player mid-thought when she has a reason to speak immediately (for example a warning, urgent observation, refusal to continue the conversation, or a strong conversational boundary). This is a conversational choice, not a forced reaction. If interrupt_player is true, speech should be non-empty and concise enough to work as an interruption. interrupt_reason is optional and concise. If drives are supplied, use them as soft context, not hard rules. For CREATE, blueprint must contain id, kind, x,y,z,width,height,depth,maxBlocks,primitives; kind may be any safe declarative type such as object, chair, vehicle, npc, settlement, city, or custom. Each primitive has block,x,y,z,dx,dy,dz. Never include executable code. Derived knowledge is evidence, not certainty; use confidence to weigh it and allow future evidence to revise it."""


def local_fallback(prompt: str) -> str:
    p = prompt.lower()
    if "exactly one token" in p or "return one token" in p:
        if any(k in p for k in ("hostility=0.9", "hostility=1", "attacked")):
            return "HORROR"
        return random.choice(("OBSERVE", "WAIT", "FOLLOW", "HOME"))
    if "core" in p or "big nyra" in p:
        return "ليس كل شيء يجب أن تعرفه الآن."
    return random.choice(("...", "ليس الآن.", "أنا أراقب.", "اتبع الإشارة."))


def call_provider(provider, prompt):
    if not provider["url"]:
        raise RuntimeError("provider not configured")
    body = json.dumps({
        "model": MODEL,
        "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}],
        "temperature": 0.7,
        "max_tokens": 256,
    }).encode()
    headers = {"Content-Type": "application/json"}
    if provider["key"]:
        headers["Authorization"] = "Bearer " + provider["key"]
    req = urllib.request.Request(provider["url"], data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=15) as response:
        data = json.loads(response.read().decode())
    text = data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
    if not text:
        raise RuntimeError("empty provider response")
    return text


def decide(prompt):
    # Provider choice remains replaceable; failure never changes Nyra identity.
    ordered = list(PROVIDERS)
    if any(k in prompt.lower() for k in ("decision", "exactly one token", "choose one")):
        ordered.reverse()
    failures = []
    for provider in ordered:
        try:
            return call_provider(provider, prompt), provider["name"]
        except Exception as exc:
            failures.append(f"{provider['name']}: {type(exc).__name__}")
    return local_fallback(prompt), "local-fallback"


def normalize_token(text):
    if not text:
        return "WAIT"
    upper = text.strip().upper()
    for token in TOKENS:
        if upper == token or upper.startswith(token + " "):
            return token
    return "WAIT"


def _extract_json(text):
    if not text:
        return None
    raw = text.strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()
    try:
        value = json.loads(raw)
        return value if isinstance(value, dict) else None
    except Exception:
        start, end = raw.find("{"), raw.rfind("}")
        if start >= 0 and end > start:
            try:
                value = json.loads(raw[start:end+1])
                return value if isinstance(value, dict) else None
            except Exception:
                return None
    return None


def plan(prompt):
    text, provider = decide(prompt + "\n" + PLAN_SCHEMA)
    obj = _extract_json(text)
    if obj:
        action = normalize_token(str(obj.get("action", "WAIT")))
        speech = str(obj.get("speech", ""))[:500]
        blueprint = obj.get("blueprint") if isinstance(obj.get("blueprint"), dict) else None
        goal = str(obj.get("goal", "WAIT")).upper() if obj else "WAIT"
        allowed_goals = {"OBSERVE","ROAM","BUILD","INVESTIGATE","FOLLOW","HIDE","RETURN_HOME","WAIT"}
        if goal not in allowed_goals: goal = "WAIT"
        target = str(obj.get("target", ""))[:120] if obj else ""
        reason = str(obj.get("reason", ""))[:240] if obj else ""
        thread_id = str(obj.get("thread_id", ""))[:120] if obj else ""
        next_step = str(obj.get("next_step", ""))[:240] if obj else ""
        commitment = str(obj.get("commitment", ""))[:40] if obj else ""
        expected_outcome = str(obj.get("expected_outcome", ""))[:320] if obj else ""
        forgiveness_decision = str(obj.get("forgiveness_decision", "DEFER")).upper() if obj else "DEFER"
        if forgiveness_decision not in {"FORGIVE","PARTIAL","REFUSE","DEFER"}: forgiveness_decision = "DEFER"
        forgiveness_reason = str(obj.get("forgiveness_reason", ""))[:240] if obj else ""
        interrupt_player = bool(obj.get("interrupt_player", False)) if obj else False
        interrupt_reason = str(obj.get("interrupt_reason", ""))[:240] if obj else ""
        if interrupt_player and not speech.strip(): interrupt_player = False
        return {"action": action, "speech": speech, "blueprint": blueprint, "goal": goal, "target": target, "reason": reason, "thread_id": thread_id, "next_step": next_step, "commitment": commitment, "expected_outcome": expected_outcome, "forgiveness_decision": forgiveness_decision, "forgiveness_reason": forgiveness_reason, "interrupt_player": interrupt_player, "interrupt_reason": interrupt_reason, "text": text, "provider": provider}
    return {"action": normalize_token(text), "speech": "", "blueprint": None, "goal": "WAIT", "target": "", "reason": "provider did not return structured JSON", "thread_id": "", "next_step": "", "commitment": "", "expected_outcome": "", "forgiveness_decision": "DEFER", "forgiveness_reason": "", "interrupt_player": False, "interrupt_reason": "", "text": text, "provider": provider}

REFLECT_SCHEMA = """Return ONLY valid JSON with keys: assessment, observed_outcome, lesson, confidence_delta, keep_strategy. assessment must be SUCCESS, PARTIAL, NEUTRAL, FAILURE, or UNCERTAIN. observed_outcome must summarize only observable Minecraft evidence. lesson must be a concise reusable lesson about Nyra's decision-making, not a claim about real-world people. confidence_delta must be between -0.30 and 0.30. keep_strategy must be true or false. Do not invent evidence. If evidence is insufficient, use UNCERTAIN and a near-zero confidence_delta."""


def reflect(prompt):
    text, provider = decide(prompt + "\n" + REFLECT_SCHEMA)
    obj = _extract_json(text)
    if obj:
        assessment = str(obj.get("assessment", "UNCERTAIN")).upper()
        if assessment not in {"SUCCESS","PARTIAL","NEUTRAL","FAILURE","UNCERTAIN"}: assessment = "UNCERTAIN"
        observed = str(obj.get("observed_outcome", ""))[:360]
        lesson = str(obj.get("lesson", ""))[:360]
        try: delta = max(-0.30, min(0.30, float(obj.get("confidence_delta", 0.0))))
        except Exception: delta = 0.0
        keep = bool(obj.get("keep_strategy", False))
        return {"assessment": assessment, "observed_outcome": observed, "lesson": lesson, "confidence_delta": delta, "keep_strategy": keep, "text": text, "provider": provider}
    return {"assessment":"UNCERTAIN", "observed_outcome":"", "lesson":"Insufficient structured evidence; defer learning.", "confidence_delta":0.0, "keep_strategy":False, "text":text, "provider":provider}


class Handler(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        raw = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == "/health":
            self._json(200, {"ok": True, "service": "nyra-core", "time": time.time(), "providers": len(PROVIDERS)})
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size > 1024 * 1024:
                return self._json(413, {"error": "request too large"})
            data = json.loads(self.rfile.read(size) or b"{}")
        except Exception:
            return self._json(400, {"error": "invalid json"})
        if self.path == "/decide":
            text, provider = decide(str(data.get("prompt", "")))
            return self._json(200, {"text": text, "provider": provider})
        if self.path == "/plan":
            return self._json(200, plan(str(data.get("prompt", ""))))
        if self.path == "/reflect":
            return self._json(200, reflect(str(data.get("prompt", ""))))
        if self.path == "/tts":
            return self._tts(data)
        if self.path == "/voice/partial":
            upstream = os.getenv("NYRA_PARTIAL_STT_URL", "").strip()
            if not upstream:
                return self._json(200, {"text": "", "partial": True})
            try:
                req = urllib.request.Request(upstream, data=json.dumps(data).encode(), headers={"Content-Type": "application/json"}, method="POST")
                with urllib.request.urlopen(req, timeout=5) as response:
                    result = json.loads(response.read().decode())
                return self._json(200, {"text": str(result.get("text", ""))[:500], "partial": True})
            except Exception as exc:
                return self._json(502, {"error": f"partial STT unavailable: {type(exc).__name__}"})
            return
        if self.path == "/voice/transcribe":
            return self._transcribe(data)
        return self._json(404, {"error": "not found"})

    def _tts(self, data):
        text = str(data.get("text", "")).strip()[:800]
        lang = str(data.get("lang", os.getenv("NYRA_TTS_LANG", "ar")))[:12]
        if not text:
            return self._json(400, {"error": "empty text"})
        # Optional gTTS adapter. Credentials are not required; outbound network access is used by gTTS.
        try:
            from gtts import gTTS
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as f:
                path=f.name
            try:
                gTTS(text=text, lang=lang).save(path)
                raw=open(path,"rb").read()
            finally:
                try: os.unlink(path)
                except OSError: pass
            self.send_response(200); self.send_header("Content-Type","audio/mpeg"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
        except Exception as exc:
            return self._json(501, {"error": f"TTS unavailable: {type(exc).__name__}"})

    def _transcribe(self, data):
        # OpenAI-compatible STT gateway. It accepts a base64 WAV and returns {text}.
        raw_b64 = str(data.get("audio_wav_base64", ""))
        player_id = str(data.get("player_id", ""))[:80]
        if not raw_b64:
            return self._json(400, {"error": "missing audio_wav_base64"})
        try:
            audio=base64.b64decode(raw_b64, validate=True)
        except Exception:
            return self._json(400, {"error": "invalid audio encoding"})
        if len(audio) > 2_000_000:
            return self._json(413, {"error": "audio too large"})
        url=os.getenv("NYRA_STT_URL", "")
        key=os.getenv("NYRA_STT_KEY", "")
        model=os.getenv("NYRA_STT_MODEL", "whisper-1")
        if not url:
            return self._json(501, {"error": "NYRA_STT_URL is not configured", "player_id": player_id})
        boundary="----NyraVoiceBoundary" + str(int(time.time()*1000))
        def part(name, value, filename=None, content_type=None):
            head=f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\""
            if filename: head += f"; filename=\"{filename}\""
            head += "\r\n"
            if content_type: head += f"Content-Type: {content_type}\r\n"
            return head.encode()+b"\r\n"+value+b"\r\n"
        body=part("model", model.encode())+part("file", audio, "audio.wav", "audio/wav")+f"--{boundary}--\r\n".encode()
        headers={"Content-Type":f"multipart/form-data; boundary={boundary}"}
        if key: headers["Authorization"]="Bearer "+key
        try:
            req=urllib.request.Request(url,data=body,headers=headers,method="POST")
            with urllib.request.urlopen(req,timeout=30) as response:
                obj=json.loads(response.read().decode())
            text=str(obj.get("text", "")).strip()[:1000]
            return self._json(200,{"text":text,"player_id":player_id})
        except Exception as exc:
            return self._json(502,{"error":f"STT provider failed: {type(exc).__name__}","player_id":player_id})

    def log_message(self, *_):
        pass


if __name__ == "__main__":
    print(f"Nyra Core listening on http://{HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
