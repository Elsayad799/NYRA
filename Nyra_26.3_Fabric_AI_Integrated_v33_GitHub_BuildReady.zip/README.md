# Nyra 26.3 Fabric AI — v7

Nyra is a persistent Minecraft AI architecture with one shared Core and multiple physical manifestations.

## v7 focus
This release adds shared-Core physical movement control: FOLLOW, HIDE, RETURN_HOME, ROAM/OBSERVE/INVESTIGATE and WAIT are executed by the manifestation manager without giving manifestations independent AI.

## v6 focus
This release introduces the first real custom `NyraEntity` instead of relying exclusively on ArmorStands. The server owns entity state/behavior and the client owns rendering, matching Fabric's current architecture.

## Build target
- Minecraft Java 26.3
- Fabric Loader 0.19.5
- Fabric API 0.160.5+26.3
- Fabric Loom 1.17-SNAPSHOT
- Java 25

## Runtime
The Minecraft mod talks to the external Nyra Core at `http://127.0.0.1:8787` by default. Provider keys remain environment-only.

## Important
A full Gradle/Minecraft build has not been claimed in this environment because Java 25 and the required Gradle dependency cache are unavailable here. Run the project with the target toolchain before treating the JAR as production-ready.

### v16 knowledge memory
Nyra now separates raw events from derived knowledge. The knowledge layer is confidence-based and revisable, so repeated evidence strengthens a fact while conflicting evidence can replace or weaken it. It is stored in `world/nyra/knowledge.json` and exposed to the AI as evidence rather than certainty.

### v19 — Episodic Memory
Nyra now groups events and decisions into persistent episodes rather than treating every event as isolated. Episodes are stored in `world/nyra/episodic_memory.json` and exposed to the AI as revisable story context. This remains an in-game observable memory system and does not infer sensitive real-world traits.


### v20 self-reflection
Nyra now records predictions about her own decisions and periodically reviews them against observable in-game evidence. Reflections are persistent, confidence-bounded, revisable, and advisory. An uncertain result is not treated as a learned fact. Use `/nyra reflection` to inspect the ledger.

### v21 Adaptive Personality
Nyra's shared Core now maintains a slowly changing behavioral profile. Repeated observable Minecraft experiences can nudge bounded traits such as curiosity, warmth, caution, assertiveness, playfulness, mystery and patience. The profile is advisory input for the AI and never hard-codes a behavior or forces creation. It persists in `world/nyra/personality.json` and can be inspected with `/nyra personality`.

### Group Dynamics (v26)
Nyra now maintains a persistent, behavior-only model of player groups. It observes proximity, movement, cohesion, and recorded player-vs-player combat to form bounded hypotheses about current group activity and possible behavioral roles. These hypotheses are context for Nyra's Core only; they do not force building, combat, travel, or any other action.

State is stored in `world/nyra/group_dynamics.json` and can be inspected with `/nyra dynamics` or `/nyra dynamics <player>`.


## v27 Voice + Relationship

Nyra v27 adds an optional Simple Voice Chat bridge. Simple Voice Chat provides proximity voice, push-to-talk/voice activation and configurable voice distance; its API exposes microphone packets, Opus decoding, and server-side positional audio channels.

### Enable
1. Install a matching Simple Voice Chat Fabric build on the server and every client that should use the microphone.
2. Keep the Simple Voice Chat UDP port configured/open (default is 24454).
3. In the world Nyra config, set `voice_enabled` to `true`.
4. Set `tts_enabled` to `true` only if you also want spoken Nyra responses.
5. Configure `NYRA_STT_URL`, `NYRA_STT_KEY`, and `NYRA_STT_MODEL` for an OpenAI-compatible speech-to-text endpoint.
6. Install Python requirements so the optional gTTS adapter is available for `/tts`.

Voice is proximity-aware: the bridge forwards microphone audio to STT only while the player is within Nyra's configured hearing distance. Nyra can still choose to remain silent after hearing speech.

### Forgiveness
Player relationships now retain `forgiveness`, `grievance`, apology count, harm timestamp and forgiven-incident count. Voice or text apologies are evidence for Nyra's decision, not an automatic reset. The AI may choose `FORGIVE`, `PARTIAL`, `REFUSE`, or `DEFER`; forgiveness does not erase the underlying memory of an attack.

## v31 — Voice Context + Conversational Memory

Voice conversations now have a persistent bounded history per player. Each retained turn includes the transcript plus observable audio/session cues: duration, pause before the turn, and a coarse loudness bucket. These cues are explicitly treated as interaction metadata, not as proof of emotion, health, intent, or mental state.

The recent voice history is fed back into Nyra's shared Core so she can maintain conversational continuity, while the Core remains free to answer, stay silent, move away, or end an interaction. State is stored in `world/nyra/voice_memory.json` and can be inspected with `/nyra voicehistory <player>`.
