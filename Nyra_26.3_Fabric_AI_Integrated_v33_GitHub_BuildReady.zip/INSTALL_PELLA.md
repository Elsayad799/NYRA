# Pella.app quick install

1. Create/choose a Minecraft Java Edition Fabric 26.3 server.
2. Ensure Java 25 is selected.
3. Upload Fabric API and `nyra-0.1.0.jar` into `mods/`.
4. Start the server once, stop it, then edit `world/nyra/config.json`.
5. Keep `core_url` as `http://127.0.0.1:8787` if the Core process runs beside Minecraft.
6. Start `nyra_core/server.py` with Python 3 if Pella provides a persistent Python process.
7. Configure AI providers only with environment variables; never put keys into the JAR or Git repository.
8. Restart Minecraft.
9. Use `/nyra status` as an operator.

If Pella only permits one Minecraft process and no sidecar process, leave the Core URL enabled anyway: the Java mod will use the deterministic local fallback when the external service is unavailable. This preserves gameplay but not full external-model reasoning.
