# NYRA + Easy LLM Voice Agent ideas (Minecraft 1.20.1)

This update adapts selected ideas from Koichiro-terao/Easy-LLM-Voice-Agent-in-Minecraft instead of copying its full platform. That reference targets Minecraft Java 1.21 and launches several Docker services; this project targets 1.20.1, so its mods and Python agent are not drop-in compatible.

## Included in this update

- Restores safe idle movement for `NyraEntity`: water-avoiding wandering, looking at nearby players, and looking around. The shared NYRA Core still owns identity, memory, relationships and high-level decisions.
- Sets `voicechat_api_version=2.6.0`; the previous `2.4.10` dependency cannot be resolved from the configured Maven repository. The API 2.6.0 artifact is published by the Simple Voice Chat project.
- Keeps the existing NYRA Python Core and its HTTP-based planner/voice bridge. No separate Sally agent, Docker server, or OpenAI key is silently introduced.

## Important limits

- This does not yet implement a WebSocket bridge compatible with Easy LLM Voice's protocol. That needs a deliberate adapter and runtime testing; blindly copying the reference's 1.21 mod code into 1.20.1 would be unsafe.
- The new vanilla goals make Nyra wander and notice nearby players; they do not guarantee context-aware movement. The next stage should let the Core request a constrained MOVE/FOLLOW/ROAM action and have the Minecraft executor validate it.
- The wardrobe assets remain a library. This change does not yet bind the supplied PNG/GLB files to the entity renderer, so it does not claim to fix the black appearance.
- Build and in-game behavior must be confirmed by GitHub Actions and a test world. No successful build is claimed here.

Reference: https://github.com/Koichiro-terao/Easy-LLM-Voice-Agent-in-Minecraft (MIT-licensed project; target version and prerequisites differ from NYRA).
