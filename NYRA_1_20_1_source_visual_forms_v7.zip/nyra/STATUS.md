# NYRA — implementation status (Minecraft 1.20.1 + Fabric)

## Verified in this workspace
- All Python Core test scripts passed individually in the latest offline run, including council, Minecraft capability, and AI world-action contract checks.
- Python source syntax check: run before packaging.
- JSON resources/config examples parse successfully.
- The project configuration targets Minecraft 1.20.1, Fabric API 0.92.5, Java 17, Gradle 8.7, and stable Fabric Loom 1.6.12.

## Not verified here
- **No Gradle/Minecraft build was run.** This environment has no Gradle executable and cannot resolve external hosts, so no JAR is included.
- Java compilation against the real Minecraft/Fabric/Simple Voice Chat dependencies has not been verified.
- Loading the mod, spawning/rendering Nyra, watcher timing/visibility, movement, voice chat, STT, TTS, and performance on Pojav/Termux require real runtime tests.
- The client entrypoint, custom humanoid model, renderer, and `nyra.png` texture are present under `src/client/java` and `src/main/resources`; these still need a real client launch to verify rendering.
- Whisper Arabic accuracy and simultaneous Minecraft + Core + Whisper performance are not verified.

## Latest changes in this pass
- Added AI-selected BREAK, GIVE, and MOB_COMMAND actions to the structured Python plan contract. Java revalidates coordinates, distance, block safety, item registry IDs, item count, and the mob-order allowlist before execution; player damage and executable model code are not permitted. Direct chat and autonomous decisions now use the same plan executor. These Java changes are not yet compile-verified against the actual Minecraft/Fabric dependencies.
- Added a bounded optional multi-model council to the Python Core (`NYRA_COUNCIL_SIZE=2`): configured providers can return structured candidate plans in parallel; valid action proposals are voted on and one real candidate is selected. Single-provider mode remains available for lower latency. Added offline council tests.
- Fixed a plan-schema mismatch: `RECRUIT` was allowed by the JSON schema but missing from the action normalizer, which could silently convert recruitment plans to `WAIT`.
- Added the first operational mob recruitment manager. `/nyra recruit <radius>` recruits nearby mobs, `/nyra army` reports the total, and `/nyra release` releases them without deleting them. Recruitment tags persist with entity saves; recruited mobs regroup around nearby Nyra manifestations, and passive recruits can target nearby hostile monsters. The Core planner may choose `RECRUIT` or `MOB_COMMAND` when useful; `FOLLOW`, `GUARD`, `DEFEND`, and `WAIT` orders are stored as entity tags and applied by the mob manager. This is not yet a full override of every vanilla mob AI, especially hostile mobs' built-in target goals.
- Added independent spoken-output toggles: `/nyra voice tts on|off`. This no longer requires enabling microphone/STT. Microphone capture stays opt-in via `/nyra voice on|off`, default off. Spoken output still requires Simple Voice Chat and a functioning Core TTS endpoint.
- Updated the Python Core plan schema to recognize the `RECRUIT` action and added static contract checks for voice and recruitment wiring.

## Changes made in earlier pass
- Pinned Fabric Loom to stable `1.6.12` instead of `1.6-SNAPSHOT`.
- Added `NyraConfig.save(...)`, which was referenced by command handlers but missing from the source. This fixes a definite Java compile error.
- Moved the default hidden Core marker to the project's current lore coordinates `(666, 66, 666)` and migrated the old built-in placeholder coordinate when found in a world config.
- Added a non-destructive `NyraHorrorDirector`: configurable levels 1–4 can trigger occasional cave ambience, short smoke traces behind a player, restrained Arabic whispers, rare corrupted `ELSAYAD799` messages while underground, and at levels 3–4 a brief faceless armor-stand silhouette that appears behind the player and vanishes when a nearby player looks directly at it. It expires automatically and is cleaned up when the server stops; it does not modify blocks or damage players.
- Added `/nyra lore` as an in-world clue and a one-time clue near the configured Core marker.
- Changed the sample config's `allow_nyra_damage_to_players` to `false`.

## Still incomplete
- A dedicated animated Faceless Watcher model/texture is not implemented; the current first pass uses a temporary armored armor stand.
- Complete Obelisk Cipher / Lawh al-Ahd al-Mansi / Lisan al-Hajar puzzle progression and persistent per-player clue tracking.
- The new BREAK/GIVE Java execution path has not been compiled against real Minecraft/Fabric dependencies or runtime-tested; treat it as source-level work pending a real Gradle build.
- Full ELSAYAD799 message sequence, real decryption/puzzle logic, and persistent per-player cave progression; only rare atmospheric corrupted messages are currently implemented.
- GeckoLib integration and expressive animation.
- Confirmed Simple Voice Chat API compatibility and real microphone-to-Arabic-STT-to-Nyra-to-TTS end-to-end behavior. TTS and microphone capture have independent toggles, but still need runtime validation.
- Actual build and in-game validation. Fix any compile errors reported by the first real Gradle build before treating this as install-ready.

### Visual forms update (2026-10-10)
Added separate 64x32 pixel-art textures for feminine, masculine, shadow, horror, and big forms; added horn/tendril model parts and renderer scaling; synchronized form changes into an existing manifestation; added `/nyra form <player> <form>` for testing. This is source-level implementation only: the Minecraft/Fabric client has not been compiled or launched in this environment, so rendering/API compatibility remains unverified.
