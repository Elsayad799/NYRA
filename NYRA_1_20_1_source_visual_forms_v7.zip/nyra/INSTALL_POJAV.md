# Install on PojavLauncher (Android) — Minecraft 1.20.1 + Fabric

## Client (the game)
1. In Pojav create a profile: Minecraft **1.20.1**, Fabric Loader (0.15 or newer; 0.19.5 is the confirmed one), **Java 17**.
2. Put into the profile's `mods` folder: Fabric API for 1.20.1 and `nyra-*.jar` (from the GitHub Actions artifact).
3. Optional voice: Simple Voice Chat for Fabric 1.20.1 (its licence is All Rights Reserved: install the official jar, never bundle it).
4. Launch once. Nyra data is created in `<world>/nyra/` (config, memory...).

## Python Core (the brain) — Termux
1. Install Termux from F-Droid. `pkg install python`.
2. Copy `nyra_core/` to the phone. Create `nyra.env` from `.env.example`, fill the DeepSeek key ONLY there.
3. `set -a; . ./nyra.env; set +a; python3 server.py`
4. Keep Termux alive: acquire its wake lock; on Android 12+ the "phantom process killer" may kill it (signal 9),
   then disable it via adb (`settings put global settings_enable_monitor_phantom_procs false`) and exclude Termux from battery optimisation.
5. In game, as operator: `/nyra core test` shows Core health and each provider's status.

## Useful commands
`/nyra status` · `/nyra autonomy off|on` · `/nyra horror off|<0-4>` · `/nyra voice off|on` · `/nyra core test`
`autonomy off` stops all autonomous movement/decisions immediately. `horror off` sets intensity 0.

## Local speech-to-text (optional, untested on a phone)
Build whisper.cpp in Termux with `-DGGML_NO_OPENMP=ON`, download a MULTILINGUAL model, then set the `NYRA_STT_*`
variables in `nyra.env`. Voice is OFF by default; it processes audio only while `/nyra voice on` and the temp audio is deleted after each utterance.
