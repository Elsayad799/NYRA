# NYRA interaction, wardrobe and voice setup (Minecraft Java 1.20.1)

## Player interaction
- `nyra-talk <message>` is available to normal players and routes the message through Nyra's existing chat/Core path. Example: `/nyra-talk أنا زعلان منك يا نايرا`.
- Normal chat containing `نايرا` or `nyra` also wakes her chat decision path. Insults, threats, apologies and attacks are recorded in the relationship state; the AI may ignore, answer, withdraw or react. This is intentionally not a guaranteed anger trigger.
- Nyra remains invulnerable to normal player attacks. An attack is remembered as a harmful social event; it no longer removes the manifestation.
- Replies are sent in ordinary Minecraft chat by default. Voice is optional and requires a running Nyra Core with the configured STT/TTS endpoints.

## Simple Voice Chat
- This project compiles against Simple Voice Chat API 2.4.10 to match the supplied `voicechat-fabric-1.20.1-2.4.10` runtime mod. Install that mod on the server and clients as required by its own instructions.
- Enable voice processing with `/nyra voice on`; enable spoken output with `/nyra voice tts on`. These features still require the external Core endpoints (`/voice/transcribe` and `/tts`) to be running and reachable. If speech output is unavailable, the normal in-game chat response remains the fallback.
- This version does NOT automatically create a passwordless Voice Chat group. The supplied voice-chat JAR is a third-party runtime mod, not source code to merge into Nyra; creating/managing groups needs an explicit API-supported implementation and must not silently place players into a public group.

## Wardrobe library
The files under `assets/nyra/wardrobe/library` are the supplied PNG and GLB assets stored for cataloging/conversion. They are NOT all active in-game skins yet: arbitrary PNG illustrations are not necessarily Minecraft 64x64/64x32 skin maps, and GLB models cannot be rendered by Minecraft's standard entity renderer without conversion/custom rendering. The current entity renderer remains the runtime appearance. Convert and validate each asset before enabling it in the wardrobe selector. Keep creator attribution and license information alongside each asset.

## AI source files
The uploaded AI ZIP contains unrelated Telegram bots, session/cookie material, and unofficial provider integrations. Those files are not blindly executed or copied into the game mod. Nyra continues to use its existing Python Core API (`core_url`) so provider logic can be reviewed and integrated safely without bundling account sessions, tokens, or unrelated polling loops. Remove/rotate any real credentials that were present in the uploaded archive.
