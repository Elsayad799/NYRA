package com.nyra.client;

import com.nyra.client.render.NyraEntityModel;
import com.nyra.client.render.NyraEntityRenderer;
import com.nyra.client.render.NyraModelLayers;
import com.nyra.core.manifestation.NyraEntityTypes;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

/** Client-only registration. The server never loads renderer/model classes. */
public final class NyraClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        NyraModelLayers.register();
        EntityRendererRegistry.register(NyraEntityTypes.NYRA, NyraEntityRenderer::new);
    }
}
