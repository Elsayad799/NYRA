package com.nyra.client.render;

import com.nyra.core.NyraMod;
import com.nyra.core.manifestation.NyraEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Minecraft 1.20.1: MobRenderer<T, M> (render *states* only exist from 1.21.2). */
public final class NyraEntityRenderer extends MobRenderer<NyraEntity, NyraEntityModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra.png");
    private static final ResourceLocation SHADOW = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_shadow.png");
    private static final ResourceLocation HORROR = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_horror.png");
    private static final ResourceLocation MASCULINE = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_masculine.png");
    private static final ResourceLocation BIG = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_big.png");

    public NyraEntityRenderer(EntityRendererProvider.Context context) {
        super(context, new NyraEntityModel(context.bakeLayer(NyraModelLayers.MAIN)), 0.28f);
    }

    @Override
    public ResourceLocation getTextureLocation(NyraEntity entity) {
        String form = entity.form() == null ? "FEMININE" : entity.form().toUpperCase(java.util.Locale.ROOT);
        return switch (form) {
            case "SHADOW" -> SHADOW;
            case "HORROR", "MONSTER", "TRUE_HORROR" -> HORROR;
            case "MASCULINE" -> MASCULINE;
            case "BIG" -> BIG;
            default -> TEXTURE;
        };
    }

    @Override
    protected void scale(NyraEntity entity, com.mojang.blaze3d.vertex.PoseStack poseStack, float partialTick) {
        String form = entity.form() == null ? "FEMININE" : entity.form().toUpperCase(java.util.Locale.ROOT);
        float scale = switch (form) {
            case "BIG" -> 2.45f;
            case "TRUE_HORROR" -> 1.32f;
            case "HORROR", "MONSTER" -> 1.12f;
            case "SHADOW" -> 1.04f;
            default -> 1.0f;
        };
        poseStack.scale(scale, scale, scale);
    }
}
