package com.nyra.client.render;

import com.nyra.core.NyraMod;
import com.nyra.core.manifestation.NyraEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Minecraft 1.20.1: MobRenderer<T, M> (render *states* only exist from 1.21.2). */
public final class NyraEntityRenderer extends MobRenderer<NyraEntity, NyraEntityModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra.png");
    private static final ResourceLocation SHADOW = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_shadow.png");
    private static final ResourceLocation HORROR = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_horror.png");
    private static final ResourceLocation MASCULINE = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_masculine.png");
    private static final ResourceLocation BIG = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_big.png");
    private static final ResourceLocation SMILE = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_smile.png");
    private static final ResourceLocation ANGRY = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_angry.png");
    private static final ResourceLocation SAD = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_sad.png");
    private static final ResourceLocation BLINK = new ResourceLocation(NyraMod.MOD_ID, "textures/entity/nyra_blink.png");

    public NyraEntityRenderer(EntityRendererProvider.Context context) {
        super(context, new NyraEntityModel(context.bakeLayer(NyraModelLayers.MAIN)), 0.28f);
    }

    @Override
    public ResourceLocation getTextureLocation(NyraEntity entity) {
        String form = entity.form() == null ? "FEMININE" : entity.form().toUpperCase(java.util.Locale.ROOT);
        // Horror forms retain their own silhouette/texture; facial expressions apply to humanoid forms.
        if (form.equals("SHADOW")) return SHADOW;
        if (form.equals("HORROR") || form.equals("MONSTER") || form.equals("TRUE_HORROR")) return HORROR;
        if (form.equals("BIG")) return BIG;
        if (form.equals("MASCULINE")) return MASCULINE;
        String expression = entity.expression();
        // The independent idle blink timer also works while another expression is active.
        if (entity.shouldAutoBlink() && !"ANGRY".equals(expression) && !"SAD".equals(expression)) return BLINK;
        if (!"NORMAL".equals(expression)) {
            return switch (expression) {
                case "SMILE" -> SMILE;
                case "ANGRY" -> ANGRY;
                case "SAD" -> SAD;
                case "BLINK" -> BLINK;
                default -> TEXTURE;
            };
        }
        return entity.shouldAutoBlink() ? BLINK : TEXTURE;
    }

    @Override
    protected void scale(NyraEntity entity, com.mojang.blaze3d.vertex.PoseStack poseStack, float partialTick) {
        String form = entity.form() == null ? "FEMININE" : entity.form().toUpperCase(java.util.Locale.ROOT);
        float scale = switch (form) {
            case "BIG" -> 2.45f;
            case "TRUE_HORROR" -> 1.32f;
            case "HORROR", "MONSTER" -> 1.12f;
            case "SHADOW" -> 1.04f;
            default -> 1.0f;
        };
        poseStack.scale(scale, scale, scale);
    }
}
