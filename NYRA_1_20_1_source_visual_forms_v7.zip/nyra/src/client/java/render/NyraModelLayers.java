package com.nyra.client.render;

import com.nyra.core.NyraMod;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.resources.ResourceLocation;

/** Properly proportioned 64x64 humanoid model. The face is intentionally blank. */
public final class NyraModelLayers {
    public static final ModelLayerLocation MAIN = new ModelLayerLocation(
            new ResourceLocation(NyraMod.MOD_ID, "manifestation"), "main");

    public static LayerDefinition create() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        // Standard humanoid proportions: head above torso, legs extending to the feet.
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4, -8, -4, 8, 8, 8), PartPose.ZERO);
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(16, 16)
                .addBox(-4, 0, -2, 8, 12, 4), PartPose.ZERO);
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(40, 16)
                .addBox(-3, -2, -2, 4, 12, 4), PartPose.offset(-5, 2, 0));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(32, 48)
                .addBox(-1, -2, -2, 4, 12, 4), PartPose.offset(5, 2, 0));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 16)
                .addBox(-2, 0, -2, 4, 12, 4), PartPose.offset(-1.9f, 12, 0));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(16, 48)
                .addBox(-2, 0, -2, 4, 12, 4), PartPose.offset(1.9f, 12, 0));
        // These pieces only appear for horror forms; the normal silhouette stays human.
        root.addOrReplaceChild("left_horn", CubeListBuilder.create().texOffs(48, 0)
                .addBox(-1, -4, -1, 2, 4, 2), PartPose.offset(-2.5f, -7, 0));
        root.addOrReplaceChild("right_horn", CubeListBuilder.create().texOffs(48, 0)
                .addBox(-1, -4, -1, 2, 4, 2), PartPose.offset(2.5f, -7, 0));
        root.addOrReplaceChild("left_tendril", CubeListBuilder.create().texOffs(52, 0)
                .addBox(-1, -1, -1, 2, 13, 2), PartPose.offset(5, 2, 0));
        root.addOrReplaceChild("right_tendril", CubeListBuilder.create().texOffs(52, 0)
                .addBox(-1, -1, -1, 2, 13, 2), PartPose.offset(-5, 2, 0));
        return LayerDefinition.create(mesh, 64, 64);
    }

    public static void register() {
        net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry.registerModelLayer(MAIN, NyraModelLayers::create);
    }

    private NyraModelLayers() {}
}
