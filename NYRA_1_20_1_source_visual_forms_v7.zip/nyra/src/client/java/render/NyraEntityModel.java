package com.nyra.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.nyra.core.manifestation.NyraEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;

/** Human-shaped Nyra model with a completely featureless face and subtle living motion. */
public final class NyraEntityModel extends EntityModel<NyraEntity> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart leftHorn;
    private final ModelPart rightHorn;
    private final ModelPart leftTendril;
    private final ModelPart rightTendril;

    public NyraEntityModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.leftHorn = root.getChild("left_horn");
        this.rightHorn = root.getChild("right_horn");
        this.leftTendril = root.getChild("left_tendril");
        this.rightTendril = root.getChild("right_tendril");
    }

    @Override
    public void setupAnim(NyraEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float walk = limbSwing * 0.6662f;
        float speed = Math.min(limbSwingAmount, 1.0f);
        leftLeg.xRot = (float) Math.cos(walk) * 1.15f * speed;
        rightLeg.xRot = (float) Math.cos(walk + Math.PI) * 1.15f * speed;
        leftArm.xRot = (float) Math.cos(walk + Math.PI) * 0.75f * speed;
        rightArm.xRot = (float) Math.cos(walk) * 0.75f * speed;
        head.xRot = headPitch * ((float) Math.PI / 180f);
        head.yRot = netHeadYaw * ((float) Math.PI / 180f);
        String form = entity.form() == null ? "FEMININE" : entity.form().toUpperCase(java.util.Locale.ROOT);
        boolean horror = form.equals("HORROR") || form.equals("MONSTER") || form.equals("TRUE_HORROR") || form.equals("BIG");
        boolean shadow = form.equals("SHADOW") || form.equals("TRUE_HORROR") || form.equals("BIG");
        leftHorn.visible = horror;
        rightHorn.visible = horror;
        leftTendril.visible = shadow;
        rightTendril.visible = shadow;
        // Calm forms subtly breathe and tilt their head instead of standing like a statue.
        float idle = (float) Math.sin(ageInTicks * 0.075f);
        body.y = idle * 0.12f;
        if (!horror && speed < 0.05f) {
            head.zRot = (float) Math.sin(ageInTicks * 0.025f) * 0.035f;
            leftArm.xRot = -0.035f + idle * 0.025f;
            rightArm.xRot = -0.035f - idle * 0.025f;
        } else {
            head.zRot = 0;
        }
        if (horror) {
            float pulse = (float) Math.sin(ageInTicks * (form.equals("TRUE_HORROR") ? 0.22f : 0.08f));
            leftArm.xRot = -0.12f + pulse * 0.08f;
            rightArm.xRot = -0.12f - pulse * 0.08f;
            if (shadow) {
                leftTendril.xRot = pulse * 0.18f;
                rightTendril.xRot = -pulse * 0.18f;
            }
        } else {
            leftTendril.xRot = 0;
            rightTendril.xRot = 0;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
