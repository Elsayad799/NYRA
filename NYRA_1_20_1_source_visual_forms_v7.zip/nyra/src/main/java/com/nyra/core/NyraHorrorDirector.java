package com.nyra.core;

import com.google.gson.JsonObject;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Small, non-destructive ambient horror director. It never changes blocks, damages
 * players, or creates an entity; it only schedules occasional sounds, particles,
 * and one-time story clues. Level 0 is a hard off switch.
 */
public final class NyraHorrorDirector {
    private static final Map<UUID, Long> NEXT_EVENT = new ConcurrentHashMap<>();
    private static final Set<UUID> CORE_CLUE_SEEN = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Watcher> WATCHERS = new ConcurrentHashMap<>();

    private NyraHorrorDirector() {}

    public static void tick(MinecraftServer server, int requestedLevel, JsonObject core) {
        if (server == null) return;
        int level = Math.max(0, Math.min(4, requestedLevel));
        if (level == 0) return;
        long now = System.currentTimeMillis();
        updateWatchers(server, now);
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!(player.level() instanceof ServerLevel world)) continue;
            if (player.isSpectator()) continue;

            // A discoverable clue near the hidden core coordinates; no exact coordinates are exposed.
            if (core != null && world.dimension().equals(Level.OVERWORLD) && CORE_CLUE_SEEN.add(player.getUUID())) {
                double x = core.has("x") ? core.get("x").getAsDouble() : 666.0;
                double y = core.has("y") ? core.get("y").getAsDouble() : 66.0;
                double z = core.has("z") ? core.get("z").getAsDouble() : 666.0;
                if (player.distanceToSqr(x, y, z) > 14.0 * 14.0) {
                    CORE_CLUE_SEEN.remove(player.getUUID());
                } else {
                    player.sendSystemMessage(Component.literal("§8The inscription shifts: \"ليس كل من يراقبك يريد إيذاءك.\""));
                }
            }

            long due = NEXT_EVENT.getOrDefault(player.getUUID(), now + initialDelay(player, level));
            if (now < due) {
                NEXT_EVENT.putIfAbsent(player.getUUID(), due);
                continue;
            }
            NEXT_EVENT.put(player.getUUID(), now + nextDelay(player, level));
            int event = player.getRandom().nextInt(level >= 3 ? 4 : 3);
            if (event == 0) {
                // Cave ambience: audible but quiet, with no gameplay effect.
                player.playNotifySound(SoundEvents.AMBIENT_CAVE.value(), SoundSource.AMBIENT,
                        0.28f + level * 0.06f, 0.72f + player.getRandom().nextFloat() * 0.45f);
            } else if (event == 1) {
                // A short trace appears behind the player's view and fades naturally.
                Vec3 look = player.getLookAngle();
                double px = player.getX() - look.x * (2.4 + level * 0.25);
                double py = player.getY() + 0.15;
                double pz = player.getZ() - look.z * (2.4 + level * 0.25);
                world.sendParticles(ParticleTypes.SMOKE, px, py, pz, 5 + level * 2, 0.16, 0.35, 0.16, 0.006);
                if (level >= 2) {
                    player.displayClientMessage(Component.literal("§8...كان هناك شيء خلفك."), true);
                }
            } else {
                if (level >= 3) spawnWatcher(world, player, now);
                if (level >= 2) {
                    if (player.getY() < 28.0 && player.getRandom().nextInt(3) == 0) {
                        String[] caveMessages = {
                                "§8[رسالة تالفة — ELSAYAD799] ﻻ ﺗﺜﻖ ﺑﺎﻟﺼﻤﺖ... 0x45 0x4C 0x53",
                                "§8[ELSAYAD799] ...هو لا يظهر أمامك. لا تمنحه هذه الفرصة.",
                                "§8[نص مشفّر] 4C 41 57 48 — ابحث عن الحجر الذي لا يحمل اسماً.",
                                "§8[رسالة غير مكتملة] أنا لا أعرف هل خرجتُ من العالم... أم أن العالم خرج مني."
                        };
                        player.displayClientMessage(Component.literal(caveMessages[player.getRandom().nextInt(caveMessages.length)]), true);
                    } else {
                        String[] whispers = {
                                "§8لا تلتفت بسرعة.",
                                "§8الصمت هنا ليس فارغًا.",
                                "§8هناك أثر لم يكن موجودًا قبل لحظة.",
                                "§8نايرا تشعر بالقلق، لكنها لا تعرف السبب."
                        };
                        player.displayClientMessage(Component.literal(whispers[player.getRandom().nextInt(whispers.length)]), true);
                    }
                }
            }
        }
    }

    public static void clearSession(MinecraftServer server) {
        if (server != null) {
            for (Watcher watcher : WATCHERS.values()) {
                for (ServerLevel level : server.getAllLevels()) {
                    var entity = level.getEntity(watcher.entityId);
                    if (entity != null) entity.discard();
                }
            }
        }
        WATCHERS.clear();
        NEXT_EVENT.clear();
        CORE_CLUE_SEEN.clear();
    }

    /** A brief, harmless faceless silhouette that appears behind a player and vanishes when noticed. */
    private static void spawnWatcher(ServerLevel world, ServerPlayer target, long now) {
        if (WATCHERS.containsKey(target.getUUID())) return;
        Vec3 look = target.getLookAngle();
        double x = target.getX() - look.x * 5.0;
        double z = target.getZ() - look.z * 5.0;
        ArmorStand watcher = new ArmorStand(world, x, target.getY(), z);
        watcher.setNoGravity(true);
        watcher.setNoBasePlate(true);
        watcher.setShowArms(false);
        watcher.setSilent(true);
        watcher.setInvulnerable(true);
        watcher.setCustomNameVisible(false);
        watcher.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
        watcher.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        watcher.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
        watcher.setYRot(target.getYRot() + 180.0f);
        if (world.addFreshEntity(watcher)) WATCHERS.put(target.getUUID(), new Watcher(watcher.getUUID(), now + 6500L));
    }

    private static void updateWatchers(MinecraftServer server, long now) {
        for (Map.Entry<UUID, Watcher> entry : WATCHERS.entrySet()) {
            UUID targetId = entry.getKey();
            Watcher data = entry.getValue();
            ServerPlayer target = server.getPlayerList().getPlayer(targetId);
            ArmorStand watcher = null;
            for (ServerLevel level : server.getAllLevels()) {
                var found = level.getEntity(data.entityId);
                if (found instanceof ArmorStand stand) { watcher = stand; break; }
            }
            boolean vanish = target == null || watcher == null || now >= data.expiresAt;
            if (!vanish && target.level() == watcher.level()) {
                // Any nearby player who actually looks at the silhouette makes it disappear.
                for (ServerPlayer observer : server.getPlayerList().getPlayers()) {
                    if (observer.level() != watcher.level() || observer.distanceToSqr(watcher) > 18.0 * 18.0) continue;
                    Vec3 toward = watcher.position().add(0, watcher.getBbHeight() * 0.65, 0).subtract(observer.getEyePosition()).normalize();
                    if (observer.getLookAngle().dot(toward) > 0.94 && observer.hasLineOfSight(watcher)) {
                        vanish = true;
                        break;
                    }
                }
            }
            if (vanish) {
                if (watcher != null) watcher.discard();
                WATCHERS.remove(targetId, data);
            }
        }
    }

    private record Watcher(UUID entityId, long expiresAt) {}

    private static long initialDelay(ServerPlayer player, int level) {
        return 20_000L + player.getRandom().nextInt(20_000) + (4 - level) * 12_000L;
    }

    private static long nextDelay(ServerPlayer player, int level) {
        long minimum = 25_000L + (4 - level) * 20_000L;
        long spread = 35_000L + (4 - level) * 15_000L;
        return minimum + player.getRandom().nextInt((int) spread);
    }
}
