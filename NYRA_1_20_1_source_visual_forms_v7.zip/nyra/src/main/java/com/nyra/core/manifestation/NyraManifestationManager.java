package com.nyra.core.manifestation;

import com.nyra.core.NyraMemory;
import com.nyra.core.Relationship;
import com.nyra.core.NyraGoalScheduler;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Keeps physical manifestations tied to one shared Core identity. */
public final class NyraManifestationManager {
    private final UUID coreId;
    private final Map<UUID, UUID> byPlayer = new ConcurrentHashMap<>();
    private final NyraNavigationController navigation = new NyraNavigationController();
    private long tickCounter;

    public NyraManifestationManager(UUID coreId) { this.coreId = coreId; }

    public UUID coreId() { return coreId; }
    public Map<UUID, UUID> snapshot() { return Map.copyOf(byPlayer); }

    /** Applies the shared Core goal to physical projections without creating an independent AI. */
    public void tick(MinecraftServer server, NyraGoalScheduler goals, double homeX, double homeY, double homeZ, double maxDistance) {
        if (server == null) return;
        tickCounter++;
        for (Map.Entry<UUID, UUID> entry : byPlayer.entrySet()) {
            UUID playerId = entry.getKey();
            ServerPlayer player = server.getPlayerList().getPlayer(playerId);
            NyraEntity entity = find(server, entry.getValue());
            if (player == null || entity == null || !entity.isAlive()) {
                if (entity != null) { navigation.stop(entity); entity.discard(); }
                byPlayer.remove(playerId, entry.getValue());
                if (entity != null) navigation.forget(entity.getUUID());
                continue;
            }
            // A player changing dimensions should carry the same shared identity with them.
            if (entity.level() != player.level()) {
                String previousForm = entity.form();
                navigation.stop(entity);
                navigation.forget(entity.getUUID());
                entity.discard();
                byPlayer.remove(playerId, entry.getValue());
                spawnFor(server, player, null, previousForm);
                continue;
            }
            NyraGoalScheduler.Goal goal = goals.get(playerId);
            double distance = entity.distanceTo(player);
            switch (goal) {
                case FOLLOW -> {
                    if (distance > 3.0 && entity.level() == player.level())
                        navigation.follow(entity, player, 1.05, tickCounter);
                }
                case RETURN_HOME -> {
                    if (entity.level() instanceof ServerLevel level && entity.distanceToSqr(homeX, homeY, homeZ) > 9.0)
                        navigation.goTo(entity, new net.minecraft.world.phys.Vec3(homeX, homeY, homeZ), 1.0, tickCounter);
                }
                case HIDE -> {
                    if (distance < 12.0 && entity.level() == player.level()) {
                        double dx = entity.getX() - player.getX();
                        double dz = entity.getZ() - player.getZ();
                        double len = Math.max(0.001, Math.sqrt(dx * dx + dz * dz));
                        double tx = player.getX() + (dx / len) * 14.0;
                        double tz = player.getZ() + (dz / len) * 14.0;
                        navigation.goTo(entity, new net.minecraft.world.phys.Vec3(tx, entity.getY(), tz), 1.15, tickCounter);
                    }
                }
                case OBSERVE -> {
                    // Stay aware of the player, catch up naturally when left behind,
                    // and occasionally take a few steps instead of freezing forever.
                    if (distance > 5.0) {
                        navigation.follow(entity, player, 0.82, tickCounter);
                    } else if (entity.getNavigation().isDone() && entity.getRandom().nextInt(55) == 0) {
                        wanderNear(entity, 3.5, 0.55, tickCounter);
                    }
                }
                case ROAM -> {
                    if (distance > 18.0) navigation.follow(entity, player, 0.72, tickCounter);
                    else if (entity.getNavigation().isDone() && entity.getRandom().nextInt(35) == 0)
                        wanderNear(entity, Math.min(12.0, Math.max(5.0, maxDistance)), 0.68, tickCounter);
                }
                case INVESTIGATE -> {
                    if (distance > 7.0) navigation.follow(entity, player, 0.92, tickCounter);
                    else if (entity.getNavigation().isDone() && entity.getRandom().nextInt(28) == 0)
                        wanderNear(entity, 6.0, 0.78, tickCounter);
                }
                case BUILD, WAIT -> navigation.stop(entity);
            }
            entity.getLookControl().setLookAt(player, 25.0f, 25.0f);
        }
    }

    private void wanderNear(NyraEntity entity, double radius, double speed, long tick) {
        double tx = entity.getX() + (entity.getRandom().nextDouble() - 0.5) * radius * 2.0;
        double tz = entity.getZ() + (entity.getRandom().nextDouble() - 0.5) * radius * 2.0;
        navigation.goTo(entity, new net.minecraft.world.phys.Vec3(tx, entity.getY(), tz), speed, tick);
    }

    /** Stops all movement immediately (used by /nyra autonomy off). Entities stay in the world, idle. */
    public void stopAll(MinecraftServer server) {
        if (server == null) return;
        for (UUID entityId : byPlayer.values()) {
            NyraEntity e = find(server, entityId);
            if (e != null) navigation.stop(e);
        }
    }

    private NyraEntity find(MinecraftServer server, UUID entityId) {
        for (ServerLevel level : server.getAllLevels()) {
            var e = level.getEntity(entityId);
            if (e instanceof NyraEntity n) return n;
        }
        return null;
    }

    /**
     * Called for every NyraEntity that enters a world (fresh spawn or loaded from disk).
     * Guarantees at most one manifestation per player: stale copies left over from a previous
     * session, re-connects or chunk reloads are removed instead of piling up.
     */
    public void onEntityLoad(MinecraftServer server, NyraEntity entity) {
        UUID target;
        try {
            target = UUID.fromString(entity.targetId());
        } catch (IllegalArgumentException e) {
            server.execute(entity::discard);   // legacy/orphan copy without an owner
            return;
        }
        UUID known = byPlayer.get(target);
        if (known != null && !known.equals(entity.getUUID())) {
            server.execute(entity::discard);   // another living manifestation already owns this player
            return;
        }
        byPlayer.put(target, entity.getUUID());
    }

    public NyraEntity spawnFor(MinecraftServer server, ServerPlayer player, NyraMemory memory, String form) {
        if (player == null) return null;
        ServerLevel level = player.serverLevel();
        UUID existingId = byPlayer.get(player.getUUID());
        if (existingId != null) {
            var existing = level.getEntity(existingId);
            if (existing instanceof NyraEntity n && n.isAlive()) return n;
            byPlayer.remove(player.getUUID());
        }

        NyraEntity entity = NyraEntityTypes.NYRA.create(level);
        if (entity == null) return null;
        // Spawn beside the player only on a real solid floor with two clear blocks above.
        double sideX = player.getX() - player.getLookAngle().z * 1.6;
        double sideZ = player.getZ() + player.getLookAngle().x * 1.6;
        BlockPos safe = findSafeGround(level, sideX, player.getY(), sideZ);
        if (safe == null) safe = findSafeGround(level, player.getX(), player.getY(), player.getZ());
        if (safe == null) safe = player.blockPosition();
        entity.moveTo(safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5, player.getYRot() + 180.0f, 0.0f);
        entity.setCoreId(coreId.toString());
        entity.setTargetId(player.getUUID().toString());
        entity.setForm(normalizeForm(form));
        level.addFreshEntity(entity);
        byPlayer.put(player.getUUID(), entity.getUUID());
        return entity;
    }


    private static BlockPos findSafeGround(ServerLevel level, double x, double y, double z) {
        BlockPos base = BlockPos.containing(x, y, z);
        for (int radius = 0; radius <= 4; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (radius > 0 && Math.abs(dx) != radius && Math.abs(dz) != radius) continue;
                    for (int dy = 2; dy >= -4; dy--) {
                        BlockPos feet = base.offset(dx, dy, dz);
                        BlockPos floor = feet.below();
                        if (!level.hasChunkAt(feet) || !level.hasChunkAt(floor)) continue;
                        var floorState = level.getBlockState(floor);
                        if (!floorState.blocksMotion() || !floorState.getFluidState().isEmpty()) continue;
                        var feetState = level.getBlockState(feet);
                        var headState = level.getBlockState(feet.above());
                        if (!feetState.getFluidState().isEmpty() || !headState.getFluidState().isEmpty()) continue;
                        VoxelShape feetShape = feetState.getCollisionShape(level, feet);
                        VoxelShape headShape = headState.getCollisionShape(level, feet.above());
                        if (feetShape.isEmpty() && headShape.isEmpty()) return feet;
                    }
                }
            }
        }
        return null;
    }

    /** Change the visible form of a player's manifestation without creating a new identity. */
    public void setFormForPlayer(MinecraftServer server, UUID playerId, String form) {
        UUID entityId = byPlayer.get(playerId);
        if (entityId == null || server == null) return;
        NyraEntity entity = find(server, entityId);
        if (entity != null && entity.isAlive()) entity.setForm(normalizeForm(form));
    }

    private static String normalizeForm(String value) {
        String form = value == null ? "FEMININE" : value.trim().toUpperCase(java.util.Locale.ROOT);
        return java.util.List.of("FEMININE", "MASCULINE", "NEUTRAL", "SHADOW", "HORROR", "MONSTER", "TRUE_HORROR", "BIG").contains(form)
                ? form : "FEMININE";
    }

    public void removeFor(MinecraftServer server, UUID playerId) {
        UUID entityId = byPlayer.remove(playerId);
        if (entityId == null) return;
        for (ServerLevel level : server.getAllLevels()) {
            var e = level.getEntity(entityId);
            if (e != null) { navigation.stop((NyraEntity) e); e.discard(); return; }
        }
    }

    public void removeAll(MinecraftServer server) {
        for (UUID playerId : byPlayer.keySet().toArray(UUID[]::new)) removeFor(server, playerId);
        byPlayer.clear();
    }
}
