package com.nyra.core.manifestation;

import com.nyra.core.NyraMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

/**
 * Registration of the Nyra manifestation entity (Minecraft 1.20.1).
 *
 * IMPORTANT: this class must be loaded from ModInitializer#onInitialize, never later.
 * Registries are frozen once the server/world starts, so registering in SERVER_STARTING crashes.
 */
public final class NyraEntityTypes {
    public static final EntityType<NyraEntity> NYRA = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            new ResourceLocation(NyraMod.MOD_ID, "manifestation"),
            EntityType.Builder.of(NyraEntity::new, MobCategory.CREATURE)
                    .sized(0.72f, 1.82f)
                    .clientTrackingRange(8)   // chunks, not blocks, in 1.20.x
                    .updateInterval(2)
                    .build(NyraMod.MOD_ID + ":manifestation"));

    private static boolean initialized;

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        FabricDefaultAttributeRegistry.register(NYRA, NyraEntity.createAttributes());
    }

    private NyraEntityTypes() {}
}
