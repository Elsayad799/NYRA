package com.nyra.core.manifestation;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;

/**
 * A physical projection of the single Nyra Core. It deliberately stores no
 * independent memory or personality; the server-side Core owns those.
 *
 * Minecraft 1.20.1 API: synched data is declared with entityData.define(...)
 * (the Builder-based variant only exists from 1.20.5).
 */
public final class NyraEntity extends PathfinderMob {
    private static final EntityDataAccessor<String> FORM =
            SynchedEntityData.defineId(NyraEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> CORE_ID =
            SynchedEntityData.defineId(NyraEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> TARGET_ID =
            SynchedEntityData.defineId(NyraEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> EXPRESSION =
            SynchedEntityData.defineId(NyraEntity.class, EntityDataSerializers.STRING);

    public NyraEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setInvulnerable(true);
        this.setCustomName(Component.literal("نايرا"));
        this.setCustomNameVisible(true);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(FORM, "NEUTRAL");
        this.entityData.define(CORE_ID, "");
        this.entityData.define(TARGET_ID, "");
        this.entityData.define(EXPRESSION, "NORMAL");
    }

    /** Saved so a reloaded world can recognise (and de-duplicate) the entity instead of spawning another. */
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("NyraForm", form());
        tag.putString("NyraCoreId", coreId());
        tag.putString("NyraTargetId", targetId());
        tag.putString("NyraExpression", expression());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setForm(tag.getString("NyraForm"));
        setCoreId(tag.getString("NyraCoreId"));
        setTargetId(tag.getString("NyraTargetId"));
        setExpression(tag.getString("NyraExpression"));
    }

    public String form() { return entityData.get(FORM); }
    public void setForm(String value) { entityData.set(FORM, value == null || value.isEmpty() ? "NEUTRAL" : value); }
    public String coreId() { return entityData.get(CORE_ID); }
    public void setCoreId(String value) { entityData.set(CORE_ID, value == null ? "" : value); }
    public String expression() { return entityData.get(EXPRESSION); }
    public void setExpression(String value) {
        String v = value == null ? "NORMAL" : value.toUpperCase(java.util.Locale.ROOT);
        if (!java.util.Set.of("NORMAL", "SMILE", "ANGRY", "SAD", "BLINK").contains(v)) v = "NORMAL";
        entityData.set(EXPRESSION, v);
    }
    public boolean shouldAutoBlink() {
        // Client and server calculate the same short blink window from entity identity and age.
        int interval = 80 + Math.floorMod(getUUID().hashCode(), 61); // 4-7 seconds at 20 TPS
        int phase = Math.floorMod(tickCount + Math.floorMod(getUUID().hashCode() >>> 3, interval), interval);
        return phase < 4; // about 0.2 seconds
    }
    public String targetId() { return entityData.get(TARGET_ID); }
    public void setTargetId(String value) { entityData.set(TARGET_ID, value == null ? "" : value); }

    @Override
    protected void registerGoals() {
        // The shared Nyra Core remains responsible for identity, memory and high-level
        // decisions. These small vanilla goals only provide safe physical idle behavior
        // between Core decisions, so the manifestation does not look frozen.
        // They do not attack, break blocks, or override the Core's conversation planner.
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.72D));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }
}
