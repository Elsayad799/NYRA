package com.nyra.core;

import com.google.gson.*;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * Non-blocking client for the external Nyra Core.
 *
 * Rules (so the game never freezes and requests never pile up on a phone):
 * - every call runs on a small bounded worker pool, never on the server thread;
 * - results are handed back on the server thread via {@link #setMainThread(Consumer)};
 * - one request per key may be in flight (duplicate/identical triggers are dropped);
 * - a circuit breaker stops calling a dead Core for a while (15 s doubling to 2 min);
 * - connect failures get one short retry, timeouts are never retried;
 * - callers get {@code false} when the request was not sent and must then keep their local behaviour.
 */
public final class AiRouter {
    private static final int MAX_QUEUE = 4;
    private static final long BASE_COOLDOWN_MS = 15_000L;
    private static final long MAX_COOLDOWN_MS = 120_000L;
    private static final int FAILS_BEFORE_OPEN = 3;

    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
    private final String base;
    private final Duration requestTimeout;
    private final ThreadPoolExecutor pool;
    private final Set<String> inFlight = ConcurrentHashMap.newKeySet();
    private final AtomicInteger consecutiveFailures = new AtomicInteger();
    private volatile long openUntil = 0L;
    private volatile long cooldownMs = BASE_COOLDOWN_MS;
    private volatile Consumer<Runnable> mainThread = Runnable::run;

    public AiRouter(String base) { this(base, 22); }

    public AiRouter(String base, int timeoutSeconds) {
        this.base = base == null ? "http://127.0.0.1:8787" : base.replaceAll("/$", "");
        this.requestTimeout = Duration.ofSeconds(Math.max(3, timeoutSeconds));
        AtomicInteger n = new AtomicInteger();
        this.pool = new ThreadPoolExecutor(1, 2, 30, TimeUnit.SECONDS, new ArrayBlockingQueue<>(MAX_QUEUE),
                r -> { Thread t = new Thread(r, "nyra-core-" + n.incrementAndGet()); t.setDaemon(true); return t; },
                new ThreadPoolExecutor.AbortPolicy());
    }

    /** Callbacks are delivered through this executor (use {@code server::execute}). */
    public void setMainThread(Consumer<Runnable> executor) { this.mainThread = executor == null ? Runnable::run : executor; }

    public boolean isAvailable() { return System.currentTimeMillis() >= openUntil; }

    public void shutdown() { pool.shutdownNow(); }

    /** @return false if the request was NOT sent (breaker open, same key in flight, or queue full). */
    public boolean planAsync(String key, String prompt, Consumer<JsonObject> callback) {
        return submit(key, "/plan", prompt, callback);
    }

    public boolean reflectAsync(String key, String prompt, Consumer<JsonObject> callback) {
        return submit(key, "/reflect", prompt, callback);
    }

    private boolean submit(String key, String path, String prompt, Consumer<JsonObject> callback) {
        if (!isAvailable()) return false;
        if (!inFlight.add(key)) return false;
        try {
            pool.execute(() -> {
                JsonObject result = null;
                try {
                    result = post(path, prompt);
                } finally {
                    inFlight.remove(key);
                }
                final JsonObject out = result == null ? new JsonObject() : result;
                mainThread.accept(() -> {
                    try { callback.accept(out); }
                    catch (RuntimeException e) { System.err.println("[Nyra][core] callback failed for " + path + ": " + e); }
                });
            });
            return true;
        } catch (RejectedExecutionException e) {
            inFlight.remove(key);
            System.err.println("[Nyra][core] request dropped (queue full): " + path);
            return false;
        }
    }

    /** Diagnostic used by /nyra core test: health + provider connectivity, entirely off the server thread. */
    public CompletableFuture<String> healthAsync() {
        CompletableFuture<String> f = new CompletableFuture<>();
        try {
            pool.execute(() -> {
                try {
                    JsonObject h = get("/health", Duration.ofSeconds(4));
                    if (h == null) { f.complete("Core unreachable at " + base + " (is nyra_core/server.py running?)"); return; }
                    StringBuilder sb = new StringBuilder("Core OK | providers configured=")
                            .append(h.has("providers") ? h.get("providers").getAsInt() : -1);
                    JsonObject t = get("/providers/test", Duration.ofSeconds(40));
                    if (t != null && t.has("results")) {
                        for (JsonElement e : t.getAsJsonArray("results")) {
                            JsonObject r = e.getAsJsonObject();
                            sb.append(" | ").append(r.get("name").getAsString()).append(": ");
                            if (!r.get("configured").getAsBoolean()) sb.append("not configured");
                            else if (r.get("ok").getAsBoolean()) sb.append("ok ").append(r.get("ms").getAsInt()).append("ms");
                            else sb.append("FAILED (").append(r.get("error").getAsString()).append(")");
                        }
                    }
                    f.complete(sb.toString());
                } catch (RuntimeException e) {
                    f.complete("Core test error: " + e.getClass().getSimpleName());
                }
            });
        } catch (RejectedExecutionException e) {
            f.complete("Core busy, try again in a moment.");
        }
        return f;
    }

    // ---- blocking helpers (worker threads only) ------------------------------------------------

    private JsonObject post(String path, String prompt) {
        JsonObject req = new JsonObject();
        req.addProperty("prompt", prompt == null ? "" : prompt);
        long t0 = System.currentTimeMillis();
        for (int attempt = 0; attempt < 2; attempt++) {
            try {
                HttpRequest r = HttpRequest.newBuilder(URI.create(base + path))
                        .timeout(requestTimeout)
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(req.toString()))
                        .build();
                HttpResponse<String> res = http.send(r, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() / 100 == 2) {
                    JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
                    onSuccess();
                    return o;
                }
                System.err.println("[Nyra][core] " + path + " HTTP " + res.statusCode());
                onFailure();
                return null;
            } catch (HttpTimeoutException e) {
                System.err.println("[Nyra][core] " + path + " timed out after " + (System.currentTimeMillis() - t0) + " ms");
                onFailure();
                return null;                                   // never retry a timeout
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return null;
            } catch (IOException e) {
                if (attempt == 0) { sleepQuietly(300); continue; }  // one short retry for connect errors
                System.err.println("[Nyra][core] " + path + " unreachable: " + e.getClass().getSimpleName());
                onFailure();
                return null;
            } catch (RuntimeException e) {                     // malformed JSON etc.
                System.err.println("[Nyra][core] " + path + " bad response: " + e.getClass().getSimpleName());
                onFailure();
                return null;
            }
        }
        return null;
    }

    private JsonObject get(String path, Duration timeout) {
        try {
            HttpRequest r = HttpRequest.newBuilder(URI.create(base + path)).timeout(timeout).GET().build();
            HttpResponse<String> res = http.send(r, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() / 100 == 2) return JsonParser.parseString(res.body()).getAsJsonObject();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (IOException | RuntimeException ignored) { }
        return null;
    }

    private void onSuccess() {
        consecutiveFailures.set(0);
        cooldownMs = BASE_COOLDOWN_MS;
        openUntil = 0L;
    }

    private void onFailure() {
        if (consecutiveFailures.incrementAndGet() >= FAILS_BEFORE_OPEN) {
            openUntil = System.currentTimeMillis() + cooldownMs;
            System.err.println("[Nyra][core] Core link paused for " + (cooldownMs / 1000) + " s; local behaviour continues.");
            cooldownMs = Math.min(MAX_COOLDOWN_MS, cooldownMs * 2);
            consecutiveFailures.set(0);
        }
    }

    private static void sleepQuietly(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
