package com.nyra.core.runtime;

import com.nyra.core.manifestation.NyraEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * First operational layer of Nyra's in-world recruitment system.
 * Recruitment is stored as entity scoreboard tags, which Minecraft saves with the entity.
 * Recruited mobs follow a nearby Nyra manifestation and can be released without deleting them.
 */
public final class NyraMobRecruitment {
    public static final String RECRUITED_TAG = "nyra_recruited";
    private static final String CORE_TAG = "nyra_core_";
    private static final String CORE_ID = "shared";
    private static final String ORDER_PREFIX = "nyra_order_";
    private static long tick;

    private NyraMobRecruitment() {}

    public static int recruitNearby(ServerLevel level, double x, double y, double z, double radius) {
        if (level == null) return 0;
        double r = Math.max(2.0, Math.min(64.0, radius));
        AABB area = new AABB(x-r, y-r, z-r, x+r, y+r, z+r);
        int recruited = 0;
        for (Entity entity : level.getEntities((Entity) null, area, e -> e instanceof Mob && !(e instanceof NyraEntity))) {
            if (!(entity instanceof Mob mob) || mob.isDeadOrDying()) continue;
            if (mob.getTags().contains(RECRUITED_TAG)) continue;
            mob.addTag(RECRUITED_TAG);
            mob.addTag(CORE_TAG + CORE_ID);
            mob.addTag(ORDER_PREFIX + "FOLLOW");
            mob.setPersistenceRequired();
            recruited++;
        }
        return recruited;
    }

    public static int count(MinecraftServer server) {
        int count = 0;
        if (server == null) return 0;
        for (ServerLevel level : server.getAllLevels())
            for (Entity e : level.getAllEntities())
                if (e instanceof Mob && e.getTags().contains(RECRUITED_TAG)) count++;
        return count;
    }

    /** Set a shared, persistent order selected by Nyra's AI Core. */
    public static int commandAll(MinecraftServer server, String requestedOrder) {
        if (server == null) return 0;
        String order = requestedOrder == null ? "FOLLOW" : requestedOrder.trim().toUpperCase(java.util.Locale.ROOT);
        if (!List.of("FOLLOW", "GUARD", "DEFEND", "WAIT").contains(order)) return 0;
        int changed = 0;
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity entity : level.getAllEntities()) {
                if (!(entity instanceof Mob mob) || !mob.getTags().contains(RECRUITED_TAG)) continue;
                mob.getTags().removeIf(tag -> tag.startsWith(ORDER_PREFIX));
                mob.addTag(ORDER_PREFIX + order);
                if ("WAIT".equals(order)) mob.getNavigation().stop();
                changed++;
            }
        }
        return changed;
    }

    private static String orderOf(Mob mob) {
        for (String tag : mob.getTags())
            if (tag.startsWith(ORDER_PREFIX)) return tag.substring(ORDER_PREFIX.length());
        return "FOLLOW";
    }

    public static int releaseAll(MinecraftServer server) {
        int released = 0;
        if (server == null) return released;
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                if (e instanceof Mob mob && mob.getTags().remove(RECRUITED_TAG)) {
                    mob.getTags().remove(CORE_TAG + CORE_ID);
                    mob.setTarget(null);
                    mob.getNavigation().stop();
                    released++;
                }
            }
        }
        return released;
    }

    public static void tick(MinecraftServer server) {
        if (server == null || ++tick % 20 != 0) return;
        for (ServerLevel level : server.getAllLevels()) {
            List<NyraEntity> manifestations = new ArrayList<>();
            for (Entity entity : level.getAllEntities())
                if (entity instanceof NyraEntity nyra && nyra.isAlive()) manifestations.add(nyra);
            if (manifestations.isEmpty()) continue;
            for (Entity entity : level.getAllEntities()) {
                if (!(entity instanceof Mob mob) || !mob.getTags().contains(RECRUITED_TAG) || mob.isDeadOrDying()) continue;
                NyraEntity nearest = null;
                double best = Double.MAX_VALUE;
                for (NyraEntity nyra : manifestations) {
                    double d = mob.distanceToSqr(nyra);
                    if (d < best) { best = d; nearest = nyra; }
                }
                if (nearest == null) continue;

                // Nyra's AI selects the order; this class only carries it out.
                // Recruited mobs are never deliberately ordered to attack players.
                if (mob.getTarget() instanceof ServerPlayer) mob.setTarget(null);
                String order = orderOf(mob);
                final NyraEntity leader = nearest;
                if ("WAIT".equals(order)) { mob.getNavigation().stop(); continue; }
                boolean defensive = "DEFEND".equals(order) || "GUARD".equals(order);
                if (defensive && !(mob instanceof Monster)) {
                    Monster threat = leader.level().getEntitiesOfClass(Monster.class,
                            leader.getBoundingBox().inflate("GUARD".equals(order) ? 8.0 : 12.0),
                            m -> m.isAlive() && !m.getTags().contains(RECRUITED_TAG))
                            .stream().min((a,b) -> Double.compare(a.distanceToSqr(leader), b.distanceToSqr(leader))).orElse(null);
                    if (threat != null && mob.distanceToSqr(threat) < 14.0 * 14.0) mob.setTarget(threat);
                }
                if ("GUARD".equals(order)) {
                    if (best > 5.0 * 5.0 && best < 48.0 * 48.0 && mob.getNavigation().isDone()) mob.getNavigation().moveTo(leader, 1.0);
                    else if (best <= 5.0 * 5.0) mob.getNavigation().stop();
                } else if (best > 7.0 * 7.0 && best < 48.0 * 48.0 && mob.getNavigation().isDone()) {
                    mob.getNavigation().moveTo(leader, 1.05);
                } else if (best <= 5.0 * 5.0 && mob.getNavigation().isInProgress()) {
                    mob.getNavigation().stop();
                }
            }
        }
    }
}
