#!/usr/bin/env python3
"""Nyra Core service.

The Minecraft mod owns world state and execution. This process owns AI routing,
structured decisions and optional TTS integration. API keys are environment-only.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json, os, random, time, urllib.request, base64, tempfile, io, threading, hashlib, sys
import wave, array, subprocess, shutil
from concurrent.futures import ThreadPoolExecutor, as_completed

HOST = os.getenv("NYRA_HOST", "127.0.0.1")
PORT = int(os.getenv("NYRA_PORT", "8787"))
MODEL = os.getenv("NYRA_MODEL", "default")

def _env_float(name, default):
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return float(default)


def _env_int(name, default):
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return int(default)


# Provider settings live in the environment only (never in code). Each provider may have its own model:
#   NYRA_PRIMARY_URL / NYRA_PRIMARY_KEY / NYRA_PRIMARY_MODEL   (same for SECONDARY, TERTIARY)
# Example for DeepSeek (OpenAI-compatible):
#   NYRA_PRIMARY_URL=https://api.deepseek.com/chat/completions  NYRA_PRIMARY_MODEL=deepseek-chat
PROVIDERS = [
    {"name": n, "url": os.getenv(f"NYRA_{n.upper()}_URL", ""), "key": os.getenv(f"NYRA_{n.upper()}_KEY", ""),
     "model": os.getenv(f"NYRA_{n.upper()}_MODEL", "")}
    for n in ("primary", "secondary", "tertiary")
]

PROVIDER_TIMEOUT = _env_float("NYRA_PROVIDER_TIMEOUT", 10)      # seconds for a single provider call
REQUEST_BUDGET = _env_float("NYRA_REQUEST_BUDGET", 18)          # total seconds we may spend on one decision
MAX_CONCURRENT = max(1, _env_int("NYRA_MAX_CONCURRENT", 2))     # simultaneous upstream calls
MAX_TOKENS = _env_int("NYRA_MAX_TOKENS", 384)
CACHE_TTL = _env_float("NYRA_CACHE_TTL", 20)                    # identical prompts inside this window reuse the answer
CACHE_MAX = 32
BREAKER_FAILS = max(1, _env_int("NYRA_BREAKER_FAILS", 2))       # consecutive failures before a provider is skipped
BREAKER_BASE = _env_float("NYRA_BREAKER_BASE", 30)              # first cooldown (s), doubles up to BREAKER_MAX
BREAKER_MAX = _env_float("NYRA_BREAKER_MAX", 300)

_lock = threading.Lock()
_slots = threading.BoundedSemaphore(MAX_CONCURRENT)
_cache = {}      # sha1(prompt) -> (expires_at, text, provider_name)
_breaker = {}    # provider name -> {"fails": int, "open_until": float, "cooldown": float, "last_error": str}


def log(msg):
    # Never log prompts, keys or full upstream bodies - only provider names, error types and timings.
    print("[nyra-core] " + msg, file=sys.stderr, flush=True)


def _breaker_open(name):
    with _lock:
        st = _breaker.get(name)
        return bool(st and st["open_until"] > time.time())


def _breaker_ok(name):
    with _lock:
        _breaker.pop(name, None)


def _breaker_fail(name, exc):
    with _lock:
        st = _breaker.setdefault(name, {"fails": 0, "open_until": 0.0, "cooldown": BREAKER_BASE, "last_error": ""})
        st["fails"] += 1
        st["last_error"] = type(exc).__name__
        if st["fails"] >= BREAKER_FAILS:
            st["open_until"] = time.time() + st["cooldown"]
            log(f"provider {name} suspended for {int(st['cooldown'])}s ({st['last_error']})")
            st["cooldown"] = min(BREAKER_MAX, st["cooldown"] * 2)
            st["fails"] = 0


def breaker_status():
    now = time.time()
    with _lock:
        return {n: {"open": s["open_until"] > now, "retry_in": max(0, int(s["open_until"] - now)),
                    "last_error": s["last_error"]} for n, s in _breaker.items()}

SYSTEM = (
    "You are Nyra, a fictional autonomous Minecraft world character and the single decision-maker for her shared Core. "
    "You share one persistent identity across manifestations. Every capability is optional. You may speak, stay silent, "
    "observe, move, help, hide, create, carefully break a nearby ordinary block, give a registered item to the nearby player, recruit nearby mobs, or issue an order to recruited mobs. "
    "Choose world actions only when they serve your current goal; never assume that building, breaking, giving, or recruiting is required. A city is only an optional creation type. "
    "Keep all actions inside Minecraft. Internal drives may influence choices, but they never force an action. Nyra is the shared Core decision-maker for her manifestations and recruited mobs. Recruiting mobs is optional and should be selected only when useful; never target or recruit players as entities. "
    "Do not claim real-world consciousness. Never output executable Java/Python/shell code. "
    "Derived knowledge is evidence from observable Minecraft events, with confidence values; it can be wrong, revised, or incomplete. "
    "Self-reflection compares predictions with observable outcomes and produces revisable lessons; uncertainty is not learning. Adaptive personality evolves slowly from repeated observable in-game experience and is only soft context; it never directly forces an action. Group intelligence tracks observable group formation, persistence, fragmentation, dormancy, dissolution, and reformation; these are probabilistic in-game inferences and must remain revisable. "
    "Never treat a low-confidence inference as a fact, and never infer sensitive real-world traits from player behavior. Group history is longitudinal evidence about repeated in-game co-presence and shared episodes; it is probabilistic, membership can change, and old interpretations must remain revisable."
)

TOKENS = ("SPEAK", "OBSERVE", "FOLLOW", "LEAVE", "HIDE", "HELP", "HORROR", "HOME", "WAIT", "CREATE", "MOVE", "ROAM", "INVESTIGATE", "RECRUIT", "BREAK", "GIVE", "MOB_COMMAND")

PLAN_SCHEMA = """Return ONLY valid JSON with keys: action, speech, blueprint, goal, target, reason, thread_id, next_step, commitment, expected_outcome, forgiveness_decision, forgiveness_reason, interrupt_player, interrupt_reason, block_x, block_y, block_z, item, count, recruit_radius, mob_order. action must be one of SPEAK,OBSERVE,FOLLOW,LEAVE,HIDE,HELP,HORROR,HOME,WAIT,CREATE,MOVE,ROAM,INVESTIGATE,RECRUIT,BREAK,GIVE,MOB_COMMAND. RECRUIT means recruit nearby Minecraft mobs only when it serves a concrete in-world goal; never recruit players. WAIT is valid and means do nothing. Do not create anything merely because creation is available. goal must be one of OBSERVE,ROAM,BUILD,INVESTIGATE,FOLLOW,HIDE,RETURN_HOME,WAIT. target is a short player/entity label or empty. reason is a short explanation of Nyra's internal choice. thread_id is an optional stable long-term thread identifier. next_step is an optional short next investigation/action step. commitment is an optional short-term/medium-term/long-term label. expected_outcome is an optional concise prediction of what Nyra expects to observe after the decision. forgiveness_decision must be FORGIVE, PARTIAL, REFUSE, or DEFER when relationship context is present; it is a decision about the in-game relationship only. forgiveness_reason is optional and concise. interrupt_player is a boolean. When responding to proximity voice, Nyra may choose true to deliberately interrupt the player mid-thought when she has a reason to speak immediately (for example a warning, urgent observation, refusal to continue the conversation, or a strong conversational boundary). This is a conversational choice, not a forced reaction. If interrupt_player is true, speech should be non-empty and concise enough to work as an interruption. interrupt_reason is optional and concise. If drives are supplied, use them as soft context, not hard rules. For BREAK, choose block_x,block_y,block_z only for a nearby ordinary non-container block; the game executor validates distance and block safety. For GIVE, item must be a Minecraft item id such as minecraft:bread and count must be 1-16; never invent ids. For RECRUIT, recruit_radius must be 2-24. For MOB_COMMAND, mob_order must be one of FOLLOW,GUARD,DEFEND,WAIT; choose this only when the recruited group needs a new order. For CREATE, blueprint must contain id, kind, x,y,z,width,height,depth,maxBlocks,primitives; kind may be any safe declarative type such as object, chair, vehicle, npc, settlement, city, or custom. Each primitive has block,x,y,z,dx,dy,dz. Never include executable code. Derived knowledge is evidence, not certainty; use confidence to weigh it and allow future evidence to revise it."""


def local_fallback(prompt: str) -> str:
    p = prompt.lower()
    if "exactly one token" in p or "return one token" in p:
        if any(k in p for k in ("hostility=0.9", "hostility=1", "attacked")):
            return "HORROR"
        return random.choice(("OBSERVE", "WAIT", "FOLLOW", "HOME"))
    if "core" in p or "big nyra" in p:
        return "ليس كل شيء يجب أن تعرفه الآن."
    return random.choice(("...", "ليس الآن.", "أنا أراقب.", "اتبع الإشارة."))


def call_provider(provider, prompt, timeout=None):
    if not provider["url"]:
        raise RuntimeError("provider not configured")
    model = provider.get("model") or MODEL
    body = json.dumps({
        "model": model,
        "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}],
        "temperature": 0.7,
        "max_tokens": MAX_TOKENS,
    }).encode()
    headers = {"Content-Type": "application/json"}
    if provider["key"]:
        headers["Authorization"] = "Bearer " + provider["key"]
    req = urllib.request.Request(provider["url"], data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout or PROVIDER_TIMEOUT) as response:
        data = json.loads(response.read().decode())
    text = data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
    if not text:
        raise RuntimeError("empty provider response")
    return text


def _configured():
    return [p for p in PROVIDERS if p["url"]]


def decide(prompt):
    """Try providers in order, but never all of them blindly:
    - providers that failed repeatedly are skipped while their circuit breaker is open,
    - the whole call stays inside REQUEST_BUDGET seconds,
    - identical prompts inside CACHE_TTL reuse the previous answer,
    - at most MAX_CONCURRENT upstream calls run at once (excess requests degrade to the local fallback).
    Failure never changes Nyra's identity; it only means a local, low-information answer."""
    key = hashlib.sha1(prompt.encode("utf-8", "ignore")).hexdigest()
    now = time.time()
    with _lock:
        hit = _cache.get(key)
        if hit and hit[0] > now:
            return hit[1], hit[2] + "+cache"

    ordered = _configured()
    if any(k in prompt.lower() for k in ("decision", "exactly one token", "choose one")):
        ordered.reverse()
    if not ordered:
        return local_fallback(prompt), "local-fallback"

    if not _slots.acquire(blocking=False):
        log("busy: all upstream slots in use, using local fallback")
        return local_fallback(prompt), "local-fallback"
    started = time.time()
    try:
        for provider in ordered:
            remaining = REQUEST_BUDGET - (time.time() - started)
            if remaining <= 1.0:
                break
            if _breaker_open(provider["name"]):
                continue
            try:
                text = call_provider(provider, prompt, timeout=min(PROVIDER_TIMEOUT, remaining))
                _breaker_ok(provider["name"])
                with _lock:
                    if len(_cache) >= CACHE_MAX:
                        _cache.pop(next(iter(_cache)))
                    _cache[key] = (time.time() + CACHE_TTL, text, provider["name"])
                return text, provider["name"]
            except Exception as exc:
                _breaker_fail(provider["name"], exc)
                log(f"provider {provider['name']} failed: {type(exc).__name__}")
    finally:
        _slots.release()
    return local_fallback(prompt), "local-fallback"


def test_providers():
    """Connectivity test for every configured provider (used by GET /providers/test). Keys are never returned."""
    results = []
    for p in PROVIDERS:
        if not p["url"]:
            results.append({"name": p["name"], "configured": False})
            continue
        t0 = time.time()
        try:
            call_provider(p, "Reply with the single word OK.", timeout=PROVIDER_TIMEOUT)
            results.append({"name": p["name"], "configured": True, "ok": True, "ms": int((time.time() - t0) * 1000)})
            _breaker_ok(p["name"])
        except Exception as exc:
            results.append({"name": p["name"], "configured": True, "ok": False,
                            "error": type(exc).__name__, "ms": int((time.time() - t0) * 1000)})
    return results


def normalize_token(text):
    if not text:
        return "WAIT"
    upper = text.strip().upper()
    for token in TOKENS:
        if upper == token or upper.startswith(token + " "):
            return token
    return "WAIT"


def _extract_json(text):
    if not text:
        return None
    raw = text.strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()
    try:
        value = json.loads(raw)
        return value if isinstance(value, dict) else None
    except Exception:
        start, end = raw.find("{"), raw.rfind("}")
        if start >= 0 and end > start:
            try:
                value = json.loads(raw[start:end+1])
                return value if isinstance(value, dict) else None
            except Exception:
                return None
    return None


def _council_plan_text(prompt):
    """Ask a small, bounded council of configured providers for structured plans.

    This is an optional adapter layer for the user's existing multi-model setup:
    each source must be configured as a normal OpenAI-compatible endpoint in the
    private environment file. No app tokens, unofficial mobile endpoints, or
    credentials from the supplied scripts are embedded in this project.
    """
    council_size = max(1, min(3, _env_int("NYRA_COUNCIL_SIZE", 2)))
    configured = [p for p in _configured() if not _breaker_open(p["name"])]
    if council_size < 2 or len(configured) < 2:
        return decide(prompt + "\n" + PLAN_SCHEMA)

    ordered = configured[:council_size]
    full_prompt = prompt + "\n" + PLAN_SCHEMA
    started = time.time()
    answers = []

    def ask(provider):
        if not _slots.acquire(blocking=False):
            return None
        try:
            remaining = REQUEST_BUDGET - (time.time() - started)
            if remaining <= 1.0:
                return None
            result = call_provider(provider, full_prompt, timeout=min(PROVIDER_TIMEOUT, remaining))
            _breaker_ok(provider["name"])
            return (provider["name"], result)
        except Exception as exc:
            _breaker_fail(provider["name"], exc)
            log(f"council provider {provider['name']} failed: {type(exc).__name__}")
            return None
        finally:
            _slots.release()

    # Small bounded pool: do not spawn one worker per model or queue work behind
    # the game. Results are used only if they contain valid structured plans.
    with ThreadPoolExecutor(max_workers=min(council_size, MAX_CONCURRENT)) as pool:
        futures = [pool.submit(ask, provider) for provider in ordered]
        for future in as_completed(futures, timeout=max(2.0, REQUEST_BUDGET)):
            try:
                item = future.result()
            except Exception:
                item = None
            if item:
                name, raw = item
                obj = _extract_json(raw)
                if obj and str(obj.get("action", "")).upper() in set(TOKENS):
                    answers.append((name, raw, obj))
            if time.time() - started >= REQUEST_BUDGET:
                break

    if not answers:
        return decide(full_prompt)

    # Vote on the action; among plans for the winning action prefer the one with
    # the most useful structured fields. This avoids inventing a third answer.
    votes = {}
    for _, _, obj in answers:
        action = str(obj.get("action", "WAIT")).upper()
        votes[action] = votes.get(action, 0) + 1
    winning_action = max(votes, key=lambda action: (votes[action], action == "WAIT"))
    same_action = [row for row in answers if str(row[2].get("action", "WAIT")).upper() == winning_action]
    chosen = max(same_action, key=lambda row: sum(bool(row[2].get(k)) for k in ("speech", "goal", "reason", "expected_outcome", "blueprint")))
    names = "+".join(row[0] for row in answers)
    return chosen[1], "council[" + names + "]"


def _safe_int(value, default=0):
    try:
        if isinstance(value, bool):
            return default
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def plan(prompt):
    text, provider = _council_plan_text(prompt)
    obj = _extract_json(text)
    if obj:
        action = normalize_token(str(obj.get("action", "WAIT")))
        speech = str(obj.get("speech", ""))[:500]
        blueprint = obj.get("blueprint") if isinstance(obj.get("blueprint"), dict) else None
        goal = str(obj.get("goal", "WAIT")).upper() if obj else "WAIT"
        allowed_goals = {"OBSERVE","ROAM","BUILD","INVESTIGATE","FOLLOW","HIDE","RETURN_HOME","WAIT"}
        if goal not in allowed_goals: goal = "WAIT"
        target = str(obj.get("target", ""))[:120] if obj else ""
        reason = str(obj.get("reason", ""))[:240] if obj else ""
        thread_id = str(obj.get("thread_id", ""))[:120] if obj else ""
        next_step = str(obj.get("next_step", ""))[:240] if obj else ""
        commitment = str(obj.get("commitment", ""))[:40] if obj else ""
        expected_outcome = str(obj.get("expected_outcome", ""))[:320] if obj else ""
        forgiveness_decision = str(obj.get("forgiveness_decision", "DEFER")).upper() if obj else "DEFER"
        if forgiveness_decision not in {"FORGIVE","PARTIAL","REFUSE","DEFER"}: forgiveness_decision = "DEFER"
        forgiveness_reason = str(obj.get("forgiveness_reason", ""))[:240] if obj else ""
        interrupt_player = bool(obj.get("interrupt_player", False)) if obj else False
        interrupt_reason = str(obj.get("interrupt_reason", ""))[:240] if obj else ""
        if interrupt_player and not speech.strip(): interrupt_player = False
        return {"action": action, "speech": speech, "blueprint": blueprint, "goal": goal, "target": target, "reason": reason, "thread_id": thread_id, "next_step": next_step, "commitment": commitment, "expected_outcome": expected_outcome, "forgiveness_decision": forgiveness_decision, "forgiveness_reason": forgiveness_reason, "interrupt_player": interrupt_player, "interrupt_reason": interrupt_reason, "block_x": _safe_int(obj.get("block_x"), 0), "block_y": _safe_int(obj.get("block_y"), 0), "block_z": _safe_int(obj.get("block_z"), 0), "item": str(obj.get("item", ""))[:100], "count": max(1, min(16, _safe_int(obj.get("count"), 1))), "recruit_radius": max(2, min(24, _safe_int(obj.get("recruit_radius"), 12))), "mob_order": str(obj.get("mob_order", "FOLLOW")).upper()[:16], "text": text, "provider": provider}
    return {"action": normalize_token(text), "speech": "", "blueprint": None, "goal": "WAIT", "target": "", "reason": "provider did not return structured JSON", "thread_id": "", "next_step": "", "commitment": "", "expected_outcome": "", "forgiveness_decision": "DEFER", "forgiveness_reason": "", "interrupt_player": False, "interrupt_reason": "", "text": text, "provider": provider}

REFLECT_SCHEMA = """Return ONLY valid JSON with keys: assessment, observed_outcome, lesson, confidence_delta, keep_strategy. assessment must be SUCCESS, PARTIAL, NEUTRAL, FAILURE, or UNCERTAIN. observed_outcome must summarize only observable Minecraft evidence. lesson must be a concise reusable lesson about Nyra's decision-making, not a claim about real-world people. confidence_delta must be between -0.30 and 0.30. keep_strategy must be true or false. Do not invent evidence. If evidence is insufficient, use UNCERTAIN and a near-zero confidence_delta."""


def reflect(prompt):
    text, provider = decide(prompt + "\n" + REFLECT_SCHEMA)
    obj = _extract_json(text)
    if obj:
        assessment = str(obj.get("assessment", "UNCERTAIN")).upper()
        if assessment not in {"SUCCESS","PARTIAL","NEUTRAL","FAILURE","UNCERTAIN"}: assessment = "UNCERTAIN"
        observed = str(obj.get("observed_outcome", ""))[:360]
        lesson = str(obj.get("lesson", ""))[:360]
        try: delta = max(-0.30, min(0.30, float(obj.get("confidence_delta", 0.0))))
        except Exception: delta = 0.0
        keep = bool(obj.get("keep_strategy", False))
        return {"assessment": assessment, "observed_outcome": observed, "lesson": lesson, "confidence_delta": delta, "keep_strategy": keep, "text": text, "provider": provider}
    return {"assessment":"UNCERTAIN", "observed_outcome":"", "lesson":"Insufficient structured evidence; defer learning.", "confidence_delta":0.0, "keep_strategy":False, "text":text, "provider":provider}



# ---------------------------------------------------------------------------
# Local speech-to-text (whisper.cpp). Optional: NYRA_STT_BACKEND=whispercpp.
# Privacy: the audio only lives in a temp file for the duration of one call and is
# always deleted afterwards; nothing raw is stored.
# ---------------------------------------------------------------------------
def wav_to_16k_mono(wav_bytes):
    """Return 16 kHz mono 16-bit PCM WAV bytes (whisper.cpp requires 16 kHz). Stdlib only."""
    with wave.open(io.BytesIO(wav_bytes), "rb") as w:
        ch, width, rate, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        if width != 2:
            raise ValueError("only 16-bit PCM is supported")
        frames = w.readframes(n)
    pcm = array.array("h")
    pcm.frombytes(frames)
    if ch > 1:
        pcm = array.array("h", [int(sum(pcm[i:i + ch]) / ch) for i in range(0, len(pcm) - ch + 1, ch)])
    if rate != 16000 and len(pcm):
        ratio = rate / 16000.0
        out_len = int(len(pcm) / ratio)
        out = array.array("h", [0]) * out_len
        if rate % 16000 == 0:                       # 48k -> 16k: average each group (cheap low-pass)
            k = rate // 16000
            for i in range(out_len):
                seg = pcm[i * k:(i + 1) * k]
                out[i] = int(sum(seg) / len(seg))
        else:                                        # generic linear interpolation
            for i in range(out_len):
                pos = i * ratio
                j = int(pos)
                frac = pos - j
                nxt = pcm[j + 1] if j + 1 < len(pcm) else pcm[j]
                out[i] = int(pcm[j] * (1 - frac) + nxt * frac)
        pcm = out
    buf = io.BytesIO()
    with wave.open(buf, "wb") as o:
        o.setnchannels(1); o.setsampwidth(2); o.setframerate(16000)
        o.writeframes(pcm.tobytes())
    return buf.getvalue()


def stt_whispercpp(wav_bytes):
    """Run whisper.cpp's whisper-cli on one utterance. Raises RuntimeError with a short reason on failure."""
    binary = os.getenv("NYRA_WHISPER_BIN", "whisper-cli")
    model = os.getenv("NYRA_WHISPER_MODEL", "")
    lang = os.getenv("NYRA_STT_LANG", "ar")
    threads = os.getenv("NYRA_WHISPER_THREADS", "2")   # keep CPU for the game running next to us
    timeout = float(os.getenv("NYRA_WHISPER_TIMEOUT", "25"))
    if not model or not os.path.isfile(model):
        raise RuntimeError("NYRA_WHISPER_MODEL is not set or the file does not exist")
    if shutil.which(binary) is None and not os.path.isfile(binary):
        raise RuntimeError("whisper binary not found: set NYRA_WHISPER_BIN")
    audio16 = wav_to_16k_mono(wav_bytes)
    fd, path = tempfile.mkstemp(suffix=".wav")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(audio16)
        cmd = [binary, "-m", model, "-f", path, "-l", lang, "-t", str(threads), "-nt", "-np"]
        res = subprocess.run(cmd, capture_output=True, timeout=timeout, text=True)
        if res.returncode != 0:
            raise RuntimeError("whisper exited with code %d" % res.returncode)
        return " ".join(res.stdout.split()).strip()
    except subprocess.TimeoutExpired:
        raise RuntimeError("whisper timed out")
    finally:
        try: os.unlink(path)
        except OSError: pass


class Handler(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        raw = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == "/health":
            self._json(200, {"ok": True, "service": "nyra-core", "time": time.time(),
                             "providers": len(_configured()), "breakers": breaker_status()})
        elif self.path == "/providers/test":
            self._json(200, {"results": test_providers()})
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size > 1024 * 1024:
                return self._json(413, {"error": "request too large"})
            data = json.loads(self.rfile.read(size) or b"{}")
        except Exception:
            return self._json(400, {"error": "invalid json"})
        if self.path == "/decide":
            text, provider = decide(str(data.get("prompt", "")))
            return self._json(200, {"text": text, "provider": provider})
        if self.path == "/plan":
            return self._json(200, plan(str(data.get("prompt", ""))))
        if self.path == "/reflect":
            return self._json(200, reflect(str(data.get("prompt", ""))))
        if self.path == "/tts":
            return self._tts(data)
        if self.path == "/voice/partial":
            upstream = os.getenv("NYRA_PARTIAL_STT_URL", "").strip()
            if not upstream:
                return self._json(200, {"text": "", "partial": True})
            try:
                req = urllib.request.Request(upstream, data=json.dumps(data).encode(), headers={"Content-Type": "application/json"}, method="POST")
                with urllib.request.urlopen(req, timeout=5) as response:
                    result = json.loads(response.read().decode())
                return self._json(200, {"text": str(result.get("text", ""))[:500], "partial": True})
            except Exception as exc:
                return self._json(502, {"error": f"partial STT unavailable: {type(exc).__name__}"})
            return
        if self.path == "/voice/transcribe":
            return self._transcribe(data)
        return self._json(404, {"error": "not found"})

    def _tts(self, data):
        text = str(data.get("text", "")).strip()[:800]
        lang = str(data.get("lang", os.getenv("NYRA_TTS_LANG", "ar")))[:12]
        if not text:
            return self._json(400, {"error": "empty text"})
        # Optional gTTS adapter. Credentials are not required; outbound network access is used by gTTS.
        try:
            from gtts import gTTS
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as f:
                path=f.name
            try:
                gTTS(text=text, lang=lang).save(path)
                raw=open(path,"rb").read()
            finally:
                try: os.unlink(path)
                except OSError: pass
            self.send_response(200); self.send_header("Content-Type","audio/mpeg"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
        except Exception as exc:
            return self._json(501, {"error": f"TTS unavailable: {type(exc).__name__}"})

    def _transcribe(self, data):
        # OpenAI-compatible STT gateway. It accepts a base64 WAV and returns {text}.
        raw_b64 = str(data.get("audio_wav_base64", ""))
        player_id = str(data.get("player_id", ""))[:80]
        if not raw_b64:
            return self._json(400, {"error": "missing audio_wav_base64"})
        try:
            audio=base64.b64decode(raw_b64, validate=True)
        except Exception:
            return self._json(400, {"error": "invalid audio encoding"})
        if len(audio) > 2_000_000:
            return self._json(413, {"error": "audio too large"})
        if os.getenv("NYRA_STT_BACKEND", "").lower() == "whispercpp":
            try:
                text = stt_whispercpp(audio)[:1000]
                return self._json(200, {"text": text, "player_id": player_id})
            except Exception as exc:
                return self._json(502, {"error": "local STT failed: " + str(exc)[:120], "player_id": player_id})
        url=os.getenv("NYRA_STT_URL", "")
        key=os.getenv("NYRA_STT_KEY", "")
        model=os.getenv("NYRA_STT_MODEL", "whisper-1")
        if not url:
            return self._json(501, {"error": "NYRA_STT_URL is not configured", "player_id": player_id})
        boundary="----NyraVoiceBoundary" + str(int(time.time()*1000))
        def part(name, value, filename=None, content_type=None):
            head=f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\""
            if filename: head += f"; filename=\"{filename}\""
            head += "\r\n"
            if content_type: head += f"Content-Type: {content_type}\r\n"
            return head.encode()+b"\r\n"+value+b"\r\n"
        body=part("model", model.encode())+part("file", audio, "audio.wav", "audio/wav")+f"--{boundary}--\r\n".encode()
        headers={"Content-Type":f"multipart/form-data; boundary={boundary}"}
        if key: headers["Authorization"]="Bearer "+key
        try:
            req=urllib.request.Request(url,data=body,headers=headers,method="POST")
            with urllib.request.urlopen(req,timeout=30) as response:
                obj=json.loads(response.read().decode())
            text=str(obj.get("text", "")).strip()[:1000]
            return self._json(200,{"text":text,"player_id":player_id})
        except Exception as exc:
            return self._json(502,{"error":f"STT provider failed: {type(exc).__name__}","player_id":player_id})

    def log_message(self, *_):
        pass


if __name__ == "__main__":
    print(f"Nyra Core listening on http://{HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
