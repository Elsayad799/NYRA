"""Provider routing tests: failover, circuit breaker, budget, cache, concurrency cap. No network needed."""
import time, threading, importlib
import server

def reset(providers, **kw):
    importlib.reload(server)
    server.PROVIDERS[:] = providers
    for k, v in kw.items():
        setattr(server, k, v)
    server._breaker.clear(); server._cache.clear()

def prov(name, url="http://x/" ):
    return {"name": name, "url": url, "key": "", "model": ""}

calls = []
def make_fake(behaviour):
    def fake(provider, prompt, timeout=None):
        calls.append(provider["name"])
        r = behaviour[provider["name"]]
        if isinstance(r, Exception):
            raise r
        return r
    return fake

# 1) failover: primary fails, secondary answers
reset([prov("primary"), prov("secondary")])
calls.clear()
server.call_provider = make_fake({"primary": RuntimeError("down"), "secondary": "OBSERVE"})
text, who = server.decide("hello world 1")
assert (text, who) == ("OBSERVE", "secondary"), (text, who)
assert calls == ["primary", "secondary"]

# 2) circuit breaker: after BREAKER_FAILS failures the broken provider is skipped
reset([prov("primary"), prov("secondary")], BREAKER_FAILS=2)
calls.clear()
server.call_provider = make_fake({"primary": RuntimeError("down"), "secondary": "WAIT"})
server.decide("p-a"); server.decide("p-b")           # two failures on primary -> breaker opens
calls.clear()
server.decide("p-c")
assert calls == ["secondary"], calls                  # primary skipped, not retried on every event
assert server.breaker_status()["primary"]["open"]

# 3) cache: identical prompt does not hit upstream twice
reset([prov("primary")])
calls.clear()
server.call_provider = make_fake({"primary": "FOLLOW"})
server.decide("same prompt"); text, who = server.decide("same prompt")
assert calls == ["primary"] and who.endswith("+cache") and text == "FOLLOW"

# 4) nothing configured -> local fallback, no crash
reset([{"name": "primary", "url": "", "key": "", "model": ""}])
text, who = server.decide("anything")
assert who == "local-fallback" and text

# 5) all providers failing -> local fallback, identity unchanged (still returns text)
reset([prov("primary"), prov("secondary")])
server.call_provider = make_fake({"primary": RuntimeError("a"), "secondary": RuntimeError("b")})
text, who = server.decide("all down")
assert who == "local-fallback"

# 6) concurrency cap: with 1 slot busy, extra requests degrade instantly instead of piling up
reset([prov("primary")], MAX_CONCURRENT=1)
server._slots = threading.BoundedSemaphore(1)
gate = threading.Event()
def slow(provider, prompt, timeout=None):
    gate.wait(2); return "WAIT"
server.call_provider = slow
t = threading.Thread(target=lambda: server.decide("slow one")); t.start(); time.sleep(0.2)
t0 = time.time(); text, who = server.decide("second while busy"); dt = time.time() - t0
assert who == "local-fallback" and dt < 0.5, (who, dt)
gate.set(); t.join()

# 7) budget: tiny budget stops after the first slow failure instead of walking all providers
reset([prov("primary"), prov("secondary")], REQUEST_BUDGET=1.5)
def slow_fail(provider, prompt, timeout=None):
    calls.append(provider["name"]); time.sleep(1.2); raise RuntimeError("slow")
calls.clear(); server.call_provider = slow_fail
t0 = time.time(); text, who = server.decide("budget test"); dt = time.time() - t0
assert who == "local-fallback" and calls == ["primary"], calls

# 8) test_providers never leaks keys
reset([{"name": "primary", "url": "http://x/", "key": "SECRET-KEY-123", "model": ""}])
server.call_provider = make_fake({"primary": "OK"})
out = str(server.test_providers())
assert "SECRET" not in out and "'ok': True" in out

print("provider routing tests: PASS")
