"""Offline tests for the optional bounded AI council and RECRUIT action."""
import json
import os
import importlib
import server


def provider(name):
    return {"name": name, "url": "http://example.invalid", "key": "", "model": ""}


# RECRUIT was in the plan schema but omitted from the action normalizer.
assert server.normalize_token("RECRUIT") == "RECRUIT"

# Council: two configured models vote on action; the majority plan is selected.
old_size = os.environ.get("NYRA_COUNCIL_SIZE")
os.environ["NYRA_COUNCIL_SIZE"] = "2"
try:
    importlib.reload(server)
    server.PROVIDERS[:] = [provider("primary"), provider("secondary")]
    server._breaker.clear()
    server._cache.clear()

    def fake_call(p, prompt, timeout=None):
        if p["name"] == "primary":
            return json.dumps({"action": "RECRUIT", "speech": "تعالوا معايا.", "goal": "FOLLOW", "reason": "need help"})
        return json.dumps({"action": "RECRUIT", "speech": "تعالوا معايا.", "goal": "FOLLOW", "reason": "need help"})

    server.call_provider = fake_call
    result = server.plan("Nyra planning test")
    assert result["action"] == "RECRUIT", result
    assert result["provider"].startswith("council[") or result["provider"] == "local-fallback", result
    assert result["speech"] == "تعالوا معايا.", result
finally:
    if old_size is None:
        os.environ.pop("NYRA_COUNCIL_SIZE", None)
    else:
        os.environ["NYRA_COUNCIL_SIZE"] = old_size

print("council tests: PASS")
