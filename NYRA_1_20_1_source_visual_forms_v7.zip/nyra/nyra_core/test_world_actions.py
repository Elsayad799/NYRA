"""Offline tests for AI-selected, bounded Minecraft world-action fields."""
import json
import server

assert server.normalize_token("BREAK") == "BREAK"
assert server.normalize_token("GIVE") == "GIVE"
assert server.normalize_token("RECRUIT") == "RECRUIT"
assert server.normalize_token("MOB_COMMAND") == "MOB_COMMAND"
assert "block_x, block_y, block_z" in server.PLAN_SCHEMA
assert "item must be a Minecraft item id" in server.PLAN_SCHEMA
assert "mob_order must be one of FOLLOW,GUARD,DEFEND,WAIT" in server.PLAN_SCHEMA
assert server._safe_int(True, 7) == 7
assert server._safe_int("12", 0) == 12
assert server._safe_int("not-a-number", 9) == 9

original = server._council_plan_text
try:
    server._council_plan_text = lambda prompt: (json.dumps({
        "action": "GIVE", "item": "minecraft:bread", "count": 999,
        "block_x": "12", "block_y": 65, "block_z": -3, "recruit_radius": 1,
        "speech": "خد دي", "mob_order": "DEFEND"
    }), "unit-test")
    result = server.plan("test structured world action")
    assert result["action"] == "GIVE", result
    assert result["item"] == "minecraft:bread", result
    assert result["count"] == 16, result
    assert result["block_x"] == 12 and result["block_y"] == 65 and result["block_z"] == -3, result
    assert result["recruit_radius"] == 2, result
    assert result["mob_order"] == "DEFEND", result
finally:
    server._council_plan_text = original

print("AI world-action contract tests: PASS")
