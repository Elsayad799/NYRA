# NYRA AI connector integration (v8)

Minecraft continues to send decisions to the existing Python Core (`/plan`, `/reflect`). This patch replaces only the provider transport layer: it does not import or start Telegram bots, polling loops, terminal input loops, or PHP/JS projects. Memory, relationships, personality, planning, and world-action validation remain in NYRA.

## Adapters added from the supplied files

- `gemini_proxy`: uses the JSON `{"message": "..."}` request style from the supplied `gemini.py` and normalizes common response fields (`response`, `reply`, `content`, `text`, `result`, `answer`). The example endpoint from that file is prefilled in `.env.example`, but it is a third-party service and may be unavailable or change its rules.
- `ai_seek_sse`: supports the streamed `data: {"content": ...}` response style used in `ai_2.py`. It requires an access token provided privately in `NYRA_SECONDARY_KEY` or `NYRA_TERTIARY_KEY`; no embedded token/session identifiers are copied.
- `openai_compatible`: retains the original standard `/chat/completions` support.
- `simple_json`: generic JSON `{message: prompt}` adapter for an endpoint you are authorized to use.

## Configuration

Edit `nyra.env` (do not commit it). Set `NYRA_PRIMARY_KIND`, `NYRA_PRIMARY_URL`, and optional `NYRA_PRIMARY_KEY` / `NYRA_PRIMARY_MODEL`. Optional fallback providers use the same suffixes for `SECONDARY` and `TERTIARY`. `NYRA_COUNCIL_SIZE=1` is the safer default for lower latency. Restart the Python Core after changes.

The multi-search script relies on a mobile-app Firebase identity and an `ULTRA` plan claim; the DeepSeek scraper solves a website challenge; GPT.php uses plain HTTP. Those flows are not embedded as-is: they depend on third-party app/site access controls, are fragile, and could expose credentials. The original source archive also contains Telegram bot tokens/cookies/session material; these are deliberately not copied into the Minecraft project. If any were real and shared, revoke/rotate them.

## Verify

1. Start `server.py` with the private environment loaded.
2. Open `http://127.0.0.1:8787/health`; `providers` should be at least 1.
3. Open `http://127.0.0.1:8787/providers/test`; the primary should report `ok: true` when its endpoint is working.
4. In Minecraft, use the existing `/nyra core test` command (permission requirements apply) and try `/nyra-talk hello` or address Nyra in chat.

An adapter only makes the connection compatible; it cannot guarantee that a third-party endpoint stays online, returns valid Minecraft action JSON, or allows this usage. Run a GitHub Actions build before installing the resulting JAR.
