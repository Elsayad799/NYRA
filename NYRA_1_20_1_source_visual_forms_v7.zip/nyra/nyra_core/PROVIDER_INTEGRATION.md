# Nyra AI provider integration

Nyra's Minecraft mod calls the Python Core over HTTP. The Core owns model routing;
Minecraft owns world observation, persistent in-world memories, relationships,
personality traits, and execution of approved in-world actions.

## Using the supplied Python AI sources

The supplied `ai.py`, `ai_2.py`, `Bot AI.py`, `gemini.py`, `GPT.py`, `Claude.php`,
and `DeepSeek 18 model.py` are not a single importable AI library. Several contain
interactive `while` loops, Telegram polling, hard-coded service tokens, or calls to
third-party proxy endpoints. Importing them into the game Core would start extra
polling loops or reuse credentials in the wrong process. They should be treated as
provider references, not imported as modules.

Instead, configure endpoints that you are authorized to use in `nyra.env`:

- `NYRA_PRIMARY_URL`, `NYRA_PRIMARY_KEY`, `NYRA_PRIMARY_MODEL`
- `NYRA_SECONDARY_URL`, `NYRA_SECONDARY_KEY`, `NYRA_SECONDARY_MODEL`
- `NYRA_TERTIARY_URL`, `NYRA_TERTIARY_KEY`, `NYRA_TERTIARY_MODEL`

Each endpoint must implement the OpenAI-compatible `/chat/completions` request and
response shape. Official model APIs or a local gateway you control are appropriate.
Do not paste API keys into source files or commit `nyra.env`.

## AI council

Set `NYRA_COUNCIL_SIZE=2` to ask up to two configured providers in parallel for a
structured plan. The Core accepts only valid JSON plans, votes on the proposed
in-world action, and uses a provider's actual candidate plan rather than fabricating
a merged answer. The pool is bounded by `NYRA_MAX_CONCURRENT`; provider failures
remain covered by the circuit breaker and fallback path. Set `NYRA_COUNCIL_SIZE=1`
for lowest latency or when only one provider is configured.

The council is not a claim of consciousness. Persistent memory, relationships,
mutable personality, episodic history, reflection, and game-world consequences are
separate systems that make Nyra's behavior continuous across sessions.
