"""Local STT tests: resampling and the whisper.cpp wrapper, using a fake whisper binary (no model download)."""
import array, io, os, stat, struct, sys, tempfile, wave
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import server


def make_wav(rate, samples, channels=1):
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(channels); w.setsampwidth(2); w.setframerate(rate)
        w.writeframes(array.array("h", samples).tobytes())
    return buf.getvalue()


def read_wav(b):
    with wave.open(io.BytesIO(b), "rb") as w:
        a = array.array("h"); a.frombytes(w.readframes(w.getnframes()))
        return w.getframerate(), w.getnchannels(), a


# 48 kHz mono -> 16 kHz mono keeps duration (3:1)
rate, ch, out = read_wav(server.wav_to_16k_mono(make_wav(48000, [1000] * 4800)))
assert (rate, ch, len(out)) == (16000, 1, 1600), (rate, ch, len(out))
assert all(abs(v - 1000) <= 1 for v in out)

# stereo is mixed down; 44.1 kHz uses the generic path
rate, ch, out = read_wav(server.wav_to_16k_mono(make_wav(44100, [100, 300] * 4410, channels=2)))
assert (rate, ch) == (16000, 1) and abs(len(out) - 1600) <= 2

# 8-bit / empty input must fail cleanly, not crash the Core
try:
    server.wav_to_16k_mono(b"not a wav")
    raise SystemExit("expected failure on invalid wav")
except Exception:
    pass

# whisper wrapper with a fake binary that prints a transcript and records the temp file it was given
tmp = tempfile.mkdtemp()
seen = os.path.join(tmp, "seen.txt")
fake = os.path.join(tmp, "whisper-fake")
with open(fake, "w") as f:
    f.write("#!/bin/sh\n# args: -m model -f file -l lang -t N -nt -np\n"
            "echo \"$4\" > %s\necho '  مرحبا   يا نايرا  '\n" % seen)
os.chmod(fake, os.stat(fake).st_mode | stat.S_IEXEC)
model = os.path.join(tmp, "model.bin"); open(model, "wb").write(b"x")
os.environ.update({"NYRA_WHISPER_BIN": fake, "NYRA_WHISPER_MODEL": model, "NYRA_STT_LANG": "ar"})
text = server.stt_whispercpp(make_wav(48000, [0] * 4800))
assert text == "مرحبا يا نايرا", repr(text)
used = open(seen).read().strip()
assert used.endswith(".wav") and not os.path.exists(used), "temp audio must be deleted after use"

# failure paths: missing model / failing binary / timeout all raise RuntimeError
os.environ["NYRA_WHISPER_MODEL"] = os.path.join(tmp, "missing.bin")
try:
    server.stt_whispercpp(make_wav(48000, [0] * 480)); raise SystemExit("expected RuntimeError")
except RuntimeError:
    pass
os.environ["NYRA_WHISPER_MODEL"] = model
bad = os.path.join(tmp, "whisper-bad")
open(bad, "w").write("#!/bin/sh\nexit 3\n"); os.chmod(bad, 0o755)
os.environ["NYRA_WHISPER_BIN"] = bad
try:
    server.stt_whispercpp(make_wav(48000, [0] * 480)); raise SystemExit("expected RuntimeError")
except RuntimeError as e:
    assert "code 3" in str(e)
slow = os.path.join(tmp, "whisper-slow")
open(slow, "w").write("#!/bin/sh\nsleep 5\n"); os.chmod(slow, 0o755)
os.environ.update({"NYRA_WHISPER_BIN": slow, "NYRA_WHISPER_TIMEOUT": "1"})
try:
    server.stt_whispercpp(make_wav(48000, [0] * 480)); raise SystemExit("expected timeout")
except RuntimeError as e:
    assert "timed out" in str(e)
print("local STT tests: PASS")
