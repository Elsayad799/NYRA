from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD = (ROOT / 'src/main/java/com/nyra/core/NyraMod.java').read_text(encoding='utf-8')
RECRUIT = (ROOT / 'src/main/java/com/nyra/core/runtime/NyraMobRecruitment.java').read_text(encoding='utf-8')
VOICE = (ROOT / 'src/main/java/com/nyra/voice/NyraVoicePlugin.java').read_text(encoding='utf-8')
CORE = (ROOT / 'nyra_core/server.py').read_text(encoding='utf-8')

assert 'Commands.literal("recruit")' in MOD
assert 'info("army"' in MOD
assert 'Commands.literal("release")' in MOD
assert 'Commands.literal("tts")' in MOD
assert 'NyraMobRecruitment.tick(s)' in MOD
assert '"RECRUIT"' in MOD
assert 'action must be one of' in CORE and 'RECRUIT' in CORE
assert 'getOpusEncodedData()' in VOICE
assert 'createLocationalAudioChannel' in VOICE
assert 'NyraMod.ttsEnabled()' in VOICE
assert 'setPersistenceRequired()' in RECRUIT
assert 'mob.getNavigation().moveTo(leader, 1.05)' in RECRUIT
print('Minecraft capability contract checks: PASS')
