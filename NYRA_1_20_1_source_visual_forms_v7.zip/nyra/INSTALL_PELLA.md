# Dedicated server (e.g. Pella.app / SillyDev) — Minecraft 1.20.1 + Fabric

1. Create a Minecraft Java **1.20.1 Fabric** server and select **Java 17**.
2. Upload Fabric API (1.20.1 build) and `nyra-*.jar` into `mods/`.
3. Optional: Simple Voice Chat (Fabric 1.20.1). It needs a UDP port; many free hosts do not offer one.
4. Start once, stop, then edit `world/nyra/config.json`.
5. The Python Core must run on the same machine (`core_url` = `http://127.0.0.1:8787`). If the host cannot run a
   persistent Python process, Nyra keeps working with local behaviour only (no AI planning).
6. Provide keys only via environment variables (see `nyra_core/.env.example`).
7. Use `/nyra core test` as operator to check Core and provider connectivity.
